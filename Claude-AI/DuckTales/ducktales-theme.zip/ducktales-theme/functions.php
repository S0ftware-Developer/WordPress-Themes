<?php
/**
 * Функции и настройки темы DuckTalesTheme.
 *
 * @package DuckTalesTheme
 */

// Защита: файл нельзя открыть напрямую по адресу в браузере
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Версия темы берём из style.css — она же используется для сброса кэша стилей
define( 'DUCKTALES_VERSION', wp_get_theme()->get( 'Version' ) );


/* ==========================================================================
   1. НАСТРОЙКА ТЕМЫ: поддержка функций WordPress и регистрация меню
   ========================================================================== */
function ducktales_setup() {

	// Файлы переводов лежат в папке languages
	load_theme_textdomain( 'ducktales-theme', get_template_directory() . '/languages' );

	// WordPress сам формирует тег <title>
	add_theme_support( 'title-tag' );

	// Миниатюры записей и адаптивные встраиваемые видео
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );

	// RSS-ссылки в <head>
	add_theme_support( 'automatic-feed-links' );

	// Современная HTML5-разметка форм, комментариев и галерей
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script',
	) );

	// Свой логотип из «Внешний вид → Настроить». Если не загружен — покажем богатого селезня.
	add_theme_support( 'custom-logo', array(
		'height'      => 64,
		'width'       => 76,
		'flex-height' => true,
		'flex-width'  => true,
	) );

	// Размер картинки для карточек-экспедиций (16:9)
	add_image_size( 'ducktales-card', 640, 360, true );

	// Два места для меню: в шапке (карта) и в подвале
	register_nav_menus( array(
		'primary' => __( 'Главное меню (карта в шапке)', 'ducktales-theme' ),
		'footer'  => __( 'Меню в подвале', 'ducktales-theme' ),
	) );
}
add_action( 'after_setup_theme', 'ducktales_setup' );

// Максимальная ширина контента (нужна для встраиваемых объектов)
function ducktales_content_width() {
	$GLOBALS['content_width'] = 720;
}
add_action( 'after_setup_theme', 'ducktales_content_width', 0 );


/* ==========================================================================
   2. ПОДКЛЮЧЕНИЕ СТИЛЕЙ, ШРИФТОВ И СКРИПТОВ
   ========================================================================== */
function ducktales_scripts() {

	// Шрифты Google: «Press Start 2P» (заголовки, с кириллицей) и «PT Serif» (основной текст)
	wp_enqueue_style(
		'ducktales-fonts',
		'https://fonts.googleapis.com/css2?family=PT+Serif:ital,wght@0,400;0,700;1,400&family=Press+Start+2P&display=swap',
		array(),
		null
	);

	// Главный файл стилей темы (style.css в корне)
	wp_enqueue_style( 'ducktales-style', get_stylesheet_uri(), array( 'ducktales-fonts' ), DUCKTALES_VERSION );

	// Анимации: гидроплан, сбор монет, бандиты
	wp_enqueue_style(
		'ducktales-animations',
		get_template_directory_uri() . '/assets/css/animations.css',
		array( 'ducktales-style' ),
		DUCKTALES_VERSION
	);

	// Скрипт темы (мобильное меню; задел под счётчик монет, звуки и мини-игру)
	wp_enqueue_script(
		'ducktales-main',
		get_template_directory_uri() . '/assets/js/main.js',
		array(),
		DUCKTALES_VERSION,
		true
	);

	// Скрипт ответов на комментарии (только там, где он нужен)
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'ducktales_scripts' );

// Ускоряем загрузку шрифтов: заранее открываем соединение с серверами Google
function ducktales_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		$urls[] = 'https://fonts.googleapis.com';
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'anonymous',
		);
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'ducktales_resource_hints', 10, 2 );


/* ==========================================================================
   3. МЕНЮ: запасной вариант, если меню ещё не создано в админке
   ========================================================================== */
function ducktales_fallback_menu() {
	echo '<ul id="primary-menu" class="menu">';
	echo '<li class="menu-item"><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Главная', 'ducktales-theme' ) . '</a></li>';
	wp_list_pages( array(
		'title_li' => '',
		'depth'    => 1,
	) );
	echo '</ul>';
}


/* ==========================================================================
   4. ПИКСЕЛЬНЫЕ СПРАЙТЫ
   ========================================================================== */

/**
 * Возвращает <img> с пиксельным спрайтом из assets/images.
 * Пропорции спрайтов заданы здесь, чтобы страница не «прыгала» при загрузке.
 *
 * @param string $name  Имя файла без .svg.
 * @param int    $width Ширина на странице в пикселях.
 * @param string $class Дополнительные CSS-классы.
 */
function ducktales_sprite( $name, $width, $class = '' ) {
	$ratios = array(
		'tycoon'    => array( 30, 36 ),
		'coin'      => array( 22, 22 ),
		'money-bag' => array( 24, 24 ),
		'gem'       => array( 22, 20 ),
		'chest'     => array( 30, 22 ),
		'crown'     => array( 26, 18 ),
		'compass'   => array( 26, 26 ),
		'seaplane'  => array( 48, 24 ),
		'vault'     => array( 34, 44 ),
		'bandit'    => array( 22, 32 ),
		'butler'    => array( 22, 32 ),
		'skyline'   => array( 160, 40 ),
	);

	if ( ! isset( $ratios[ $name ] ) ) {
		return '';
	}

	$height = round( $width * $ratios[ $name ][1] / $ratios[ $name ][0] );
	$url    = get_template_directory_uri() . '/assets/images/' . $name . '.svg';

	return sprintf(
		'<img class="pixel-img %1$s" src="%2$s" width="%3$d" height="%4$d" alt="" aria-hidden="true">',
		esc_attr( $class ),
		esc_url( $url ),
		(int) $width,
		(int) $height
	);
}

/**
 * Иконка сокровища по номеру карточки: мешок → камень → сундук → корона → …
 */
function ducktales_treasure_icon( $index ) {
	$icons = array(
		'money-bag' => 48,
		'gem'       => 40,
		'chest'     => 52,
		'crown'     => 44,
	);

	$names = array_keys( $icons );
	$name  = $names[ (int) $index % count( $names ) ];

	return ducktales_sprite( $name, $icons[ $name ], 'expedition__icon' );
}


/* ==========================================================================
   5. ПОМОЩНИКИ ДЛЯ ШАБЛОНОВ
   ========================================================================== */

// Номер экспедиции — это настоящий ID записи, дополненный нулями: «№ 0042»
function ducktales_expedition_number() {
	return sprintf( '%04d', get_the_ID() );
}

// «Место» экспедиции — это первая рубрика записи
function ducktales_place_name() {
	$categories = get_the_category();

	if ( ! empty( $categories ) && 'uncategorized' !== $categories[0]->slug ) {
		return $categories[0]->name;
	}

	return __( 'Неизвестные земли', 'ducktales-theme' );
}

// Время чтения: считаем слова (в том числе кириллические) при скорости 180 слов в минуту
function ducktales_reading_time() {
	$text  = wp_strip_all_tags( get_the_content() );
	$words = preg_match_all( '/\p{L}+/u', $text );

	return max( 1, (int) ceil( $words / 180 ) );
}

// Мета-строка под заголовком: дата отправления и время в пути
function ducktales_entry_meta() {
	printf(
		'<p class="entry-meta"><span class="entry-meta__item">%1$s <time datetime="%2$s">%3$s</time></span><span class="entry-meta__item">%4$s</span></p>',
		esc_html__( 'Отправление:', 'ducktales-theme' ),
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		/* translators: %d — минуты чтения */
		esc_html( sprintf( __( 'В пути: %d мин', 'ducktales-theme' ), ducktales_reading_time() ) )
	);
}

// Короткий анонс для карточек: 28 слов и многоточие
function ducktales_excerpt_length() {
	return 28;
}
add_filter( 'excerpt_length', 'ducktales_excerpt_length' );

function ducktales_excerpt_more() {
	return '…';
}
add_filter( 'excerpt_more', 'ducktales_excerpt_more' );

/**
 * Шутливая записка от домработницы для пустых страниц (404, поиск без результатов).
 * Возвращает случайную фразу, чтобы страница не выглядела одинаково при каждом заходе.
 */
function ducktales_housekeeper_note() {
	$notes = array(
		__( 'Милый, здесь только что было прибрано — и заодно исчезла нужная тебе страница.', 'ducktales-theme' ),
		__( 'Я смахнула пыль со всех комнат поместья, но такой комнаты не нашла.', 'ducktales-theme' ),
		__( 'Проверь, не завалялся ли адрес страницы под ковром в прихожей.', 'ducktales-theme' ),
	);

	return $notes[ array_rand( $notes ) ];
}
