<?php
/**
 * Шаблон одиночной записи — страница одной «экспедиции».
 *
 * @package DuckTalesTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="container">
	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>

			<?php // Вкладка с номером экспедиции ?>
			<p class="expedition__tab">
				<?php
				/* translators: %s — номер экспедиции */
				printf( esc_html__( 'Экспедиция № %s', 'ducktales-theme' ), esc_html( ducktales_expedition_number() ) );
				?>
			</p>

			<header class="entry__header">
				<h1 class="entry__title"><?php the_title(); ?></h1>

				<?php // Дата отправления и время в пути ?>
				<?php ducktales_entry_meta(); ?>
			</header>

			<?php // Большая картинка экспедиции (если есть) ?>
			<?php if ( has_post_thumbnail() ) : ?>
				<div class="entry__thumb"><?php the_post_thumbnail( 'large' ); ?></div>
			<?php endif; ?>

			<div class="entry__content">
				<?php
				the_content();

				// Постраничные записи (<!--nextpage-->)
				wp_link_pages( array(
					'before' => '<p class="page-links">' . esc_html__( 'Страницы:', 'ducktales-theme' ),
					'after'  => '</p>',
				) );
				?>
			</div>

			<footer class="entry__footer">
				<?php // Рубрика — «место», метки — «находки» ?>
				<p class="entry__tags">
					<?php
					/* translators: %s — название рубрики */
					printf( esc_html__( 'Место: %s', 'ducktales-theme' ), esc_html( ducktales_place_name() ) );
					?>
				</p>
				<?php the_tags( '<p class="entry__tags">' . esc_html__( 'Находки: ', 'ducktales-theme' ), ', ', '</p>' ); ?>
			</footer>
		</article>

		<?php // Переход между экспедициями ?>
		<?php
		the_post_navigation( array(
			'prev_text'          => esc_html__( 'Предыдущая экспедиция: %title', 'ducktales-theme' ),
			'next_text'          => esc_html__( 'Следующая экспедиция: %title', 'ducktales-theme' ),
			'screen_reader_text' => esc_html__( 'Навигация по экспедициям', 'ducktales-theme' ),
		) );
		?>

		<?php // Комментарии оформлены как письма в поместье (см. comments.php WordPress по умолчанию) ?>
		<?php
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
		?>

	<?php endwhile; ?>
</div>

<?php
get_footer();
