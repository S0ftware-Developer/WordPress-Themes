<?php
/**
 * Подвал сайта: паттерн из монет, стопка монет с бандитами-похитителями,
 * меню, копирайт и подпись автора.
 *
 * @package DuckTalesTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</main><!-- #content -->

<?php // Лента с силуэтом города над футером ?>
<div class="skyline-band skyline-band--footer" aria-hidden="true">
	<?php echo ducktales_sprite( 'skyline', 1200, '' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
</div>

<?php // Фон футера — бесшовный паттерн из монет (pattern-coins.svg задан в style.css) ?>
<footer class="site-footer">
	<div class="site-footer__panel">

		<?php // Стопка монет с бандитами, которые по очереди их похищают (движение — в animations.css) ?>
		<div class="site-footer__heist" aria-hidden="true">
			<?php echo ducktales_sprite( 'bandit', 40, 'site-footer__bandit site-footer__bandit--left' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php for ( $i = 0; $i < 5; $i++ ) : ?>
				<?php echo ducktales_sprite( 'coin', 26, 'site-footer__coin' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php endfor; ?>
			<?php echo ducktales_sprite( 'bandit', 40, 'site-footer__bandit site-footer__bandit--right' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</div>

		<?php echo ducktales_sprite( 'tycoon', 64, 'site-footer__logo' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

		<?php // Меню подвала: показываем, только если оно назначено в «Внешний вид → Меню» ?>
		<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<nav class="footer-nav" aria-label="<?php esc_attr_e( 'Меню в подвале', 'ducktales-theme' ); ?>">
				<?php
				wp_nav_menu( array(
					'theme_location' => 'footer',
					'container'      => false,
					'depth'          => 1,
				) );
				?>
			</nav>
		<?php endif; ?>

		<p class="site-footer__copy">
			<?php
			printf(
				/* translators: 1: год, 2: название сайта */
				esc_html__( '© %1$s %2$s. Следи за монетами — братья опять что-то замышляют.', 'ducktales-theme' ),
				esc_html( wp_date( 'Y' ) ),
				esc_html( get_bloginfo( 'name' ) )
			);
			?>
		</p>

		<?php // Подпись автора темы (обязательная) ?>
		<p class="site-footer__copy site-footer__credit">The website was made by Andrei Orlov: <a href="https://orlovandrei.space" target="_blank" rel="noopener">orlovandrei.space</a></p>

		<a class="button" href="#top"><?php esc_html_e( 'Взлететь наверх', 'ducktales-theme' ); ?></a>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
