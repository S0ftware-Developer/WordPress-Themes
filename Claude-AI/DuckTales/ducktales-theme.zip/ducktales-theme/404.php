<?php
/**
 * Страница ошибки 404: дворецкий Даксворд разводит крыльями.
 *
 * @package DuckTalesTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="container">
	<section class="note">

		<?php echo ducktales_sprite( 'butler', 110, 'note__icon' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

		<div class="ledger">
			<h1 class="ledger__title"><?php esc_html_e( 'Такой комнаты в поместье нет', 'ducktales-theme' ); ?></h1>
			<p class="ledger__text"><?php esc_html_e( 'Страницы по этому адресу не существует: возможно, её убрали в дальнее крыло или адрес набран с ошибкой. Загляните в другую комнату или вернитесь в холл.', 'ducktales-theme' ); ?></p>
		</div>

		<?php get_search_form(); ?>

		<a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'В холл поместья', 'ducktales-theme' ); ?></a>
	</section>
</div>

<?php
get_footer();
