<?php
/**
 * Шапка сайта: небо Даксбурга с гидропланом, логотип и меню в виде карты сокровищ.
 *
 * @package DuckTalesTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php // Помечаем страницу классом «js», чтобы кнопка мобильного меню работала только при включённом JavaScript ?>
	<script>document.documentElement.className += ' js';</script>
	<?php wp_head(); ?>
</head>

<body id="top" <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Перейти к содержимому', 'ducktales-theme' ); ?></a>

<?php // Небо Даксбурга: силуэт города и пролетающий гидроплан пилота (чисто декоративный слой) ?>
<div class="sky" aria-hidden="true">
	<?php echo ducktales_sprite( 'skyline', 900, 'sky__skyline' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	<div class="sky__plane"><?php echo ducktales_sprite( 'seaplane', 130 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
</div>

<header class="site-header">
	<div class="site-header__inner">

		<?php // Логотип: свой из настроек или богатый селезень-путешественник по умолчанию ?>
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php
			if ( has_custom_logo() ) {
				echo wp_kses_post( get_custom_logo() );
			} else {
				echo ducktales_sprite( 'tycoon', 76, 'brand__logo' ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			?>
			<div class="brand__text">
				<?php // На главной название сайта — заголовок первого уровня, на остальных страницах — обычный абзац ?>
				<?php if ( is_front_page() && is_home() ) : ?>
					<h1 class="brand__title"><?php bloginfo( 'name' ); ?></h1>
				<?php else : ?>
					<p class="brand__title"><?php bloginfo( 'name' ); ?></p>
				<?php endif; ?>

				<?php $description = get_bloginfo( 'description', 'display' ); ?>
				<?php if ( $description ) : ?>
					<p class="brand__tagline"><?php echo esc_html( $description ); ?></p>
				<?php endif; ?>
			</div>
		</a>

		<?php // Кнопка меню для телефонов; логика — в assets/js/main.js ?>
		<button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-navigation">
			<?php esc_html_e( 'Меню', 'ducktales-theme' ); ?>
		</button>
	</div>
</header>

<?php // Меню-карта: пергамент с рваным краем, компасом и пунктирной тропой между пунктами ?>
<nav id="site-navigation" class="map-nav" aria-label="<?php esc_attr_e( 'Главное меню', 'ducktales-theme' ); ?>">
	<div class="map">
		<?php echo ducktales_sprite( 'compass', 52, 'map__compass' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<p class="map__title"><?php esc_html_e( 'Карта странствий', 'ducktales-theme' ); ?></p>
		<?php
		wp_nav_menu( array(
			'theme_location' => 'primary',
			'menu_id'        => 'primary-menu',
			'container'      => false,
			'depth'          => 1,
			'fallback_cb'    => 'ducktales_fallback_menu',
		) );
		?>
	</div>
</nav>

<?php // Лента с силуэтом города под меню ?>
<div class="skyline-band" aria-hidden="true">
	<?php echo ducktales_sprite( 'skyline', 1200, '' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
</div>

<main id="content" class="site-main">
