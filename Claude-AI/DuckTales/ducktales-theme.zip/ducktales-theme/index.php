<?php
/**
 * Главный шаблон: список постов в виде карточек-«экспедиций».
 * Он же обслуживает архивы (рубрики, метки, даты) и результаты поиска.
 *
 * @package DuckTalesTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="container">

	<?php if ( is_home() && ! is_paged() ) : ?>

		<?php // Приветствие у Хранилища — только на первой странице главной ?>
		<section class="hero" aria-labelledby="hero-title">
			<?php echo ducktales_sprite( 'vault', 140, 'hero__vault' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<div class="ledger">
				<h2 id="hero-title" class="ledger__title"><?php esc_html_e( 'Запись в гроссбухе', 'ducktales-theme' ); ?></h2>
				<p class="ledger__text"><?php esc_html_e( 'Каждая монета в этом хранилище честно заработана в опасной экспедиции. Выбирай любую запись и отправляйся следом.', 'ducktales-theme' ); ?></p>
			</div>
		</section>

	<?php elseif ( is_archive() ) : ?>

		<?php // Заголовок архива: рубрика («место»), метка, автор или дата ?>
		<header class="page-header">
			<?php the_archive_title( '<h1 class="page-header__title">', '</h1>' ); ?>
			<?php the_archive_description( '<p class="page-header__text">', '</p>' ); ?>
		</header>

	<?php elseif ( is_search() ) : ?>

		<header class="page-header">
			<h1 class="page-header__title">
				<?php
				/* translators: %s — поисковый запрос */
				printf( esc_html__( 'Поиск сокровищ: %s', 'ducktales-theme' ), '<span>' . esc_html( get_search_query() ) . '</span>' );
				?>
			</h1>
		</header>

	<?php endif; ?>

	<?php if ( have_posts() ) : ?>

		<div class="expeditions">
			<?php
			// Номер карточки нужен, чтобы чередовать иконки: мешок → камень → сундук → корона
			$card_index = 0;

			while ( have_posts() ) :
				the_post();
				?>

				<article id="post-<?php the_ID(); ?>" <?php post_class( 'expedition' ); ?>>

					<?php // Вкладка: номер экспедиции (это ID записи) ?>
					<p class="expedition__tab">
						<?php
						/* translators: %s — номер экспедиции */
						printf( esc_html__( 'Экспедиция № %s', 'ducktales-theme' ), esc_html( ducktales_expedition_number() ) );
						?>
					</p>

					<?php // Шапка карточки: место (рубрика) и иконка сокровища ?>
					<div class="expedition__head">
						<p class="expedition__place"><?php echo esc_html( ducktales_place_name() ); ?></p>
						<?php echo ducktales_treasure_icon( $card_index ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					</div>

					<?php // Миниатюра — только если она задана у записи ?>
					<?php if ( has_post_thumbnail() ) : ?>
						<a class="expedition__thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
							<?php the_post_thumbnail( 'ducktales-card' ); ?>
						</a>
					<?php endif; ?>

					<div class="expedition__body">
						<h2 class="expedition__title">
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</h2>

						<?php ducktales_entry_meta(); ?>

						<div class="expedition__excerpt"><?php the_excerpt(); ?></div>

						<a class="button" href="<?php the_permalink(); ?>">
							<?php esc_html_e( 'В экспедицию!', 'ducktales-theme' ); ?>
							<span class="screen-reader-text"><?php the_title(); ?></span>
						</a>
					</div>
				</article>

				<?php $card_index++; ?>
			<?php endwhile; ?>
		</div>

		<?php // Пагинация ?>
		<?php
		the_posts_pagination( array(
			'mid_size'           => 1,
			'prev_text'          => esc_html__( 'Назад', 'ducktales-theme' ),
			'next_text'          => esc_html__( 'Дальше', 'ducktales-theme' ),
			'screen_reader_text' => esc_html__( 'Страницы экспедиций', 'ducktales-theme' ),
		) );
		?>

	<?php else : ?>

		<?php // Ничего не найдено: записка от домработницы ?>
		<div class="note">
			<?php echo ducktales_sprite( 'butler', 96, 'note__icon' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<div class="ledger">
				<h2 class="ledger__title"><?php esc_html_e( 'Сокровищ не найдено', 'ducktales-theme' ); ?></h2>
				<p class="ledger__text"><?php echo esc_html( ducktales_housekeeper_note() ); ?></p>
			</div>
			<?php get_search_form(); ?>
		</div>

	<?php endif; ?>

</div>

<?php
get_footer();
