<?php
/**
 * Архивы: рубрики, метки, даты, авторы.
 *
 * @package SonicTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<?php if ( have_posts() ) : ?>

	<?php the_archive_title( '<h1 class="page-title">', '</h1>' ); ?>
	<?php the_archive_description( '<div class="archive-description">', '</div>' ); ?>

	<div class="zone-grid">
		<?php
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/content', 'zone' );
		endwhile;
		?>
	</div>

	<?php
	the_posts_pagination(
		array(
			'mid_size'           => 2,
			'prev_text'          => '◀ Назад',
			'next_text'          => 'Вперёд ▶',
			'screen_reader_text' => 'Навигация по зонам',
		)
	);
	?>

<?php else : ?>

	<section class="game-over">
		<h1 class="game-over__title">Зона пуста</h1>
		<p>В этом разделе пока нет записей.</p>
		<a class="btn-spring" href="<?php echo esc_url( home_url( '/' ) ); ?>">На главную</a>
	</section>

<?php endif; ?>

<?php
get_footer();
