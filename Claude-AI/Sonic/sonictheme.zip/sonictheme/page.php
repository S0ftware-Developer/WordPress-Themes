<?php
/**
 * Обычная страница (например, «Обо мне» или «Портфолио»).
 *
 * @package SonicTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	?>

	<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
		<header class="entry__header">
			<?php the_title( '<h1 class="entry__title">', '</h1>' ); ?>
		</header>

		<?php if ( has_post_thumbnail() ) : ?>
			<figure class="entry__thumb">
				<?php the_post_thumbnail( 'large' ); ?>
			</figure>
		<?php endif; ?>

		<div class="entry__content">
			<?php
			the_content();

			wp_link_pages(
				array(
					'before' => '<p class="page-links">Части страницы: ',
					'after'  => '</p>',
				)
			);
			?>
		</div>
	</article>

	<?php
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}

endwhile;

get_footer();
