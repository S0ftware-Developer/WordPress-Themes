<?php
/**
 * Страница 404 — «Game Over».
 *
 * @package SonicTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<section class="game-over">
	<h1 class="game-over__title">Game Over</h1>
	<p>Страница не найдена: возможно, она была удалена или адрес введён с ошибкой.</p>
	<p>Найдите нужное через поиск или вернитесь на главную.</p>

	<?php get_search_form(); ?>

	<a class="btn-spring blink" href="<?php echo esc_url( home_url( '/' ) ); ?>">Продолжить? На главную</a>
</section>

<?php
get_footer();
