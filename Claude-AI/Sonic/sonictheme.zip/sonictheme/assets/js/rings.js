/**
 * SonicTheme — скрипты темы.
 * 1. Сбор колец при скролле (IntersectionObserver).
 * 2. Активация чекпоинтов в футере.
 * 3. Переключатель мобильного меню.
 */
( function () {
	'use strict';

	var reduceMotion = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var hasObserver  = 'IntersectionObserver' in window;

	/* ---------------------------------------------------------------------
	   1. СБОР КОЛЕЦ
	   Когда карточка-зона попадает в экран, кольца «собираются» по очереди.
	   --------------------------------------------------------------------- */
	var cards = document.querySelectorAll( '.zone-card' );

	function collectRings( card ) {
		var rings = card.querySelectorAll( '.ring-icon' );

		card.classList.add( 'is-visited' );

		Array.prototype.forEach.call( rings, function ( ring, index ) {
			// Пауза между кольцами — 180 мс, чтобы получился «звон» подряд
			window.setTimeout( function () {
				ring.classList.add( 'is-collected' );
			}, reduceMotion ? 0 : 350 + index * 180 );
		} );
	}

	if ( cards.length ) {
		if ( ! hasObserver ) {
			// Старые браузеры: просто показываем всё сразу
			Array.prototype.forEach.call( cards, collectRings );
		} else {
			var cardObserver = new IntersectionObserver( function ( entries, observer ) {
				entries.forEach( function ( entry ) {
					if ( entry.isIntersecting ) {
						collectRings( entry.target );
						observer.unobserve( entry.target ); // собираем один раз
					}
				} );
			}, { threshold: 0.25 } );

			Array.prototype.forEach.call( cards, function ( card ) {
				cardObserver.observe( card );
			} );
		}
	}

	/* ---------------------------------------------------------------------
	   2. ЧЕКПОИНТЫ В ФУТЕРЕ
	   При появлении футера лампы загораются красным одна за другой.
	   Также срабатывают при наведении и фокусе.
	   --------------------------------------------------------------------- */
	var checkpoints = document.querySelectorAll( '.checkpoint' );

	function activate( point ) {
		point.classList.add( 'is-active' );
	}

	Array.prototype.forEach.call( checkpoints, function ( point ) {
		point.addEventListener( 'mouseenter', function () { activate( point ); } );
	} );

	var footerRow = document.querySelector( '.footer-checkpoints' );

	if ( footerRow && checkpoints.length ) {
		if ( ! hasObserver ) {
			Array.prototype.forEach.call( checkpoints, activate );
		} else {
			var footerObserver = new IntersectionObserver( function ( entries, observer ) {
				if ( entries[ 0 ].isIntersecting ) {
					Array.prototype.forEach.call( checkpoints, function ( point, index ) {
						window.setTimeout( function () {
							activate( point );
						}, reduceMotion ? 0 : index * 120 );
					} );
					observer.disconnect();
				}
			}, { threshold: 0.6 } );

			footerObserver.observe( footerRow );
		}
	}

	/* ---------------------------------------------------------------------
	   3. МОБИЛЬНОЕ МЕНЮ
	   --------------------------------------------------------------------- */
	var toggle = document.querySelector( '.menu-toggle' );
	var nav    = document.getElementById( 'site-navigation' );

	if ( toggle && nav ) {
		toggle.addEventListener( 'click', function () {
			var isOpen = nav.classList.toggle( 'is-open' );
			toggle.setAttribute( 'aria-expanded', isOpen ? 'true' : 'false' );
		} );
	}
} )();
