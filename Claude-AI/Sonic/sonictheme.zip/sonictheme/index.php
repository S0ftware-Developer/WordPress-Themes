<?php
/**
 * Главная страница и запасной шаблон.
 * Посты выводятся как карточки-«зоны».
 *
 * @package SonicTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<?php if ( is_home() && ! is_paged() ) : ?>
	<!-- Титульная карточка, как экран запуска уровня -->
	<section class="title-card">
		<p class="title-card__pre">Добро пожаловать в</p>
		<h1 class="title-card__name"><?php bloginfo( 'name' ); ?></h1>
		<p class="title-card__act">Зона 1 · Акт 1</p>
		<?php if ( get_bloginfo( 'description' ) ) : ?>
			<p class="title-card__text"><?php bloginfo( 'description' ); ?></p>
		<?php endif; ?>
	</section>
<?php elseif ( is_search() ) : ?>
	<h1 class="section-title">
		Результаты поиска: <?php echo esc_html( get_search_query() ); ?>
	</h1>
<?php else : ?>
	<h1 class="section-title">Все зоны</h1>
<?php endif; ?>

<?php if ( have_posts() ) : ?>

	<div class="zone-grid">
		<?php
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/content', 'zone' );
		endwhile;
		?>
	</div>

	<?php
	// Пагинация в виде «актов»: кольца с номерами страниц.
	the_posts_pagination(
		array(
			'mid_size'           => 2,
			'prev_text'          => '◀ Назад',
			'next_text'          => 'Вперёд ▶',
			'screen_reader_text' => 'Навигация по зонам',
		)
	);
	?>

<?php else : ?>

	<section class="game-over">
		<h2 class="game-over__title">Зона пуста</h2>
		<p>Записей пока нет. Попробуйте поискать по-другому.</p>
		<?php get_search_form(); ?>
	</section>

<?php endif; ?>

<?php
get_footer();
