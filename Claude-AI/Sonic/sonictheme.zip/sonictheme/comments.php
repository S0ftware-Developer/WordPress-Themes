<?php
/**
 * Шаблон комментариев.
 *
 * @package SonicTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Запись защищена паролем — комментарии не показываем.
if ( post_password_required() ) {
	return;
}
?>

<section id="comments" class="comments-area">

	<?php if ( have_comments() ) : ?>
		<h2 class="comments-title">
			Комментарии (<?php echo (int) get_comments_number(); ?>)
		</h2>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 48,
				)
			);
			?>
		</ol>

		<?php the_comments_navigation(); ?>

		<?php if ( ! comments_open() ) : ?>
			<p>Комментарии закрыты.</p>
		<?php endif; ?>
	<?php endif; ?>

	<?php
	comment_form(
		array(
			'title_reply'        => 'Оставить комментарий',
			'label_submit'       => 'Отправить',
			'comment_notes_before' => '',
		)
	);
	?>
</section>
