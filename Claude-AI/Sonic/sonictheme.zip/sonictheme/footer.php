<?php
/**
 * Футер: шипы, паттерн из чекпоинтов, земля «Зелёных холмов».
 *
 * @package SonicTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</main><!-- #content -->

<footer class="site-footer">

	<!-- Шипы на границе контента и футера -->
	<div class="spikes" aria-hidden="true"></div>

	<div class="site-footer__panel">

		<!-- Ряд чекпоинтов: JS «активирует» их при появлении футера -->
		<ul class="footer-checkpoints" aria-hidden="true">
			<?php for ( $i = 0; $i < 14; $i++ ) : ?>
				<li class="checkpoint">
					<span class="checkpoint__lamp"></span>
					<span class="checkpoint__pole"></span>
					<span class="checkpoint__base"></span>
				</li>
			<?php endfor; ?>
		</ul>

		<div class="site-footer__inner container">
			<p class="footer-copy">
				&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?>
				<?php bloginfo( 'name' ); ?>
			</p>

			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'footer',
					'menu_class'     => 'footer-menu',
					'container'      => false,
					'depth'          => 1,
					'fallback_cb'    => false,
				)
			);
			?>

			<p class="footer-note">
				Неофициальный фан-сайт. Sonic the Hedgehog — торговая марка SEGA.
				Сайт и тема SonicTheme никак не связаны с SEGA.
			</p>

			<!-- Подпись автора темы -->
			<p class="footer-credit">
				The website was made by Andrei Orlov:
				<a href="https://orlovandrei.space" target="_blank" rel="noopener">orlovandrei.space</a>
			</p>
		</div>
	</div>

	<!-- Земля: трава и шахматка -->
	<div class="footer-ground" aria-hidden="true"></div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
