<?php
/**
 * Форма поиска в пиксельном стиле.
 *
 * @package SonicTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$sonic_uid = wp_unique_id( 'search-' );
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $sonic_uid ); ?>">Поиск по сайту</label>
	<input
		type="search"
		id="<?php echo esc_attr( $sonic_uid ); ?>"
		name="s"
		placeholder="Что ищем?"
		value="<?php echo esc_attr( get_search_query() ); ?>">
	<button type="submit">Искать</button>
</form>
