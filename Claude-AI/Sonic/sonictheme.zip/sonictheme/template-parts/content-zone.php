<?php
/**
 * Карточка поста в виде «зоны».
 * Используется в index.php и archive.php внутри цикла.
 *
 * @package SonicTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$sonic_zone_no    = sonictheme_zone_number();
$sonic_rings      = sonictheme_ring_count( get_the_ID() );
$sonic_categories = get_the_category();
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'zone-card' ); ?>>

	<!-- Ярлыки: номер зоны и рубрика -->
	<header class="zone-card__head">
		<span class="zone-card__label">Зона <?php echo esc_html( str_pad( (string) $sonic_zone_no, 2, '0', STR_PAD_LEFT ) ); ?></span>
		<?php if ( ! empty( $sonic_categories ) ) : ?>
			<span class="zone-card__act"><?php echo esc_html( $sonic_categories[0]->name ); ?></span>
		<?php endif; ?>
	</header>

	<!-- Миниатюра или мини-пейзаж-заглушка -->
	<?php if ( has_post_thumbnail() ) : ?>
		<a class="zone-card__thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
			<?php the_post_thumbnail( 'sonic-zone' ); ?>
		</a>
	<?php else : ?>
		<a class="zone-card__thumb zone-card__thumb--empty" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true"></a>
	<?php endif; ?>

	<div class="zone-card__body">
		<?php
		the_title(
			'<h2 class="zone-card__title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">',
			'</a></h2>'
		);
		?>

		<ul class="zone-card__meta">
			<li><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time></li>
			<li>~<?php echo (int) sonictheme_reading_minutes(); ?> мин чтения</li>
			<?php if ( comments_open() || get_comments_number() ) : ?>
				<li>Комментарии: <?php echo (int) get_comments_number(); ?></li>
			<?php endif; ?>
		</ul>

		<div class="zone-card__excerpt">
			<?php the_excerpt(); ?>
		</div>

		<footer class="zone-card__footer">
			<!-- Кольца за прохождение зоны (собираются при скролле) -->
			<div class="zone-card__rings" role="img" aria-label="Колец за прохождение: <?php echo (int) $sonic_rings; ?>">
				<?php for ( $i = 0; $i < $sonic_rings; $i++ ) : ?>
					<span class="ring-icon" aria-hidden="true"></span>
				<?php endfor; ?>
			</div>

			<a class="btn-spring" href="<?php the_permalink(); ?>">
				Играть дальше
				<span class="screen-reader-text">: <?php the_title(); ?></span>
			</a>
		</footer>
	</div>
</article>
