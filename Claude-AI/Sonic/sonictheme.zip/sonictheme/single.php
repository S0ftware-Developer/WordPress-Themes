<?php
/**
 * Одиночная запись («акт»).
 *
 * @package SonicTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	?>

	<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>

		<header class="entry__header">
			<?php if ( has_category() ) : ?>
				<p class="entry__meta"><?php the_category( ', ' ); ?></p>
			<?php endif; ?>

			<?php the_title( '<h1 class="entry__title">', '</h1>' ); ?>

			<ul class="entry__meta">
				<li><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time></li>
				<li>Автор: <?php the_author(); ?></li>
				<li>~<?php echo (int) sonictheme_reading_minutes(); ?> мин чтения</li>
			</ul>
		</header>

		<?php if ( has_post_thumbnail() ) : ?>
			<figure class="entry__thumb">
				<?php the_post_thumbnail( 'large' ); ?>
			</figure>
		<?php endif; ?>

		<div class="entry__content">
			<?php
			the_content();

			wp_link_pages(
				array(
					'before' => '<p class="page-links">Части записи: ',
					'after'  => '</p>',
				)
			);
			?>
		</div>

		<?php if ( has_tag() ) : ?>
			<footer class="entry__footer">
				<?php the_tags( 'Метки: ', ', ', '' ); ?>
			</footer>
		<?php endif; ?>
	</article>

	<?php
	// Навигация между записями: прошлая / следующая зона.
	the_post_navigation(
		array(
			'prev_text' => '◀ Прошлая зона: %title',
			'next_text' => 'Следующая зона: %title ▶',
		)
	);

	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}

endwhile;

get_footer();
