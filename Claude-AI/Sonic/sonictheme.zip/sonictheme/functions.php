<?php
/**
 * SonicTheme — функции темы.
 *
 * Здесь: настройка поддержки возможностей WordPress, регистрация меню,
 * подключение стилей и скриптов, вспомогательные функции для карточек-зон.
 *
 * @package SonicTheme
 */

// Защита от прямого обращения к файлу.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SONICTHEME_VERSION', '1.0.0' );

/* --------------------------------------------------------------------------
   1. Настройка темы
   -------------------------------------------------------------------------- */
function sonictheme_setup() {
	// Перевод темы (папка /languages, если понадобится).
	load_theme_textdomain( 'sonictheme', get_template_directory() . '/languages' );

	// WordPress сам формирует <title>.
	add_theme_support( 'title-tag' );

	// RSS-ссылки в <head>.
	add_theme_support( 'automatic-feed-links' );

	// Миниатюры записей и свой размер для карточек-зон (16:9).
	add_theme_support( 'post-thumbnails' );
	add_image_size( 'sonic-zone', 640, 360, true );

	// Современная HTML5-разметка для форм, комментариев и галерей.
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);

	// Логотип, загружаемый в «Внешний вид → Настроить».
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 64,
			'width'       => 260,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);

	// Адаптивные встраиваемые видео (YouTube и др.).
	add_theme_support( 'responsive-embeds' );

	// Регистрация двух областей меню: главное (кольца) и футер.
	register_nav_menus(
		array(
			'primary' => 'Главное меню (кольца)',
			'footer'  => 'Меню в футере',
		)
	);
}
add_action( 'after_setup_theme', 'sonictheme_setup' );

/* Максимальная ширина контента (для встраиваемых объектов). */
function sonictheme_content_width() {
	$GLOBALS['content_width'] = 860;
}
add_action( 'after_setup_theme', 'sonictheme_content_width', 0 );

/* --------------------------------------------------------------------------
   2. Подключение стилей и скриптов
   -------------------------------------------------------------------------- */
function sonictheme_enqueue_assets() {
	// Пиксельный шрифт Press Start 2P (кириллица подтягивается автоматически).
	wp_enqueue_style(
		'sonictheme-fonts',
		'https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap',
		array(),
		null
	);

	// Основной стиль темы. filemtime() сбрасывает кэш браузера при правках.
	wp_enqueue_style(
		'sonictheme-style',
		get_stylesheet_uri(),
		array( 'sonictheme-fonts' ),
		filemtime( get_template_directory() . '/style.css' )
	);

	// Анимации: скоростные линии, сбор колец, чекпоинты.
	wp_enqueue_style(
		'sonictheme-animations',
		get_theme_file_uri( 'assets/css/animations.css' ),
		array( 'sonictheme-style' ),
		filemtime( get_template_directory() . '/assets/css/animations.css' )
	);

	// Скрипт сбора колец. Грузится в футере, с отложенным выполнением.
	wp_enqueue_script(
		'sonictheme-rings',
		get_theme_file_uri( 'assets/js/rings.js' ),
		array(),
		filemtime( get_template_directory() . '/assets/js/rings.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	// Ответы на комментарии (вложенные ветки).
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'sonictheme_enqueue_assets' );

/* Ускоряем загрузку шрифта: preconnect к серверам Google Fonts. */
function sonictheme_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		$urls[] = 'https://fonts.googleapis.com';
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'anonymous',
		);
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'sonictheme_resource_hints', 10, 2 );

/* Класс .js на <html>: стили анимаций включаются, только если скрипты работают. */
function sonictheme_js_class() {
	echo "<script>document.documentElement.className += ' js';</script>\n";
}
add_action( 'wp_head', 'sonictheme_js_class', 1 );

/* --------------------------------------------------------------------------
   3. Меню-запасной вариант (пока меню не создано в админке)
   -------------------------------------------------------------------------- */
function sonictheme_fallback_menu() {
	echo '<ul id="primary-menu" class="ring-menu">';
	echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">Старт</a></li>';
	wp_list_pages(
		array(
			'title_li' => '',
			'depth'    => 1,
		)
	);
	echo '</ul>';
}

/* --------------------------------------------------------------------------
   4. Выдержки
   -------------------------------------------------------------------------- */
function sonictheme_excerpt_length() {
	return 28; // слов в выдержке
}
add_filter( 'excerpt_length', 'sonictheme_excerpt_length' );

function sonictheme_excerpt_more() {
	return '…';
}
add_filter( 'excerpt_more', 'sonictheme_excerpt_more' );

/* --------------------------------------------------------------------------
   5. Помощники для карточек-зон
   -------------------------------------------------------------------------- */

/**
 * Порядковый номер зоны в ленте с учётом пагинации.
 * Вызывать внутри цикла.
 */
function sonictheme_zone_number() {
	global $wp_query;

	$paged    = max( 1, (int) get_query_var( 'paged' ) );
	$per_page = (int) get_query_var( 'posts_per_page' );

	if ( $per_page < 1 ) {
		$per_page = (int) get_option( 'posts_per_page', 10 );
	}

	return ( $paged - 1 ) * $per_page + (int) $wp_query->current_post + 1;
}

/**
 * Время чтения в минутах (около 180 слов в минуту).
 */
function sonictheme_reading_minutes( $post_id = null ) {
	$content = get_post_field( 'post_content', $post_id );
	$text    = wp_strip_all_tags( strip_shortcodes( $content ) );
	$parts   = preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY );
	$words   = is_array( $parts ) ? count( $parts ) : 0;

	return max( 1, (int) ceil( $words / 180 ) );
}

/**
 * Количество колец в карточке: 1 минута чтения = 1 кольцо, максимум 5.
 */
function sonictheme_ring_count( $post_id = null ) {
	return min( 5, sonictheme_reading_minutes( $post_id ) );
}
