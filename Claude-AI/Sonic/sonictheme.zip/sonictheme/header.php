<?php
/**
 * Шапка темы: логотип Sonic-стиля и меню в виде колец.
 *
 * @package SonicTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Фон со скоростными линиями (чисто декоративный) -->
<div class="speed-lines" aria-hidden="true"></div>

<a class="skip-link screen-reader-text" href="#content">Перейти к содержимому</a>

<header class="site-header">
	<div class="site-header__inner container">

		<!-- Логотип -->
		<div class="site-branding">
			<p class="site-title">
				<?php if ( has_custom_logo() ) : ?>
					<?php the_custom_logo(); ?>
				<?php else : ?>
					<a class="logo-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
						<img
							src="<?php echo esc_url( get_theme_file_uri( 'assets/img/logo-sonic.svg' ) ); ?>"
							alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"
							width="260" height="64">
					</a>
				<?php endif; ?>
			</p>

			<?php $sonic_description = get_bloginfo( 'description', 'display' ); ?>
			<?php if ( $sonic_description ) : ?>
				<p class="site-description"><?php echo esc_html( $sonic_description ); ?></p>
			<?php endif; ?>
		</div>

		<!-- Кнопка мобильного меню -->
		<button class="menu-toggle" type="button" aria-controls="primary-menu" aria-expanded="false">
			Меню
		</button>

		<!-- Навигация в виде колец -->
		<nav id="site-navigation" class="main-nav" aria-label="Главное меню">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'menu_id'        => 'primary-menu',
					'menu_class'     => 'ring-menu',
					'container'      => false,
					'fallback_cb'    => 'sonictheme_fallback_menu',
				)
			);
			?>
		</nav>
	</div>

	<!-- Шипы, свисающие под шапкой -->
	<div class="spikes spikes--down" aria-hidden="true"></div>
</header>

<main id="content" class="site-main container">
