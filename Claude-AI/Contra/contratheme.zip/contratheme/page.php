<?php
/**
 * Шаблон обычной страницы (например, «Обо мне» или «Портфолио»)
 *
 * @package ContraTheme
 */

get_header();
?>

<main id="primary" class="site-main container">

	<?php
	while ( have_posts() ) :
		the_post();
		?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>

			<header class="entry__header">
				<p class="entry__briefing">Личное дело</p>
				<h1 class="entry__title"><?php the_title(); ?></h1>
			</header>

			<?php if ( has_post_thumbnail() ) : ?>
				<figure class="entry__thumb">
					<?php the_post_thumbnail( 'large' ); ?>
				</figure>
			<?php endif; ?>

			<div class="entry__content">
				<?php
				the_content();

				wp_link_pages(
					array(
						'before' => '<nav class="page-links">Страницы: ',
						'after'  => '</nav>',
					)
				);
				?>
			</div>

		</article>

		<?php
		// Комментарии на страницах — только если включены в админке
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}

	endwhile;
	?>

</main>

<?php
get_footer();
