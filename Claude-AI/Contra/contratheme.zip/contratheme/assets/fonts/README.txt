Сюда нужно положить файл шрифта: PressStart2P.woff2

Шрифт «Press Start 2P» свободный (лицензия SIL OFL), поддерживает кириллицу.
Скачать: https://fonts.google.com/specimen/Press+Start+2P  (кнопка Get font),
затем конвертировать TTF в WOFF2 (например, через https://cloudconvert.com/ttf-to-woff2)
и сохранить как assets/fonts/PressStart2P.woff2.

Пока файла нет, тема сама подключает шрифт с Google Fonts (см. functions.php).
Как только файл появится, запросы к Google прекратятся.
