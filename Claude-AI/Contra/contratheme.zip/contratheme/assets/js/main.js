/**
 * ContraTheme — основной скрипт
 * Сейчас: мобильное меню и обратный отсчёт на странице 404.
 * Данные из PHP лежат в объекте window.ContraTheme (см. functions.php).
 */
( function () {
	'use strict';

	// 1. Меню-HUD на мобильных: кнопка «Меню» открывает и закрывает список
	var nav = document.querySelector( '.hud-nav' );
	var toggle = nav ? nav.querySelector( '.hud-toggle' ) : null;

	if ( toggle ) {
		toggle.addEventListener( 'click', function () {
			var isOpen = nav.classList.toggle( 'is-open' );
			toggle.setAttribute( 'aria-expanded', isOpen ? 'true' : 'false' );
		} );
	}

	// 2. Страница 404: обратный отсчёт «CONTINUE? 9… 0»
	var counter = document.getElementById( 'continue-count' );

	if ( counter ) {
		var left = parseInt( counter.textContent, 10 ) || 9;
		var timer = setInterval( function () {
			left -= 1;
			counter.textContent = String( Math.max( left, 0 ) );

			if ( left <= 0 ) {
				clearInterval( timer );
				// На нуле цифры краснеют — «время вышло»
				counter.parentElement.classList.add( 'is-over' );
			}
		}, 1000 );
	}

	// 3. Задел на будущее (см. Шаг 5):
	//    - звуки выстрелов по клику и при взрыве кнопок;
	//    - счётчик «жизней» посетителя (#contra-lives, data-lives).
} )();
