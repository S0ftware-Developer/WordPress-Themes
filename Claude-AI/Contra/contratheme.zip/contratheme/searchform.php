<?php
/**
 * Форма поиска. Своя разметка нужна, чтобы у кнопки работал взрыв
 * (у <input type="submit"> нельзя сделать псевдоэлементы).
 *
 * @package ContraTheme
 */
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label>
		<span class="screen-reader-text">Поиск:</span>
		<input type="search" class="search-field" placeholder="Поиск цели…" value="<?php echo esc_attr( get_search_query() ); ?>" name="s">
	</label>
	<button type="submit" class="btn btn-explosion search-submit">Огонь!</button>
</form>
