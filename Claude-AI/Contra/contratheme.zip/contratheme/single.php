<?php
/**
 * Шаблон отдельной записи: «брифинг миссии»
 *
 * @package ContraTheme
 */

get_header();
?>

<main id="primary" class="site-main container">

	<?php
	while ( have_posts() ) :
		the_post();

		$contratheme_weapon  = contratheme_get_weapon();
		$contratheme_minutes = contratheme_reading_minutes();
		$contratheme_level   = contratheme_difficulty();
		?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>

			<header class="entry__header">
				<p class="entry__briefing">Брифинг миссии №<?php echo esc_html( sprintf( '%03d', get_the_ID() ) ); ?></p>
				<h1 class="entry__title"><?php the_title(); ?></h1>

				<!-- Данные миссии -->
				<ul class="entry__meta">
					<li>
						<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
							<?php echo esc_html( get_the_date( 'd.m.Y' ) ); ?>
						</time>
					</li>
					<li>Командир: <?php the_author(); ?></li>
					<?php if ( has_category() ) : ?>
						<li>Зона: <?php the_category( ', ' ); ?></li>
					<?php endif; ?>
					<li>
						<?php
						echo esc_html(
							$contratheme_minutes . ' ' . contratheme_plural( $contratheme_minutes, array( 'минута', 'минуты', 'минут' ) )
						);
						?>
					</li>
					<li>Сложность: <?php echo contratheme_difficulty_html( $contratheme_level ); // phpcs:ignore WordPress.Security.EscapeOutput ?></li>
					<li class="entry__weapon">
						<img src="<?php echo esc_url( $contratheme_weapon['url'] ); ?>" width="48" height="33" alt="">
						<?php echo esc_html( $contratheme_weapon['name'] ); ?>
					</li>
				</ul>
			</header>

			<?php if ( has_post_thumbnail() ) : ?>
				<figure class="entry__thumb">
					<?php the_post_thumbnail( 'large' ); ?>
				</figure>
			<?php endif; ?>

			<div class="entry__content">
				<?php
				the_content();

				wp_link_pages(
					array(
						'before' => '<nav class="page-links">Страницы: ',
						'after'  => '</nav>',
					)
				);
				?>
			</div>

			<?php the_tags( '<p class="entry__tags">Позывные: ', ', ', '</p>' ); ?>

		</article>

		<?php
		// Переход между миссиями
		the_post_navigation(
			array(
				'prev_text'          => '<span class="nav-sub">Предыдущая миссия</span><span class="nav-title">%title</span>',
				'next_text'          => '<span class="nav-sub">Следующая миссия</span><span class="nav-title">%title</span>',
				'screen_reader_text' => 'Навигация по миссиям',
			)
		);

		// Комментарии
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}

	endwhile;
	?>

</main>

<?php
get_footer();
