<?php
/**
 * Комментарии: «эфир рации»
 *
 * @package ContraTheme
 */

// Запись под паролем — комментарии не показываем
if ( post_password_required() ) {
	return;
}
?>

<section id="comments" class="comments-area">

	<?php if ( have_comments() ) : ?>

		<h2 class="comments-title">
			<?php
			$contratheme_count = (int) get_comments_number();
			echo esc_html(
				'Эфир рации: ' . $contratheme_count . ' ' .
				contratheme_plural( $contratheme_count, array( 'сообщение', 'сообщения', 'сообщений' ) )
			);
			?>
		</h2>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 40,
				)
			);
			?>
		</ol>

		<?php
		the_comments_navigation(
			array(
				'prev_text'          => 'Старые сообщения',
				'next_text'          => 'Новые сообщения',
				'screen_reader_text' => 'Навигация по комментариям',
			)
		);
		?>

	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() ) : ?>
		<p class="no-comments">Связь закрыта: новые сообщения не принимаются.</p>
	<?php endif; ?>

	<?php
	// Форма: кнопка отправки — <button>, чтобы работал взрыв
	comment_form(
		array(
			'title_reply'          => 'Выйти на связь',
			'title_reply_to'       => 'Ответить бойцу %s',
			'cancel_reply_link'    => 'Отмена',
			'label_submit'         => 'Отправить',
			'comment_notes_before' => '',
			'submit_button'        => '<button name="%1$s" type="submit" id="%2$s" class="%3$s btn btn-explosion">%4$s</button>',
		)
	);
	?>

</section>
