<?php
/**
 * Шапка сайта: HUD-полоса (очки, жизни), логотип CONTRA и меню
 *
 * @package ContraTheme
 */

// «Очки игрока» = количество опубликованных записей × 1000
$contratheme_counts    = wp_count_posts();
$contratheme_published = isset( $contratheme_counts->publish ) ? (int) $contratheme_counts->publish : 0;
$contratheme_score     = sprintf( '%06d', $contratheme_published * 1000 );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php
// wp_body_open() появилась в WordPress 5.2 — для старых версий вызываем хук напрямую
if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
} else {
	do_action( 'wp_body_open' );
}
?>

<a class="skip-link screen-reader-text" href="#primary">Перейти к содержимому</a>

<div id="page" class="site">

	<header id="masthead" class="site-header">

		<!-- Верхняя HUD-полоса, как в аркадном автомате -->
		<div class="hud-bar" aria-hidden="true">
			<div class="container hud-bar__inner">
				<span class="hud-item hud-item--player">
					<span class="hud-label">1P</span>
					<span class="hud-value"><?php echo esc_html( $contratheme_score ); ?></span>
				</span>

				<span class="hud-item">
					<span class="hud-label">HI</span>
					<span class="hud-value">100000</span>
				</span>

				<!-- Жизни: 3 медали. Пригодятся для счётчика жизней (см. main.js) -->
				<span class="hud-item">
					<span class="hud-label">ЖИЗНИ</span>
					<span class="hud-lives" id="contra-lives" data-lives="3">
						<?php for ( $i = 0; $i < 3; $i++ ) : ?>
							<span class="medal"></span>
						<?php endfor; ?>
					</span>
				</span>
			</div>
		</div>

		<div class="container header-inner">

			<!-- Логотип «CONTRA» и пиксельный солдат -->
			<div class="site-logo">
				<?php if ( has_custom_logo() ) : ?>
					<?php the_custom_logo(); ?>
				<?php else : ?>
					<a class="site-logo__link" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) . ' — на главную' ); ?>">
						<img class="site-logo__sprite" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/soldier.svg' ) ); ?>" width="48" height="66" alt="">
						<span class="site-logo__words">
							<span class="site-logo__text">CONTRA</span>
							<span class="site-logo__tagline">ИГРОВОЙ БЛОГ / ЭКШЕН / ПОРТФОЛИО</span>
						</span>
					</a>
				<?php endif; ?>
			</div>

			<!-- Главное меню в виде игрового HUD -->
			<nav id="site-navigation" class="hud-nav" aria-label="Главное меню">
				<button class="hud-toggle" type="button" aria-controls="primary-menu" aria-expanded="false">Меню</button>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'menu_id'        => 'primary-menu',
						'menu_class'     => 'hud-menu',
						'container'      => false,
						'depth'          => 1,
						'fallback_cb'    => 'contratheme_fallback_menu',
					)
				);
				?>
			</nav>

		</div>
	</header>

	<div id="content" class="site-content">
