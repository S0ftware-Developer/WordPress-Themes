<?php
/**
 * Футер: джунгли, наш боец против вражеской базы, копирайт
 *
 * @package ContraTheme
 */
?>
	</div><!-- #content -->

	<footer id="colophon" class="site-footer">

		<!-- Сцена: боец слева стреляет по базе справа (пуля — в effects.css) -->
		<div class="footer-scene" aria-hidden="true">
			<img class="footer-scene__soldier" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/soldier.svg' ) ); ?>" width="80" height="110" alt="">
			<img class="footer-scene__base" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/base.svg' ) ); ?>" width="256" height="128" alt="">
			<div class="footer-scene__ground"></div>
		</div>

		<div class="footer-inner">
			<div class="container">

				<?php
				// Меню футера выводится, только если оно назначено в админке
				wp_nav_menu(
					array(
						'theme_location' => 'footer',
						'menu_class'     => 'footer-menu',
						'container'      => 'nav',
						'container_aria_label' => 'Меню в футере',
						'depth'          => 1,
						'fallback_cb'    => false,
					)
				);
				?>

				<p class="footer-copy">
					&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?>
					<?php bloginfo( 'name' ); ?>. Все права защищены.
				</p>
				<p class="footer-insert-coin">
					The website was made by Andrei Orlov: orlovandrei.space. Тема ContraTheme. Insert coin.
				</p>

			</div>
		</div>

	</footer>

</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
