<?php
/**
 * Функции и настройки темы ContraTheme
 *
 * @package ContraTheme
 */

// Защита от прямого обращения к файлу
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Версия темы берётся из style.css — так браузеры обновляют кэш при апдейтах
define( 'CONTRATHEME_VERSION', wp_get_theme()->get( 'Version' ) ? wp_get_theme()->get( 'Version' ) : '1.0.0' );


/* ==========================================================================
   1. Базовая настройка темы
   ========================================================================== */
if ( ! function_exists( 'contratheme_setup' ) ) :
	function contratheme_setup() {

		// WordPress сам формирует <title> страницы
		add_theme_support( 'title-tag' );

		// RSS-ссылки в <head>
		add_theme_support( 'automatic-feed-links' );

		// Миниатюры записей (обложки миссий)
		add_theme_support( 'post-thumbnails' );
		add_image_size( 'mission-thumb', 800, 450, true ); // 16:9 с обрезкой

		// Современная HTML5-разметка для форм, комментариев и галерей
		add_theme_support(
			'html5',
			array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
		);

		// Свой логотип через «Внешний вид → Настроить» (по умолчанию — CONTRA)
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 80,
				'width'       => 320,
				'flex-height' => true,
				'flex-width'  => true,
			)
		);

		// Адаптивные видео и встраивания
		add_theme_support( 'responsive-embeds' );

		// Два места для меню: HUD в шапке и ссылки в футере
		register_nav_menus(
			array(
				'primary' => 'Главное меню (HUD в шапке)',
				'footer'  => 'Меню в футере',
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'contratheme_setup' );

/**
 * Ширина контента — нужна WordPress для корректных размеров встраиваний.
 */
function contratheme_content_width() {
	$GLOBALS['content_width'] = 800;
}
add_action( 'after_setup_theme', 'contratheme_content_width', 0 );


/* ==========================================================================
   2. Подключение стилей и скриптов
   ========================================================================== */
function contratheme_scripts() {

	$font_file = get_theme_file_path( 'assets/fonts/PressStart2P.woff2' );

	if ( file_exists( $font_file ) ) {
		// Шрифт лежит в теме — подключаем локально, без запросов к Google
		$font_css = "@font-face{font-family:'Press Start 2P';font-style:normal;font-weight:400;font-display:swap;src:url('"
			. esc_url_raw( get_theme_file_uri( 'assets/fonts/PressStart2P.woff2' ) )
			. "') format('woff2');}";

		wp_register_style( 'contratheme-font', false, array(), CONTRATHEME_VERSION );
		wp_enqueue_style( 'contratheme-font' );
		wp_add_inline_style( 'contratheme-font', $font_css );
	} else {
		// Запасной вариант: файла шрифта нет — берём его из Google Fonts
		wp_enqueue_style(
			'contratheme-font',
			'https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap',
			array(),
			null
		);
	}

	// Основной стиль темы (style.css)
	wp_enqueue_style( 'contratheme-style', get_stylesheet_uri(), array( 'contratheme-font' ), CONTRATHEME_VERSION );

	// Анимации: взрывы, мерцание, пули
	wp_enqueue_style(
		'contratheme-effects',
		get_theme_file_uri( 'assets/css/effects.css' ),
		array( 'contratheme-style' ),
		CONTRATHEME_VERSION
	);

	// Скрипт темы: мобильное меню, отсчёт на 404. Грузится в футере, с defer
	wp_enqueue_script(
		'contratheme-main',
		get_theme_file_uri( 'assets/js/main.js' ),
		array(),
		CONTRATHEME_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	// Данные для скрипта (пригодятся для звуков и счётчика жизней)
	wp_localize_script(
		'contratheme-main',
		'ContraTheme',
		array(
			'homeUrl'  => home_url( '/' ),
			'themeUrl' => get_theme_file_uri(),
			'lives'    => 3,
		)
	);

	// Скрипт ответа на комментарии — только там, где он нужен
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'contratheme_scripts' );


/* ==========================================================================
   3. Выдержки (краткое описание миссии в карточке)
   ========================================================================== */
add_filter(
	'excerpt_length',
	function () {
		return 24; // слов в выдержке
	}
);

add_filter(
	'excerpt_more',
	function () {
		return '…';
	}
);


/* ==========================================================================
   4. Меню-заглушка, пока в админке не создано меню
   ========================================================================== */
function contratheme_fallback_menu() {
	$home_class = ( is_home() || is_front_page() ) ? ' class="current-menu-item"' : '';

	echo '<ul id="primary-menu" class="hud-menu">';
	echo '<li' . $home_class . '><a href="' . esc_url( home_url( '/' ) ) . '">Штаб</a></li>'; // phpcs:ignore WordPress.Security.EscapeOutput
	wp_list_pages(
		array(
			'title_li' => '',
			'depth'    => 1,
			'number'   => 5,
		)
	);
	echo '</ul>';
}


/* ==========================================================================
   5. Вспомогательные функции для карточек-миссий
   ========================================================================== */

/**
 * Русское склонение: 1 минута, 2 минуты, 5 минут.
 *
 * @param int   $n     Число.
 * @param array $forms Три формы: array( 'минута', 'минуты', 'минут' ).
 * @return string
 */
function contratheme_plural( $n, $forms ) {
	$n  = abs( (int) $n ) % 100;
	$n1 = $n % 10;

	if ( $n > 10 && $n < 20 ) {
		return $forms[2];
	}
	if ( $n1 > 1 && $n1 < 5 ) {
		return $forms[1];
	}
	if ( 1 === $n1 ) {
		return $forms[0];
	}
	return $forms[2];
}

/**
 * Оружие миссии. Берётся из произвольного поля «contra_weapon»
 * (значения m, s, l, f). Если поле пустое — выбирается по ID записи.
 *
 * @param int|null $post_id ID записи.
 * @return array name, letter, slug, url.
 */
function contratheme_get_weapon( $post_id = null ) {
	$post_id = $post_id ? (int) $post_id : (int) get_the_ID();

	$weapons = array(
		'm' => array(
			'slug'   => 'rifle',
			'letter' => 'M',
			'name'   => 'Пулемёт',
		),
		's' => array(
			'slug'   => 'spread',
			'letter' => 'S',
			'name'   => 'Разброс',
		),
		'l' => array(
			'slug'   => 'laser',
			'letter' => 'L',
			'name'   => 'Лазер',
		),
		'f' => array(
			'slug'   => 'fire',
			'letter' => 'F',
			'name'   => 'Огнемёт',
		),
	);

	$keys   = array_keys( $weapons );
	$custom = strtolower( (string) get_post_meta( $post_id, 'contra_weapon', true ) );
	$key    = isset( $weapons[ $custom ] ) ? $custom : $keys[ $post_id % count( $keys ) ];

	$weapon        = $weapons[ $key ];
	$weapon['url'] = get_theme_file_uri( 'assets/img/weapons/' . $weapon['slug'] . '.svg' );

	return $weapon;
}

/**
 * Время «прохождения» миссии = время чтения записи в минутах.
 *
 * @param int|null $post_id ID записи.
 * @return int
 */
function contratheme_reading_minutes( $post_id = null ) {
	$post = get_post( $post_id );
	if ( ! $post ) {
		return 1;
	}

	$text  = wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
	$words = preg_split( '/\s+/u', trim( $text ), -1, PREG_SPLIT_NO_EMPTY );
	$count = is_array( $words ) ? count( $words ) : 0;

	return max( 1, (int) ceil( $count / 180 ) ); // ~180 слов в минуту
}

/**
 * Сложность миссии от 1 до 3 — зависит от длины записи.
 *
 * @param int|null $post_id ID записи.
 * @return int
 */
function contratheme_difficulty( $post_id = null ) {
	$minutes = contratheme_reading_minutes( $post_id );

	if ( $minutes <= 3 ) {
		return 1;
	}
	if ( $minutes <= 8 ) {
		return 2;
	}
	return 3;
}

/**
 * Разметка «пиксельных квадратов» сложности (уже экранирована).
 *
 * @param int $level Уровень 1–3.
 * @return string
 */
function contratheme_difficulty_html( $level ) {
	$html = '<span class="difficulty" role="img" aria-label="' . esc_attr( 'Сложность: ' . $level . ' из 3' ) . '">';
	for ( $i = 1; $i <= 3; $i++ ) {
		$html .= '<i class="difficulty__pip' . ( $i <= $level ? ' is-on' : '' ) . '"></i>';
	}
	return $html . '</span>';
}

/**
 * Сквозной номер миссии в списке с учётом страницы пагинации.
 *
 * @return int
 */
function contratheme_mission_number() {
	global $wp_query;

	$paged    = max( 1, (int) get_query_var( 'paged' ) );
	$per_page = (int) get_query_var( 'posts_per_page' );
	if ( $per_page < 1 ) {
		$per_page = (int) get_option( 'posts_per_page' );
	}

	return ( $paged - 1 ) * $per_page + (int) $wp_query->current_post + 1;
}
