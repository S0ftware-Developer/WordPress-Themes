<?php
/**
 * Главный шаблон: посты выводятся как карточки-миссии.
 * Используется для главной, архивов, рубрик и результатов поиска.
 *
 * @package ContraTheme
 */

get_header();
?>

<main id="primary" class="site-main container">

	<!-- Заголовок «этапа» зависит от типа страницы -->
	<header class="stage-title">
		<?php if ( is_search() ) : ?>

			<span class="stage-title__label">Разведка</span>
			<h1>Результаты поиска: «<?php echo esc_html( get_search_query() ); ?>»</h1>

		<?php elseif ( is_archive() ) : ?>

			<span class="stage-title__label">Архив миссий</span>
			<?php the_archive_title( '<h1>', '</h1>' ); ?>
			<?php the_archive_description( '<p class="stage-title__sub">', '</p>' ); ?>

		<?php else : ?>

			<span class="stage-title__label">Stage 1</span>
			<h1>Джунгли: выбери миссию</h1>
			<p class="stage-title__sub">
				Свежие записи блога — это задания от командования.
				Жми «В бой», чтобы открыть брифинг.
			</p>

		<?php endif; ?>
	</header>

	<?php if ( have_posts() ) : ?>

		<div class="mission-grid">
			<?php
			while ( have_posts() ) :
				the_post();
				// Карточка миссии лежит в отдельном шаблоне
				get_template_part( 'template-parts/content', 'mission' );
			endwhile;
			?>
		</div>

		<?php
		// Пагинация: «Назад / 1 2 3 / Дальше»
		the_posts_pagination(
			array(
				'mid_size'           => 1,
				'prev_text'          => 'Назад',
				'next_text'          => 'Дальше',
				'screen_reader_text' => 'Навигация по миссиям',
			)
		);
		?>

	<?php else : ?>

		<!-- Ничего не найдено -->
		<section class="game-over">
			<h2 class="game-over__title">Миссий нет</h2>
			<p class="game-over__text">
				Здесь пока пусто. Командование готовит новые задания — загляни позже
				или попробуй поискать другую цель.
			</p>
			<?php get_search_form(); ?>
		</section>

	<?php endif; ?>

</main>

<?php
get_footer();
