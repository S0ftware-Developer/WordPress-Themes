<?php
/**
 * Страница 404: вместо ошибки — экран «GAME OVER»
 *
 * @package ContraTheme
 */

get_header();
?>

<main id="primary" class="site-main container">

	<section class="game-over">
		<h1 class="game-over__title">Game over</h1>

		<p class="game-over__text">
			Ошибка 404: такой миссии не существует. Возможно, вражескую базу уже
			взорвали, а может, ты свернул не туда в джунглях.
		</p>

		<!-- Обратный отсчёт: анимируется в main.js -->
		<p class="game-over__continue">
			Continue? <span class="game-over__count" id="continue-count">9</span>
		</p>

		<a class="btn btn-explosion" href="<?php echo esc_url( home_url( '/' ) ); ?>">Продолжить</a>

		<?php get_search_form(); ?>
	</section>

</main>

<?php
get_footer();
