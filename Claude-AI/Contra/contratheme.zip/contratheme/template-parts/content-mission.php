<?php
/**
 * Карточка-миссия: одна запись в списке.
 * Подключается из index.php через get_template_part().
 *
 * @package ContraTheme
 */

$contratheme_weapon  = contratheme_get_weapon();       // оружие миссии (иконка M / S / L / F)
$contratheme_number  = contratheme_mission_number();   // номер миссии в списке
$contratheme_minutes = contratheme_reading_minutes();  // время «прохождения»
$contratheme_level   = contratheme_difficulty();       // сложность 1–3
$contratheme_cats    = get_the_category();

// Первая запись на главной — «босс уровня»
$contratheme_is_boss = ( 1 === $contratheme_number && is_home() && ! is_paged() );
$contratheme_class   = 'mission-card' . ( $contratheme_is_boss ? ' mission-card--boss' : '' );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $contratheme_class ); ?>>

	<!-- Верхняя планка: номер миссии и капсула с оружием -->
	<header class="mission-card__bar">
		<span class="mission-card__num">Миссия <?php echo esc_html( sprintf( '%02d', $contratheme_number ) ); ?></span>

		<?php if ( $contratheme_is_boss ) : ?>
			<span class="mission-card__flag">Босс</span>
		<?php elseif ( is_sticky() ) : ?>
			<span class="mission-card__flag">Главная цель</span>
		<?php endif; ?>

		<img
			class="mission-card__weapon"
			src="<?php echo esc_url( $contratheme_weapon['url'] ); ?>"
			width="48" height="33" alt=""
			title="<?php echo esc_attr( 'Оружие: ' . $contratheme_weapon['name'] . ' (' . $contratheme_weapon['letter'] . ')' ); ?>"
		>
	</header>

	<!-- Обложка миссии. Нет миниатюры — рисуется вражеская база -->
	<a
		class="mission-card__thumb<?php echo has_post_thumbnail() ? '' : ' is-placeholder'; ?>"
		href="<?php the_permalink(); ?>"
		tabindex="-1"
		aria-hidden="true"
	>
		<?php
		if ( has_post_thumbnail() ) {
			the_post_thumbnail( 'mission-thumb', array( 'alt' => '' ) );
		}
		?>
	</a>

	<div class="mission-card__body">

		<h2 class="mission-card__title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h2>

		<!-- Данные миссии: дата, зона (рубрика), время -->
		<ul class="mission-card__meta">
			<li>
				<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
					<?php echo esc_html( get_the_date( 'd.m.Y' ) ); ?>
				</time>
			</li>
			<?php if ( ! empty( $contratheme_cats ) ) : ?>
				<li>Зона: <?php echo esc_html( $contratheme_cats[0]->name ); ?></li>
			<?php endif; ?>
			<li>
				<?php
				echo esc_html(
					$contratheme_minutes . ' ' . contratheme_plural( $contratheme_minutes, array( 'минута', 'минуты', 'минут' ) )
				);
				?>
			</li>
		</ul>

		<div class="mission-card__excerpt">
			<?php the_excerpt(); ?>
		</div>

		<footer class="mission-card__footer">
			<?php echo contratheme_difficulty_html( $contratheme_level ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

			<!-- Кнопка со взрывом при наведении (стили — effects.css) -->
			<a
				class="btn btn-explosion"
				href="<?php the_permalink(); ?>"
				aria-label="<?php echo esc_attr( 'В бой: ' . wp_strip_all_tags( get_the_title() ) ); ?>"
			>В бой!</a>
		</footer>

	</div>
</article>
