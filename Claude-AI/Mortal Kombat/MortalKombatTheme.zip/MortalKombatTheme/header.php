<?php
/**
 * Шапка сайта: логотип MK и меню-арена
 *
 * @package MortalKombatTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// На главной заголовок сайта — <h1>, на остальных страницах — <p> (правило SEO)
$mk_title_tag = ( is_front_page() && is_home() ) ? 'h1' : 'p';
$mk_dragon    = get_template_directory_uri() . '/assets/images/dragon.svg';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php
// wp_body_open() есть только в WordPress 5.2+, поэтому проверяем наличие функции
if ( function_exists( 'wp_body_open' ) ) {
    wp_body_open();
} else {
    do_action( 'wp_body_open' );
}
?>

<a class="skip-link screen-reader-text" href="#main">Перейти к содержимому</a>

<header class="site-header">
    <!-- Молнии по краям шапки (анимируются в CSS) -->
    <span class="bolt bolt--1" aria-hidden="true"></span>
    <span class="bolt bolt--2" aria-hidden="true"></span>

    <div class="header-inner">

        <!-- Логотип MK: медальон с драконом + большие буквы -->
        <a class="mk-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="На главную">
            <?php if ( has_custom_logo() ) : ?>
                <?php
                // Если в настройках загружен свой логотип — показываем его
                echo wp_get_attachment_image( get_theme_mod( 'custom_logo' ), 'full', false, array( 'class' => 'site-logo-badge' ) );
                ?>
            <?php else : ?>
                <img class="site-logo-badge" src="<?php echo esc_url( $mk_dragon ); ?>" alt="" width="96" height="96">
            <?php endif; ?>
            <span class="mk-logo-text" aria-hidden="true">MK</span>
        </a>

        <<?php echo $mk_title_tag; ?> class="site-title">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
        </<?php echo $mk_title_tag; ?>>

        <?php if ( get_bloginfo( 'description' ) ) : ?>
            <p class="site-description"><?php bloginfo( 'description' ); ?></p>
        <?php endif; ?>
    </div>

    <!-- Навигация в виде арены -->
    <nav id="arena-nav" class="arena-nav" aria-label="Главное меню">
        <button class="menu-toggle" aria-controls="arena-nav" aria-expanded="false">☰ ВЫБЕРИ АРЕНУ</button>
        <?php
        wp_nav_menu( array(
            'theme_location' => 'primary',
            'container'      => false,
            'menu_class'     => 'arena-menu',
            'depth'          => 1,                  // без выпадающих подменю: проще и надёжнее на мобильных
            'fallback_cb'    => 'mk_fallback_menu', // запасное меню, если основное не создано
        ) );
        ?>
    </nav>
</header>
