/**
 * Скрипты темы MortalKombatTheme
 * Сейчас: переключение мобильного меню.
 * Позже (Шаг 5): звуки ударов и счётчик побед.
 */
(function () {
    'use strict';

    var toggle = document.querySelector('.menu-toggle');
    var nav = document.getElementById('arena-nav');

    if (!toggle || !nav) {
        return;
    }

    // По клику открываем или закрываем меню на маленьких экранах
    toggle.addEventListener('click', function () {
        var isOpen = nav.classList.toggle('is-open');
        toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
})();
