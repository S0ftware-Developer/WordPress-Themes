<?php
/**
 * Главный шаблон: список постов в виде карточек-бойцов.
 * Также обслуживает архивы, поиск, а пока нет single.php и page.php,
 * показывает и одиночные записи/страницы.
 *
 * @package MortalKombatTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();
?>

<main id="main" class="arena-main">

<?php if ( is_singular() ) : ?>

    <?php /* ---------- Одиночная запись или страница ---------- */ ?>
    <?php while ( have_posts() ) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class( 'arena-single' ); ?>>
            <header class="arena-heading">
                <h1 class="arena-title"><?php the_title(); ?></h1>
            </header>
            <div class="entry-content">
                <?php the_content(); ?>
            </div>
        </article>
    <?php endwhile; ?>

<?php elseif ( have_posts() ) : ?>

    <?php /* ---------- Список бойцов ---------- */ ?>
    <header class="arena-heading">
        <?php if ( is_search() ) : ?>
            <h1 class="arena-title">Поиск бойца: <?php echo esc_html( get_search_query() ); ?></h1>
        <?php elseif ( is_archive() ) : ?>
            <h1 class="arena-title"><?php echo wp_kses_post( get_the_archive_title() ); ?></h1>
        <?php else : ?>
            <h2 class="arena-title">ВЫБЕРИ СВОЕГО БОЙЦА</h2>
            <p class="arena-subtitle">Свежие записи из турнира</p>
        <?php endif; ?>
    </header>

    <div class="fighters-grid">
        <?php
        while ( have_posts() ) :
            the_post();
            // Разметка одной карточки вынесена в отдельный файл
            get_template_part( 'template-parts/content', 'fighter' );
        endwhile;
        ?>
    </div>

    <?php
    // Постраничная навигация «Раунды»
    the_posts_pagination( array(
        'mid_size'  => 1,
        'prev_text' => '◀ Назад',
        'next_text' => 'Вперёд ▶',
    ) );
    ?>

<?php else : ?>

    <?php /* ---------- Ничего не найдено ---------- */ ?>
    <section class="arena-message">
        <h2>FINISH HIM!</h2>
        <p>Бойцов не найдено. Арена пуста.</p>
        <a class="btn-fatality" href="<?php echo esc_url( home_url( '/' ) ); ?>" data-hover="FATALITY">
            <span>НА ГЛАВНУЮ</span>
        </a>
    </section>

<?php endif; ?>

</main>

<?php
get_footer();
