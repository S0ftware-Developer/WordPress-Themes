<?php
/**
 * Футер: дракон, молнии, меню, копирайт и подпись автора
 *
 * @package MortalKombatTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<footer class="site-footer">
    <!-- Молнии по бокам футера -->
    <span class="bolt bolt--1" aria-hidden="true"></span>
    <span class="bolt bolt--2" aria-hidden="true"></span>

    <!-- Дракон -->
    <img class="footer-dragon"
         src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/dragon.svg' ); ?>"
         alt="" width="150" height="150" loading="lazy">

    <p class="footer-flourish">GAME OVER? НЕТ. ПРОДОЛЖЕНИЕ СЛЕДУЕТ…</p>

    <?php
    // Меню футера (выводится, только если назначено в админке)
    if ( has_nav_menu( 'footer' ) ) {
        wp_nav_menu( array(
            'theme_location'  => 'footer',
            'container'       => 'nav',
            'container_class' => 'footer-nav',
            'menu_class'      => 'footer-menu',
            'depth'           => 1,
        ) );
    }
    ?>

    <p class="footer-copy">
        &copy; <?php echo esc_html( gmdate( 'Y' ) ); ?>
        <?php bloginfo( 'name' ); ?>. Все права защищены.
    </p>

    <!-- Подпись автора сайта (обязательный элемент футера) -->
    <p class="footer-credit">
        The website was made by Andrei Orlov:
        <a href="https://orlovandrei.space" target="_blank" rel="noopener">orlovandrei.space</a>
    </p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
