<?php
/**
 * Функции и настройки темы MortalKombatTheme
 *
 * @package MortalKombatTheme
 */

// Защита от прямого открытия файла
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Версия темы — используется для сброса кэша CSS/JS при обновлении
define( 'MK_THEME_VERSION', '1.0.0' );

/**
 * Базовая настройка темы: поддержка функций WordPress и меню
 */
function mk_theme_setup() {
    // WordPress сам формирует <title> страницы
    add_theme_support( 'title-tag' );

    // Миниатюры записей — это «портреты бойцов»
    add_theme_support( 'post-thumbnails' );

    // Размер портрета 400×500 с обрезкой по центру (соотношение 4:5)
    add_image_size( 'mk-portrait', 400, 500, true );

    // Современная HTML5-разметка для стандартных элементов
    add_theme_support( 'html5', array(
        'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script',
    ) );

    // RSS-ссылки в <head>
    add_theme_support( 'automatic-feed-links' );

    // Свой логотип через «Внешний вид → Настроить → Айдентика сайта»
    add_theme_support( 'custom-logo', array(
        'height'      => 96,
        'width'       => 96,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    // Две области меню: главное (арена) и футер
    register_nav_menus( array(
        'primary' => 'Главное меню (Арена)',
        'footer'  => 'Меню в футере',
    ) );
}
add_action( 'after_setup_theme', 'mk_theme_setup' );

/**
 * Подключение шрифта, стилей и скриптов
 */
function mk_enqueue_assets() {
    $dir_uri  = get_template_directory_uri();
    $dir_path = get_template_directory();

    // --- Шрифт «Press Start 2P» ---
    // Вариант 1 (рекомендуется для ЕС/GDPR): локальный файл в assets/fonts/
    // Вариант 2: если файла нет, подтягиваем шрифт с Google Fonts
    $local_font = $dir_path . '/assets/fonts/PressStart2P-Regular.woff2';

    if ( file_exists( $local_font ) ) {
        wp_register_style( 'mk-font', false, array(), MK_THEME_VERSION );
        wp_enqueue_style( 'mk-font' );
        wp_add_inline_style(
            'mk-font',
            "@font-face{font-family:'Press Start 2P';font-style:normal;font-weight:400;font-display:swap;src:url('" .
            esc_url( $dir_uri . '/assets/fonts/PressStart2P-Regular.woff2' ) . "') format('woff2');}"
        );
    } else {
        wp_enqueue_style(
            'mk-google-font',
            'https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap',
            array(),
            null
        );
    }

    // --- Основные стили темы (style.css) ---
    wp_enqueue_style( 'mk-style', get_stylesheet_uri(), array(), MK_THEME_VERSION );

    // --- Анимация Fatality для кнопок ---
    wp_enqueue_style(
        'mk-fatality',
        $dir_uri . '/assets/css/fatality.css',
        array( 'mk-style' ),
        MK_THEME_VERSION
    );

    // --- Скрипт темы (в подвале страницы) ---
    wp_enqueue_script(
        'mk-main',
        $dir_uri . '/assets/js/main.js',
        array(),
        MK_THEME_VERSION,
        true
    );
}
add_action( 'wp_enqueue_scripts', 'mk_enqueue_assets' );

/**
 * Длина отрывка поста: 20 слов
 */
function mk_excerpt_length( $length ) {
    return 20;
}
add_filter( 'excerpt_length', 'mk_excerpt_length' );

/**
 * Окончание отрывка вместо [...]
 */
function mk_excerpt_more( $more ) {
    return '…';
}
add_filter( 'excerpt_more', 'mk_excerpt_more' );

/**
 * Запасное меню — показывается, пока меню не создано в админке
 */
function mk_fallback_menu() {
    echo '<ul class="arena-menu">';
    echo '<li class="current-menu-item"><a href="' . esc_url( home_url( '/' ) ) . '">Главная</a></li>';

    // Подсказку видит только администратор
    if ( current_user_can( 'edit_theme_options' ) ) {
        echo '<li><a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '">Создать меню</a></li>';
    }
    echo '</ul>';
}
