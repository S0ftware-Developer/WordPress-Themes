<?php
/**
 * Карточка бойца: один пост в списке
 *
 * @package MortalKombatTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// «Стиль боя» = первая рубрика поста
$mk_cats  = get_the_category();
$mk_style = ! empty( $mk_cats ) ? $mk_cats[0]->name : 'Без стиля';

// «Сила» бойца: декоративное число 40–99, зависящее от ID поста.
// Так у каждой карточки своя полоска здоровья, но она не меняется между загрузками.
$mk_power = 40 + ( get_the_ID() % 60 );

// «Победы» = число комментариев
$mk_wins = (int) get_comments_number();
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'fighter-card' ); ?>>

    <!-- Портрет бойца -->
    <a class="fighter-portrait" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
        <?php if ( has_post_thumbnail() ) : ?>
            <?php the_post_thumbnail( 'mk-portrait', array( 'loading' => 'lazy' ) ); ?>
        <?php else : ?>
            <!-- Нет миниатюры — показываем силуэт «неизвестного бойца» -->
            <span class="fighter-silhouette">?</span>
        <?php endif; ?>
    </a>

    <div class="fighter-info">
        <p class="fighter-style">Стиль: <?php echo esc_html( $mk_style ); ?></p>

        <h2 class="fighter-name">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h2>

        <p class="fighter-excerpt"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>

        <!-- Полоска здоровья -->
        <p class="health-label">СИЛА</p>
        <div class="health-bar" aria-hidden="true">
            <span style="--power: <?php echo (int) $mk_power; ?>%;"></span>
        </div>

        <div class="fighter-meta">
            <span><?php echo esc_html( get_the_date( 'd.m.Y' ) ); ?></span>
            <span>ПОБЕД: <?php echo (int) $mk_wins; ?></span>
        </div>

        <!-- Кнопка с анимацией Fatality (текст меняется при наведении) -->
        <a class="btn-fatality" href="<?php the_permalink(); ?>" data-hover="FATALITY">
            <span>В БОЙ!</span>
        </a>
    </div>
</article>
