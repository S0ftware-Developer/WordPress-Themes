<?php
/**
 * Шаблон отдельной записи — «прохождение уровня»
 *
 * @package MarioTheme
 */

get_header();
?>

<div class="site-wrap" id="content">
    <div class="site-main-area">

        <main class="site-main">

            <?php
            while ( have_posts() ) :
                the_post();
                ?>

                <article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>

                    <p class="coin-badge">
                        <span class="coin-icon" aria-hidden="true"></span>
                        <?php echo esc_html( mariotheme_post_score() ); ?> МОНЕТ
                    </p>

                    <h1 class="entry-title"><?php the_title(); ?></h1>

                    <?php mariotheme_entry_meta(); ?>

                    <?php if ( has_post_thumbnail() ) : ?>
                        <div class="block-level__thumb">
                            <?php the_post_thumbnail( 'large' ); ?>
                        </div>
                    <?php endif; ?>

                    <div class="entry-content">
                        <?php
                        the_content();

                        wp_link_pages( array(
                            'before' => '<nav class="pagination">Страницы: ',
                            'after'  => '</nav>',
                        ) );
                        ?>
                    </div>

                    <?php
                    $mario_cats = get_the_category_list( ', ' );
                    if ( $mario_cats ) {
                        echo '<p class="block-level__meta">Миры: ' . wp_kses_post( $mario_cats ) . '</p>';
                    }
                    the_tags( '<p class="block-level__meta">Метки: ', ', ', '</p>' );
                    ?>

                </article>

                <!-- Переход к соседним уровням -->
                <nav class="post-nav" aria-label="Соседние записи">
                    <?php previous_post_link( '%link', '&larr; %title' ); ?>
                    <?php next_post_link( '%link', '%title &rarr;' ); ?>
                </nav>

                <?php
                if ( comments_open() || get_comments_number() ) {
                    comments_template();
                }

            endwhile;
            ?>

        </main>

        <?php get_sidebar(); ?>

    </div>
</div>

<?php
get_footer();
