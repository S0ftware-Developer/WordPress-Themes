/**
 * MarioTheme — интерактивные мелочи: появление уровней, мобильное меню
 *
 * Файл не зависит от jQuery и подключается в футере.
 */
( function () {
    'use strict';

    // Снимаем класс no-js: JavaScript работает, можно включать анимации
    document.body.classList.remove( 'no-js' );

    var reducedMotion = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

    /**
     * Карточки-уровни «выезжают» на экран при прокрутке до них
     */
    function initReveal() {
        var levels = document.querySelectorAll( '.block-level' );

        if ( ! levels.length ) {
            return;
        }

        if ( ! ( 'IntersectionObserver' in window ) || reducedMotion ) {
            levels.forEach( function ( level ) {
                level.classList.add( 'is-revealed' );
            } );
            return;
        }

        var observer = new IntersectionObserver( function ( entries ) {
            entries.forEach( function ( entry, i ) {
                if ( ! entry.isIntersecting ) {
                    return;
                }

                // Уровни появляются по очереди, с небольшой задержкой
                setTimeout( function () {
                    entry.target.classList.add( 'is-revealed' );
                }, i * 80 );

                observer.unobserve( entry.target );
            } );
        }, { threshold: 0.15 } );

        levels.forEach( function ( level ) {
            observer.observe( level );
        } );
    }

    /**
     * Мобильное меню: кнопка «МЕНЮ» раскрывает список пунктов
     */
    function initNav() {
        var toggle = document.getElementById( 'nav-toggle' );
        var nav = document.getElementById( 'primary-menu' );

        if ( ! toggle || ! nav ) {
            return;
        }

        toggle.addEventListener( 'click', function () {
            var isOpen = nav.classList.toggle( 'is-open' );
            toggle.setAttribute( 'aria-expanded', isOpen ? 'true' : 'false' );
        } );
    }

    /**
     * Клик по кнопке «Пройти уровень» — короткий подскок перед переходом.
     * Небольшая задержка перехода даёт анимации доиграть.
     */
    function initButtonJump() {
        if ( reducedMotion ) {
            return;
        }

        document.querySelectorAll( 'a.btn' ).forEach( function ( btn ) {
            btn.addEventListener( 'click', function ( event ) {
                if ( btn.dataset.jumped ) {
                    return; // переход уже разрешён, не блокируем повторно
                }

                event.preventDefault();
                btn.dataset.jumped = 'true';
                btn.style.animation = 'mario-jump 0.4s ease-out';

                setTimeout( function () {
                    window.location.href = btn.href;
                }, 250 );
            } );
        } );
    }

    initReveal();
    initNav();
    initButtonJump();

}() );
