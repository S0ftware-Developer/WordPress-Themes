<?php
/**
 * Страница 404 — оформлена как провал в пропасть между блоками
 *
 * @package MarioTheme
 */

get_header();
?>

<div class="site-wrap" id="content">

    <section class="game-over">

        <p class="game-over__code">404</p>

        <h1 class="game-over__title">УРОВЕНЬ НЕ НАЙДЕН</h1>

        <p>Похоже, здесь пропасть: такой страницы на сайте нет.<br>
           Возможно, ссылка устарела или в адресе опечатка.</p>

        <!-- Земля с провалом посередине -->
        <div class="pit" aria-hidden="true">
            <span></span>
            <span class="gap"></span>
            <span class="gap"></span>
            <span></span>
        </div>

        <p>
            <a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">Вернуться на уровень 1-1</a>
        </p>

        <div style="max-width: 420px; margin: 40px auto 0;">
            <p>Или найдите нужное через поиск:</p>
            <?php get_search_form(); ?>
        </div>

    </section>

</div>

<?php
get_footer();
