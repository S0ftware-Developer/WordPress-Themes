<?php
/**
 * Главный шаблон: лента записей, где каждая запись — «уровень»
 *
 * @package MarioTheme
 */

get_header();
?>

<div class="site-wrap" id="content">
    <div class="site-main-area">

        <main class="site-main">

            <?php if ( is_home() && ! is_front_page() ) : ?>
                <h1 class="page-title"><?php single_post_title(); ?></h1>
            <?php elseif ( is_archive() ) : ?>
                <h1 class="page-title"><?php the_archive_title(); ?></h1>
            <?php elseif ( is_search() ) : ?>
                <h1 class="page-title">Поиск: <?php echo esc_html( get_search_query() ); ?></h1>
            <?php endif; ?>

            <?php if ( have_posts() ) : ?>

                <div class="levels-field">

                    <?php
                    $mario_position = 0;

                    while ( have_posts() ) :
                        the_post();
                        ?>

                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'block-level' ); ?>>

                            <!-- Номер уровня в формате «мир-этап», как в оригинале -->
                            <span class="level-flag">
                                УРОВЕНЬ <?php echo esc_html( mariotheme_level_label( $mario_position ) ); ?>
                            </span>

                            <?php if ( has_post_thumbnail() ) : ?>
                                <a class="block-level__thumb" href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail( 'mario-level', array( 'loading' => 'lazy' ) ); ?>
                                </a>
                            <?php endif; ?>

                            <h2 class="block-level__title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>

                            <?php mariotheme_entry_meta(); ?>

                            <div class="block-level__excerpt">
                                <?php the_excerpt(); ?>
                            </div>

                            <!-- Счётчик монет вместо обычной рубрики -->
                            <p class="coin-badge">
                                <span class="coin-icon" aria-hidden="true"></span>
                                <?php echo esc_html( mariotheme_post_score() ); ?> МОНЕТ
                            </p>

                            <p>
                                <a class="btn" href="<?php the_permalink(); ?>">
                                    Пройти уровень
                                    <span class="screen-reader-text"><?php the_title(); ?></span>
                                </a>
                            </p>

                        </article>

                        <?php $mario_position++; ?>

                    <?php endwhile; ?>

                </div><!-- .levels-field -->

                <!-- Постраничная навигация -->
                <nav class="pagination" aria-label="Навигация по страницам">
                    <?php
                    echo paginate_links( array(
                        'prev_text' => '&larr; Пред. мир',
                        'next_text' => 'След. мир &rarr;',
                    ) );
                    ?>
                </nav>

            <?php else : ?>

                <div class="entry">
                    <h2>Уровни ещё не построены</h2>
                    <p>Опубликуйте первую запись в админке — и здесь появится уровень 1-1.</p>
                    <?php get_search_form(); ?>
                </div>

            <?php endif; ?>

        </main>

        <?php get_sidebar(); ?>

    </div>
</div>

<?php
get_footer();
