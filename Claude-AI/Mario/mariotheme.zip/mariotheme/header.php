<?php
/**
 * Шапка сайта: логотип «M» на жёлтом блоке и меню из кирпичных блоков
 *
 * @package MarioTheme
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Фоновая сцена: небо с плывущими облаками, рисуется целиком на CSS -->
<div class="sky-scene" aria-hidden="true">
    <div class="cloud" style="width:120px;height:50px;top:8%;left:10%;animation-duration:38s;"></div>
    <div class="cloud" style="width:90px;height:38px;top:18%;left:55%;animation-duration:52s;animation-delay:-10s;"></div>
    <div class="cloud" style="width:150px;height:60px;top:4%;left:75%;animation-duration:65s;animation-delay:-25s;"></div>
    <div class="hill" style="left:-60px;"></div>
    <div class="hill" style="left:60%;width:260px;height:120px;"></div>
</div>

<!-- Ссылка для навигации с клавиатуры -->
<a class="screen-reader-text" href="#content">Перейти к содержимому</a>

<header class="site-header" id="top">
    <div class="header-inner">

        <div class="brand">
            <?php if ( has_custom_logo() ) : ?>
                <?php the_custom_logo(); ?>
            <?php else : ?>
                <!-- Логотип: буква «M» на блоке-монете -->
                <div class="logo-m" aria-hidden="true">M</div>
            <?php endif; ?>

            <div class="brand__text">
                <?php if ( is_front_page() ) : ?>
                    <h1 class="site-title">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
                    </h1>
                <?php else : ?>
                    <p class="site-title">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
                    </p>
                <?php endif; ?>

                <?php $mario_description = get_bloginfo( 'description', 'display' ); ?>
                <?php if ( $mario_description ) : ?>
                    <p class="site-description"><?php echo esc_html( $mario_description ); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Кнопка раскрытия меню на мобильных -->
        <button class="nav-toggle" id="nav-toggle" aria-expanded="false" aria-controls="primary-menu">
            МЕНЮ
        </button>

        <!-- Меню оформлено как ряд кирпичных блоков уровня -->
        <nav class="main-nav" id="primary-menu" aria-label="Главное меню">
            <?php
            if ( has_nav_menu( 'primary' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'depth'          => 2,
                ) );
            } else {
                wp_page_menu( array(
                    'menu_class' => 'fallback-menu',
                    'before'     => '',
                    'after'      => '',
                ) );
            }
            ?>
        </nav>

    </div>
</header>
