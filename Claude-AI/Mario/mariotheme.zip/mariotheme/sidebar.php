<?php
/**
 * Сайдбар: HUD со статистикой и виджеты
 *
 * @package MarioTheme
 */
?>

<aside class="sidebar" role="complementary">

    <!-- HUD в духе счётчика очков/монет/мира из верхней панели игры -->
    <section class="widget">
        <h3 class="widget-title">Статистика</h3>
        <div class="hud">
            <div>
                <span>МОНЕТЫ</span>
                <strong><?php echo esc_html( wp_count_posts()->publish ); ?>0</strong>
            </div>
            <div>
                <span>МИР</span>
                <strong>1-1</strong>
            </div>
            <div>
                <span>ЖИЗНИ</span>
                <strong>&times;3</strong>
            </div>
        </div>
    </section>

    <?php if ( is_active_sidebar( 'sidebar-main' ) ) : ?>

        <?php dynamic_sidebar( 'sidebar-main' ); ?>

    <?php else : ?>

        <!-- Запасное наполнение, если виджеты ещё не добавлены -->
        <section class="widget">
            <h3 class="widget-title">Поиск</h3>
            <?php get_search_form(); ?>
        </section>

        <section class="widget">
            <h3 class="widget-title">Свежие уровни</h3>
            <ul>
                <?php
                $mario_recent = new WP_Query( array(
                    'posts_per_page'      => 5,
                    'ignore_sticky_posts' => true,
                ) );

                while ( $mario_recent->have_posts() ) :
                    $mario_recent->the_post();
                    ?>
                    <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                <?php
                endwhile;

                wp_reset_postdata();
                ?>
            </ul>
        </section>

        <section class="widget">
            <h3 class="widget-title">Миры (рубрики)</h3>
            <ul>
                <?php wp_list_categories( array( 'title_li' => '' ) ); ?>
            </ul>
        </section>

    <?php endif; ?>

</aside>
