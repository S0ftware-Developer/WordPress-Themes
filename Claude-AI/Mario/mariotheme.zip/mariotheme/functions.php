<?php
/**
 * MarioTheme — функции и настройки темы
 *
 * @package MarioTheme
 */

// Прямой вызов файла запрещён
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Базовая поддержка возможностей WordPress
 */
function mariotheme_setup() {

    // Тег <title> генерирует WordPress
    add_theme_support( 'title-tag' );

    // Миниатюры записей (обложки уровней)
    add_theme_support( 'post-thumbnails' );

    // Корректная HTML5-разметка для встроенных элементов
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ) );

    // Кастомный логотип (заменит блок «M», если загружен свой)
    add_theme_support( 'custom-logo', array(
        'height'      => 52,
        'width'       => 52,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'responsive-embeds' );

    // Размер обложки для карточки-уровня
    add_image_size( 'mario-level', 600, 340, true );

    // Регистрируем два меню
    register_nav_menus( array(
        'primary' => 'Главное меню (шапка)',
        'footer'  => 'Меню в футере',
    ) );

    // Файлы перевода
    load_theme_textdomain( 'mariotheme', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'mariotheme_setup' );

/**
 * Подключение стилей и скриптов
 */
function mariotheme_assets() {

    $theme_version = wp_get_theme()->get( 'Version' );

    // Пиксельные шрифты с Google Fonts:
    // Press Start 2P — заголовки и HUD, VT323 — основной текст записей
    wp_enqueue_style(
        'mariotheme-fonts',
        'https://fonts.googleapis.com/css2?family=Press+Start+2P&family=VT323&display=swap',
        array(),
        null
    );

    // Главный файл темы (обязательный style.css)
    wp_enqueue_style(
        'mariotheme-style',
        get_stylesheet_uri(),
        array( 'mariotheme-fonts' ),
        $theme_version
    );

    // Дополнительные анимации: облака, монеты, появление карточек
    wp_enqueue_style(
        'mariotheme-extra',
        get_template_directory_uri() . '/assets/css/mario.css',
        array( 'mariotheme-style' ),
        $theme_version
    );

    // Скрипт эффектов
    wp_enqueue_script(
        'mariotheme-script',
        get_template_directory_uri() . '/assets/js/mario.js',
        array(),
        $theme_version,
        true // подключаем в футере
    );

    // Скрипт ответов на комментарии на страницах записей
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'mariotheme_assets' );

/**
 * Регистрация областей виджетов
 */
function mariotheme_widgets_init() {

    register_sidebar( array(
        'name'          => 'Сайдбар',
        'id'            => 'sidebar-main',
        'description'   => 'Боковая панель на главной и в записях.',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => 'Футер',
        'id'            => 'footer-widgets',
        'description'   => 'Виджеты в нижней части сайта.',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'mariotheme_widgets_init' );

/**
 * Длина анонса — 24 слова, чтобы карточки-уровни были одного размера
 */
function mariotheme_excerpt_length( $length ) {
    return 24;
}
add_filter( 'excerpt_length', 'mariotheme_excerpt_length' );

/**
 * Многоточие в анонсе заменяем на ретро-троеточие
 */
function mariotheme_excerpt_more( $more ) {
    return ' ...';
}
add_filter( 'excerpt_more', 'mariotheme_excerpt_more' );

/**
 * Номер «уровня» для записи в ленте — формат 1-1, 1-2, 1-3...
 * Мир (первая цифра) меняется каждые четыре записи, как в оригинале.
 *
 * @param int $position Порядковый номер записи в цикле (начиная с 0).
 * @return string Строка вида «1-3».
 */
function mariotheme_level_label( $position ) {
    $world = (int) floor( $position / 4 ) + 1;
    $stage = ( $position % 4 ) + 1;

    return $world . '-' . $stage;
}

/**
 * «Очки» записи — шуточный счётчик монет вместо обычного числа просмотров.
 * Считается по количеству слов и комментариев.
 *
 * @return int
 */
function mariotheme_post_score() {
    $words    = str_word_count( wp_strip_all_tags( get_the_content() ) );
    $comments = absint( get_comments_number() );

    return ( $words * 10 ) + ( $comments * 100 );
}

/**
 * Добавляем класс no-js в <body>.
 * JavaScript снимет его при загрузке — так стили деградируют корректно.
 */
function mariotheme_body_classes( $classes ) {
    $classes[] = 'no-js';
    return $classes;
}
add_filter( 'body_class', 'mariotheme_body_classes' );

/**
 * Мета-строка записи: дата, автор
 */
function mariotheme_entry_meta() {
    printf(
        '<p class="block-level__meta">%1$s &middot; %2$s</p>',
        esc_html( get_the_date( 'd.m.Y' ) ),
        esc_html( get_the_author() )
    );
}
