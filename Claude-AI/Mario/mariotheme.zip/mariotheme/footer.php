<?php
/**
 * Футер сайта с паттерном земли и рядом кирпичных блоков
 *
 * @package MarioTheme
 */
?>

<footer class="site-footer">

    <!-- Ряд кирпичных блоков вдоль верхней кромки футера -->
    <div class="footer-bricks" aria-hidden="true">
        <?php for ( $i = 0; $i < 20; $i++ ) : ?>
            <span></span>
        <?php endfor; ?>
    </div>

    <?php if ( is_active_sidebar( 'footer-widgets' ) ) : ?>
        <div class="footer-widgets site-wrap">
            <?php dynamic_sidebar( 'footer-widgets' ); ?>
        </div>
    <?php endif; ?>

    <div class="footer-inner">

        <p>
            &copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?>
            <?php bloginfo( 'name' ); ?>. The website was made by Andrei Orlov: orlovandrei.space
        </p>

        <?php if ( has_nav_menu( 'footer' ) ) : ?>
            <nav aria-label="Меню в футере">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'footer',
                    'container'      => false,
                    'depth'          => 1,
                ) );
                ?>
            </nav>
        <?php endif; ?>

        <p><a href="#top">&#9650; Наверх по трубе</a></p>

    </div>

</footer>

<?php wp_footer(); ?>
</body>
</html>
