<?php
/**
 * Сайдбар: панель «Следующая фигура» и виджеты
 *
 * @package TetrisTheme
 */
?>

<aside class="sidebar" role="complementary">

    <!-- Фирменная панель Тетриса: предпросмотр следующей фигуры.
         Сюда позже можно встроить мини-игру. -->
    <section class="widget next-piece">
        <h3 class="widget-title">Следующая</h3>
        <div class="next-piece__grid" aria-hidden="true">
            <span></span><span></span><span></span><span></span>
        </div>
        <p>Новые записи — каждую неделю.</p>
    </section>

    <?php if ( is_active_sidebar( 'sidebar-main' ) ) : ?>

        <?php dynamic_sidebar( 'sidebar-main' ); ?>

    <?php else : ?>

        <!-- Запасное наполнение, если виджеты ещё не добавлены -->
        <section class="widget">
            <h3 class="widget-title">Поиск</h3>
            <?php get_search_form(); ?>
        </section>

        <section class="widget">
            <h3 class="widget-title">Свежие записи</h3>
            <ul>
                <?php
                $tetris_recent = new WP_Query( array(
                    'posts_per_page'      => 5,
                    'ignore_sticky_posts' => true,
                ) );

                while ( $tetris_recent->have_posts() ) :
                    $tetris_recent->the_post();
                    ?>
                    <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                <?php
                endwhile;

                // Обязательно возвращаем глобальный $post на место
                wp_reset_postdata();
                ?>
            </ul>
        </section>

        <section class="widget">
            <h3 class="widget-title">Рубрики</h3>
            <ul>
                <?php wp_list_categories( array( 'title_li' => '' ) ); ?>
            </ul>
        </section>

    <?php endif; ?>

</aside>
