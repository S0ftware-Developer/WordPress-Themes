/**
 * TetrisTheme — фоновые падающие фигуры и эффект приземления карточек
 *
 * Файл не зависит от jQuery и подключается в футере.
 */
( function () {
    'use strict';

    // Снимаем класс no-js: JavaScript работает, можно включать анимации
    document.body.classList.remove( 'no-js' );

    /**
     * Формы семи тетрамино.
     * Каждая описана как сетка: cols — ширина в клетках,
     * cells — массив 0/1, где 1 — закрашенная клетка.
     */
    var SHAPES = [
        { cols: 4, cells: [ 1, 1, 1, 1 ] },                   // I
        { cols: 2, cells: [ 1, 1, 1, 1 ] },                   // O
        { cols: 3, cells: [ 0, 1, 0, 1, 1, 1 ] },             // T
        { cols: 3, cells: [ 0, 1, 1, 1, 1, 0 ] },             // S
        { cols: 3, cells: [ 1, 1, 0, 0, 1, 1 ] },             // Z
        { cols: 3, cells: [ 1, 0, 0, 1, 1, 1 ] },             // J
        { cols: 3, cells: [ 0, 0, 1, 1, 1, 1 ] }              // L
    ];

    // Палитра приходит из PHP через wp_localize_script
    var COLORS = ( window.TetrisThemeData && window.TetrisThemeData.colors ) || [
        '#00f0f0', '#f0f000', '#a000f0', '#00f000', '#f00000', '#0000f0', '#f0a000'
    ];

    // Пользователь просил меньше движения — фон остаётся статичным
    var reducedMotion = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

    /**
     * Создаёт одну падающую фигуру и добавляет её в фоновый слой
     *
     * @param {HTMLElement} field Контейнер игрового поля
     * @param {number}      index Порядковый номер (влияет на задержку)
     */
    function createPiece( field, index ) {
        var shape = SHAPES[ Math.floor( Math.random() * SHAPES.length ) ];
        var color = COLORS[ Math.floor( Math.random() * COLORS.length ) ];

        var piece = document.createElement( 'div' );
        piece.className = 'falling-piece';
        piece.style.setProperty( '--piece', color );
        piece.style.gridTemplateColumns = 'repeat(' + shape.cols + ', var(--cell))';

        // Позиция по горизонтали: случайная колонка поля
        piece.style.left = Math.random() * 90 + '%';

        // Скорость и задержка разные, чтобы фигуры не падали синхронно
        piece.style.animationDuration = ( 14 + Math.random() * 16 ).toFixed( 1 ) + 's';
        piece.style.animationDelay = ( index * 2.5 ).toFixed( 1 ) + 's';

        // Рисуем клетки фигуры; пустые ячейки остаются прозрачными
        shape.cells.forEach( function ( filled ) {
            var cell = document.createElement( 'span' );
            if ( ! filled ) {
                cell.style.background = 'transparent';
                cell.style.border = '0';
            }
            piece.appendChild( cell );
        } );

        field.appendChild( piece );
    }

    /**
     * Запускает фоновый «снегопад» из тетрамино
     */
    function initBackground() {
        var field = document.getElementById( 'tetris-field' );

        if ( ! field || reducedMotion ) {
            return;
        }

        // Восемь фигур — достаточно для наполненного фона без нагрузки на CPU
        for ( var i = 0; i < 8; i++ ) {
            createPiece( field, i );
        }
    }

    /**
     * Карточки записей «приземляются» при попадании в зону видимости
     */
    function initLanding() {
        var posts = document.querySelectorAll( '.block-post' );

        if ( ! posts.length ) {
            return;
        }

        // Если IntersectionObserver недоступен — просто показываем карточки
        if ( ! ( 'IntersectionObserver' in window ) || reducedMotion ) {
            posts.forEach( function ( post ) {
                post.classList.add( 'is-landed' );
            } );
            return;
        }

        var observer = new IntersectionObserver( function ( entries ) {
            entries.forEach( function ( entry, i ) {
                if ( ! entry.isIntersecting ) {
                    return;
                }

                // Небольшая задержка между соседними блоками — падают по очереди
                setTimeout( function () {
                    entry.target.classList.add( 'is-landed' );
                }, i * 90 );

                observer.unobserve( entry.target );
            } );
        }, { threshold: 0.15 } );

        posts.forEach( function ( post ) {
            observer.observe( post );
        } );
    }

    /**
     * Мобильное меню: кнопка раскрывает список пунктов
     */
    function initNav() {
        var toggle = document.getElementById( 'nav-toggle' );
        var nav = document.getElementById( 'primary-menu' );

        if ( ! toggle || ! nav ) {
            return;
        }

        toggle.addEventListener( 'click', function () {
            var isOpen = nav.classList.toggle( 'is-open' );
            toggle.setAttribute( 'aria-expanded', isOpen ? 'true' : 'false' );
        } );
    }

    // Запуск после построения DOM
    initBackground();
    initLanding();
    initNav();

}() );
