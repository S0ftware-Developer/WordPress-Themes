<?php
/**
 * Главный шаблон: лента записей, где каждый пост — блок-тетрамино
 *
 * @package TetrisTheme
 */

get_header();
?>

<div class="site-wrap" id="content">
    <div class="site-main-area">

        <main class="site-main">

            <?php if ( is_home() && ! is_front_page() ) : ?>
                <h1 class="page-title"><?php single_post_title(); ?></h1>
            <?php elseif ( is_archive() ) : ?>
                <h1 class="page-title"><?php the_archive_title(); ?></h1>
            <?php elseif ( is_search() ) : ?>
                <h1 class="page-title">Поиск: <?php echo esc_html( get_search_query() ); ?></h1>
            <?php endif; ?>

            <?php if ( have_posts() ) : ?>

                <div class="posts-field">

                    <?php
                    while ( have_posts() ) :
                        the_post();

                        // Цвет фигуры для этой записи — постоянный, зависит от ID
                        $piece_color = tetristheme_piece_color();
                        ?>

                        <article id="post-<?php the_ID(); ?>"
                                 <?php post_class( 'block-post' ); ?>
                                 style="--piece: <?php echo esc_attr( $piece_color ); ?>">

                            <!-- Счётчик очков вместо привычной рубрики -->
                            <span class="score-badge">
                                SCORE <?php echo esc_html( tetristheme_post_score() ); ?>
                            </span>

                            <?php if ( has_post_thumbnail() ) : ?>
                                <a class="block-post__thumb" href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail( 'tetris-block', array( 'loading' => 'lazy' ) ); ?>
                                </a>
                            <?php endif; ?>

                            <h2 class="block-post__title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>

                            <?php tetristheme_entry_meta(); ?>

                            <div class="block-post__excerpt">
                                <?php the_excerpt(); ?>
                            </div>

                            <a class="btn" href="<?php the_permalink(); ?>">
                                Читать
                                <span class="screen-reader-text"><?php the_title(); ?></span>
                            </a>

                        </article>

                    <?php endwhile; ?>

                </div><!-- .posts-field -->

                <!-- Постраничная навигация -->
                <nav class="pagination" aria-label="Навигация по страницам">
                    <?php
                    echo paginate_links( array(
                        'prev_text' => '&larr; Назад',
                        'next_text' => 'Вперёд &rarr;',
                    ) );
                    ?>
                </nav>

            <?php else : ?>

                <div class="entry" style="--piece: #f00000">
                    <h2>Пока пусто</h2>
                    <p>Здесь ещё не упало ни одного блока. Опубликуйте первую запись в админке — и она появится в ленте.</p>
                    <?php get_search_form(); ?>
                </div>

            <?php endif; ?>

        </main>

        <?php get_sidebar(); ?>

    </div>
</div>

<?php
get_footer();
