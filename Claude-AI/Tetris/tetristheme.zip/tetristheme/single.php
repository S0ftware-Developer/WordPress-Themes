<?php
/**
 * Шаблон отдельной записи
 *
 * @package TetrisTheme
 */

get_header();
?>

<div class="site-wrap" id="content">
    <div class="site-main-area">

        <main class="site-main">

            <?php
            while ( have_posts() ) :
                the_post();

                $piece_color = tetristheme_piece_color();
                ?>

                <article id="post-<?php the_ID(); ?>"
                         <?php post_class( 'entry' ); ?>
                         style="--piece: <?php echo esc_attr( $piece_color ); ?>">

                    <span class="score-badge">
                        SCORE <?php echo esc_html( tetristheme_post_score() ); ?>
                    </span>

                    <h1 class="entry-title"><?php the_title(); ?></h1>

                    <?php tetristheme_entry_meta(); ?>

                    <?php if ( has_post_thumbnail() ) : ?>
                        <div class="block-post__thumb">
                            <?php the_post_thumbnail( 'large' ); ?>
                        </div>
                    <?php endif; ?>

                    <div class="entry-content">
                        <?php
                        the_content();

                        // Постраничная навигация внутри длинной записи
                        wp_link_pages( array(
                            'before' => '<nav class="pagination">Страницы: ',
                            'after'  => '</nav>',
                        ) );
                        ?>
                    </div>

                    <?php
                    // Рубрики и метки записи
                    $tetris_cats = get_the_category_list( ', ' );
                    if ( $tetris_cats ) {
                        echo '<p class="block-post__meta">Рубрики: ' . wp_kses_post( $tetris_cats ) . '</p>';
                    }
                    the_tags( '<p class="block-post__meta">Метки: ', ', ', '</p>' );
                    ?>

                </article>

                <!-- Переход к соседним записям: «предыдущая фигура / следующая» -->
                <nav class="post-nav" aria-label="Соседние записи">
                    <?php previous_post_link( '%link', '&larr; %title' ); ?>
                    <?php next_post_link( '%link', '%title &rarr;' ); ?>
                </nav>

                <?php
                // Комментарии
                if ( comments_open() || get_comments_number() ) {
                    comments_template();
                }

            endwhile;
            ?>

        </main>

        <?php get_sidebar(); ?>

    </div>
</div>

<?php
get_footer();
