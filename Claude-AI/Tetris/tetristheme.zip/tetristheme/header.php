<?php
/**
 * Шапка сайта: логотип-тетрамино и навигация в стиле игрового меню
 *
 * @package TetrisTheme
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Фоновый слой: игровое поле 10x20, сюда JS добавляет падающие фигуры -->
<div class="tetris-field" id="tetris-field" aria-hidden="true"></div>

<!-- Ссылка для навигации с клавиатуры -->
<a class="screen-reader-text" href="#content">Перейти к содержимому</a>

<header class="site-header" id="top">
    <div class="header-inner">

        <div class="brand">
            <?php if ( has_custom_logo() ) : ?>
                <?php the_custom_logo(); ?>
            <?php else : ?>
                <!-- Логотип: T-тетрамино из четырёх блоков -->
                <div class="logo-tetromino" aria-hidden="true">
                    <span></span><span></span><span></span><span></span>
                </div>
            <?php endif; ?>

            <div class="brand__text">
                <?php if ( is_front_page() ) : ?>
                    <h1 class="site-title">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
                    </h1>
                <?php else : ?>
                    <p class="site-title">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
                    </p>
                <?php endif; ?>

                <?php $tetris_description = get_bloginfo( 'description', 'display' ); ?>
                <?php if ( $tetris_description ) : ?>
                    <p class="site-description"><?php echo esc_html( $tetris_description ); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Кнопка раскрытия меню на мобильных -->
        <button class="nav-toggle" id="nav-toggle" aria-expanded="false" aria-controls="primary-menu">
            МЕНЮ
        </button>

        <nav class="main-nav" id="primary-menu" aria-label="Главное меню">
            <?php
            // Если меню не назначено в админке — выводим список страниц
            if ( has_nav_menu( 'primary' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'depth'          => 2,
                ) );
            } else {
                wp_page_menu( array(
                    'menu_class' => 'fallback-menu',
                    'before'     => '',
                    'after'      => '',
                ) );
            }
            ?>
        </nav>

    </div>
</header>
