<?php
/**
 * Шаблон статической страницы
 *
 * @package TetrisTheme
 */

get_header();
?>

<div class="site-wrap" id="content">
    <div class="site-main-area">

        <main class="site-main">

            <?php
            while ( have_posts() ) :
                the_post();
                ?>

                <article id="post-<?php the_ID(); ?>"
                         <?php post_class( 'entry' ); ?>
                         style="--piece: <?php echo esc_attr( tetristheme_piece_color() ); ?>">

                    <h1 class="entry-title"><?php the_title(); ?></h1>

                    <?php if ( has_post_thumbnail() ) : ?>
                        <div class="block-post__thumb">
                            <?php the_post_thumbnail( 'large' ); ?>
                        </div>
                    <?php endif; ?>

                    <div class="entry-content">
                        <?php
                        the_content();

                        wp_link_pages( array(
                            'before' => '<nav class="pagination">Страницы: ',
                            'after'  => '</nav>',
                        ) );
                        ?>
                    </div>

                </article>

                <?php
                if ( comments_open() || get_comments_number() ) {
                    comments_template();
                }

            endwhile;
            ?>

        </main>

        <?php get_sidebar(); ?>

    </div>
</div>

<?php
get_footer();
