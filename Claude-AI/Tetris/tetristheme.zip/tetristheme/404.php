<?php
/**
 * Страница 404 — оформлена как экран «GAME OVER»
 *
 * @package TetrisTheme
 */

get_header();
?>

<div class="site-wrap" id="content">

    <section class="game-over">

        <p class="game-over__code">404</p>

        <h1 class="game-over__title">GAME OVER</h1>

        <p>Стакан переполнен: такой страницы на сайте нет.<br>
           Возможно, ссылка устарела или в адресе опечатка.</p>

        <p>
            <a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"
               style="--piece: #00f0f0">Начать заново</a>
        </p>

        <div style="max-width: 420px; margin: 40px auto 0;">
            <p>Или найдите нужное через поиск:</p>
            <?php get_search_form(); ?>
        </div>

    </section>

</div>

<?php
get_footer();
