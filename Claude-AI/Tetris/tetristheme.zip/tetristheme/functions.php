<?php
/**
 * TetrisTheme — функции и настройки темы
 *
 * @package TetrisTheme
 */

// Прямой вызов файла запрещён
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Базовая поддержка возможностей WordPress
 */
function tetristheme_setup() {

    // Тег <title> генерирует WordPress
    add_theme_support( 'title-tag' );

    // Миниатюры записей (обложки постов-блоков)
    add_theme_support( 'post-thumbnails' );

    // Корректная HTML5-разметка для встроенных элементов
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ) );

    // Поддержка кастомного логотипа (заменит тетрамино, если загружен)
    add_theme_support( 'custom-logo', array(
        'height'      => 60,
        'width'       => 60,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    // Автоматические ссылки на RSS-ленты
    add_theme_support( 'automatic-feed-links' );

    // Адаптивные вставки видео
    add_theme_support( 'responsive-embeds' );

    // Размер обложки для карточки-блока
    add_image_size( 'tetris-block', 600, 340, true );

    // Регистрируем два меню
    register_nav_menus( array(
        'primary' => 'Главное меню (шапка)',
        'footer'  => 'Меню в футере',
    ) );

    // Файлы перевода
    load_theme_textdomain( 'tetristheme', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'tetristheme_setup' );

/**
 * Подключение стилей и скриптов
 */
function tetristheme_assets() {

    $theme_version = wp_get_theme()->get( 'Version' );

    // Пиксельные шрифты с Google Fonts:
    // Press Start 2P — заголовки, VT323 — основной текст
    wp_enqueue_style(
        'tetristheme-fonts',
        'https://fonts.googleapis.com/css2?family=Press+Start+2P&family=VT323&display=swap',
        array(),
        null
    );

    // Главный файл темы (обязательный style.css)
    wp_enqueue_style(
        'tetristheme-style',
        get_stylesheet_uri(),
        array( 'tetristheme-fonts' ),
        $theme_version
    );

    // Анимации падающих блоков и фон игрового поля
    wp_enqueue_style(
        'tetristheme-tetris',
        get_template_directory_uri() . '/assets/css/tetris.css',
        array( 'tetristheme-style' ),
        $theme_version
    );

    // Скрипт эффектов
    wp_enqueue_script(
        'tetristheme-script',
        get_template_directory_uri() . '/assets/js/tetris.js',
        array(),
        $theme_version,
        true // подключаем в футере
    );

    // Передаём палитру тетрамино в JavaScript
    wp_localize_script( 'tetristheme-script', 'TetrisThemeData', array(
        'colors' => array_values( tetristheme_get_palette() ),
    ) );

    // Скрипт ответов на комментарии на страницах постов
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'tetristheme_assets' );

/**
 * Палитра семи классических фигур Тетриса
 *
 * @return array Ассоциативный массив «буква фигуры => HEX-цвет»
 */
function tetristheme_get_palette() {
    return array(
        'I' => '#00f0f0', // бирюзовая палка
        'O' => '#f0f000', // жёлтый квадрат
        'T' => '#a000f0', // фиолетовая
        'S' => '#00f000', // зелёная
        'Z' => '#f00000', // красная
        'J' => '#0000f0', // синяя
        'L' => '#f0a000', // оранжевая
    );
}

/**
 * Назначает записи цвет фигуры.
 * Цвет зависит от ID записи, поэтому у поста он всегда один и тот же,
 * а в ленте карточки выглядят разноцветными.
 *
 * @param int|null $post_id ID записи.
 * @return string HEX-цвет.
 */
function tetristheme_piece_color( $post_id = null ) {
    $post_id = $post_id ? $post_id : get_the_ID();
    $palette = array_values( tetristheme_get_palette() );

    return $palette[ absint( $post_id ) % count( $palette ) ];
}

/**
 * Регистрация областей виджетов
 */
function tetristheme_widgets_init() {

    register_sidebar( array(
        'name'          => 'Сайдбар',
        'id'            => 'sidebar-main',
        'description'   => 'Боковая панель на главной и в записях.',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => 'Футер',
        'id'            => 'footer-widgets',
        'description'   => 'Виджеты в нижней части сайта.',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'tetristheme_widgets_init' );

/**
 * Длина анонса — 24 слова, чтобы карточки-блоки были одного размера
 */
function tetristheme_excerpt_length( $length ) {
    return 24;
}
add_filter( 'excerpt_length', 'tetristheme_excerpt_length' );

/**
 * Многоточие в анонсе заменяем на ретро-троеточие
 */
function tetristheme_excerpt_more( $more ) {
    return ' ...';
}
add_filter( 'excerpt_more', 'tetristheme_excerpt_more' );

/**
 * «Очки» записи — шуточный счётчик вместо обычного числа просмотров.
 * Считается по количеству комментариев и длине текста.
 *
 * @return int
 */
function tetristheme_post_score() {
    $words    = str_word_count( wp_strip_all_tags( get_the_content() ) );
    $comments = absint( get_comments_number() );

    // Округляем до сотен — так число выглядит как игровой счёт
    return ( $words * 10 ) + ( $comments * 100 );
}

/**
 * Добавляем класс no-js в <body>.
 * JavaScript снимет его при загрузке — так стили деградируют корректно.
 */
function tetristheme_body_classes( $classes ) {
    $classes[] = 'no-js';
    return $classes;
}
add_filter( 'body_class', 'tetristheme_body_classes' );

/**
 * Мета-строка записи: дата, автор, рубрики
 */
function tetristheme_entry_meta() {
    printf(
        '<p class="block-post__meta">%1$s &middot; %2$s</p>',
        esc_html( get_the_date( 'd.m.Y' ) ),
        esc_html( get_the_author() )
    );
}
