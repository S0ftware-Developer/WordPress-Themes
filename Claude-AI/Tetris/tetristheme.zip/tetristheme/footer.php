<?php
/**
 * Футер сайта с паттерном из уложенных блоков
 *
 * @package TetrisTheme
 */
?>

<footer class="site-footer">

    <!-- Ряд «уложенных» тетрамино вдоль верхней кромки футера.
         Цвета перебираются циклически по семи фигурам. -->
    <div class="footer-stack" aria-hidden="true">
        <?php
        $tetris_palette = array_values( tetristheme_get_palette() );

        for ( $i = 0; $i < 20; $i++ ) {
            printf(
                '<span style="background:%s"></span>',
                esc_attr( $tetris_palette[ $i % count( $tetris_palette ) ] )
            );
        }
        ?>
    </div>

    <?php if ( is_active_sidebar( 'footer-widgets' ) ) : ?>
        <div class="footer-widgets">
            <?php dynamic_sidebar( 'footer-widgets' ); ?>
        </div>
    <?php endif; ?>

    <div class="footer-inner">

        <p>
            &copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?>
            <?php bloginfo( 'name' ); ?>. The website was made by Andrei Orlov: orlovandrei.space
        </p>

        <?php if ( has_nav_menu( 'footer' ) ) : ?>
            <nav aria-label="Меню в футере">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'footer',
                    'container'      => false,
                    'depth'          => 1,
                ) );
                ?>
            </nav>
        <?php endif; ?>

        <p><a href="#top">&#9650; Наверх</a></p>

    </div>

</footer>

<?php wp_footer(); ?>
</body>
</html>
