<?php
/**
 * Шапка с денежным хранилищем и картой сокровищ
 *
 * @package DuckTalesTheme
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="screen-reader-text" href="#content">Перейти к содержимому</a>

<!-- Шапка с денежным хранилищем -->
<header class="site-header" id="top">
    <div class="header-inner">

        <div class="brand">
            <!-- Логотип - денежное хранилище -->
            <?php if ( has_custom_logo() ) : ?>
                <?php the_custom_logo(); ?>
            <?php else : ?>
                <div class="logo-treasury" title="Золотая монета №1 Скруджа Макдака" role="img" aria-label="Логотип: золотая монета"></div>
            <?php endif; ?>

            <div class="brand__text">
                <?php if ( is_front_page() ) : ?>
                    <h1 class="site-title">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
                    </h1>
                <?php else : ?>
                    <p class="site-title">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
                    </p>
                <?php endif; ?>

                <?php $site_description = get_bloginfo( 'description', 'display' ); ?>
                <?php if ( $site_description ) : ?>
                    <p class="site-description"><?php echo esc_html( $site_description ); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Меню - карта сокровищ -->
        <nav class="main-nav" id="primary-menu" aria-label="Главное меню">
            <?php
            if ( has_nav_menu( 'primary' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'depth'          => 2,
                ) );
            } else {
                wp_page_menu( array(
                    'menu_class' => 'fallback-menu',
                    'before'     => '',
                    'after'      => '',
                ) );
            }
            ?>
        </nav>

    </div>
</header>
