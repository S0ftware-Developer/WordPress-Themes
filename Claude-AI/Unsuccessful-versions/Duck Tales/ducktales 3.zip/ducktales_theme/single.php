<?php
/**
 * Отдельная экспедиция (пост)
 *
 * @package DuckTalesTheme
 */

get_header();
?>

<div class="site-wrap" id="content">
    <div class="site-main-area">

        <main class="site-main">

            <?php
            while ( have_posts() ) :
                the_post();
                $character = ducktales_get_character();
                ?>

                <article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>

                    <!-- Персонаж-герой (иконка рисуется через CSS ::before) -->
                    <span class="character-badge <?php echo esc_attr( $character['class'] ); ?>">
                        <?php echo esc_html( $character['name'] ); ?>
                    </span>

                    <h1 class="entry-title"><?php the_title(); ?></h1>

                    <?php ducktales_expedition_meta(); ?>

                    <?php if ( has_post_thumbnail() ) : ?>
                        <div class="treasure-card__thumb">
                            <?php the_post_thumbnail( 'large' ); ?>
                        </div>
                    <?php endif; ?>

                    <div class="entry-content">
                        <?php
                        the_content();

                        wp_link_pages( array(
                            'before' => '<nav class="pagination">СЦЕНЫ: ',
                            'after'  => '</nav>',
                        ) );
                        ?>
                    </div>

                    <?php
                    $treasure_cats = get_the_category_list( ', ' );
                    if ( $treasure_cats ) {
                        echo '<p class="treasure-meta">ЛОКАЦИИ: ' . wp_kses_post( $treasure_cats ) . '</p>';
                    }
                    the_tags( '<p class="treasure-meta">СОКРОВИЩА: ', ', ', '</p>' );
                    ?>

                </article>

                <!-- Переход к соседним экспедициям -->
                <nav class="post-nav" aria-label="Соседние экспедиции">
                    <?php previous_post_link( '%link', '← %title' ); ?>
                    <?php next_post_link( '%link', '%title →' ); ?>
                </nav>

                <?php
                if ( comments_open() || get_comments_number() ) {
                    comments_template();
                }

            endwhile;
            ?>

        </main>

        <?php get_sidebar(); ?>

    </div>
</div>

<?php
get_footer();
