<?php
/**
 * DuckTalesTheme - функции и настройки
 * Утиные истории - Скруджа, Братья Гавс, утята, денежное хранилище
 *
 * @package DuckTalesTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Поддержка возможностей WordPress
 */
function ducktales_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array(
        'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script',
    ) );
    add_theme_support( 'custom-logo', array(
        'height' => 60, 'width' => 60, 'flex-height' => true, 'flex-width' => true,
    ) );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'responsive-embeds' );

    add_image_size( 'treasure-thumb', 600, 340, true );

    register_nav_menus( array(
        'primary' => 'Главное меню (карта сокровищ)',
        'footer'  => 'Меню в футере',
    ) );

    load_theme_textdomain( 'ducktales', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'ducktales_setup' );

/**
 * Подключение стилей и скриптов
 */
function ducktales_assets() {
    $theme_version = wp_get_theme()->get( 'Version' );

    // Пиксельные шрифты с Google Fonts
    wp_enqueue_style(
        'ducktales-fonts',
        'https://fonts.googleapis.com/css2?family=Press+Start+2P&family=VT323&display=swap',
        array(), null
    );

    // Главный CSS
    wp_enqueue_style(
        'ducktales-style',
        get_stylesheet_uri(),
        array( 'ducktales-fonts' ),
        $theme_version
    );

    // Доп. CSS с анимациями
    wp_enqueue_style(
        'ducktales-animations',
        get_template_directory_uri() . '/assets/css/ducktales.css',
        array( 'ducktales-style' ),
        $theme_version
    );

    // JavaScript
    wp_enqueue_script(
        'ducktales-script',
        get_template_directory_uri() . '/assets/js/ducktales.js',
        array(), $theme_version, true
    );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'ducktales_assets' );

/**
 * Регистрация виджетов
 */
function ducktales_widgets_init() {
    register_sidebar( array(
        'name'          => 'Сайдбар (Денежное хранилище)',
        'id'            => 'sidebar-main',
        'description'   => 'Виджеты рядом с экспедициями',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => 'Футер',
        'id'            => 'footer-widgets',
        'description'   => 'Виджеты в футере.',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'ducktales_widgets_init' );

/**
 * Длина анонса
 */
function ducktales_excerpt_length( $length ) {
    return 20;
}
add_filter( 'excerpt_length', 'ducktales_excerpt_length' );

function ducktales_excerpt_more( $more ) {
    return ' ...';
}
add_filter( 'excerpt_more', 'ducktales_excerpt_more' );

/**
 * Номер экспедиции
 */
function ducktales_expedition_number( $position ) {
    return $position + 1;
}

/**
 * Персонажи - случайно для каждого поста
 */
function ducktales_get_character() {
    // Каждому персонажу соответствует CSS-класс со своей иконкой-силуэтом
    // (см. .character-badge.* в style.css) - цилиндр, матросская шапка,
    // три кепки, маска - вместо текстовых эмодзи.
    $characters = array(
        array( 'name' => 'Скруджа Макдака', 'class' => 'scrooge' ),
        array( 'name' => 'Братья Гавс', 'class' => 'brothers' ),
        array( 'name' => 'Утята', 'class' => 'nephews' ),
        array( 'name' => 'ЗигЗаг МакКряка', 'class' => 'zigzag' ),
    );
    return $characters[ get_the_ID() % count( $characters ) ];
}

/**
 * Класс no-js для JavaScript деградации
 */
function ducktales_body_classes( $classes ) {
    $classes[] = 'no-js';
    return $classes;
}
add_filter( 'body_class', 'ducktales_body_classes' );

/**
 * Мета-строка экспедиции
 */
function ducktales_expedition_meta() {
    printf(
        '<p class="treasure-meta">%1$s</p>',
        esc_html( get_the_date( 'd.m.Y' ) )
    );
}
