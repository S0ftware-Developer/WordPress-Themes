<?php
/**
 * Страница 404 - потеряны в пути
 *
 * @package DuckTalesTheme
 */

get_header();
?>

<div class="site-wrap" id="content">

    <section class="game-over">

        <p class="game-over__code">404</p>

        <h1 class="game-over__title">ЭКСПЕДИЦИЯ НЕ НАЙДЕНА!</h1>

        <div class="lost-map" aria-hidden="true"></div>

        <p>Похоже, эта карта сокровищ порвана и путь потерян...</p>
        <p>Нужный клад найти не удалось. Вернитесь на главную и начните новую экспедицию!</p>

        <p>
            <a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">ВЕРНУТЬСЯ НА ГЛАВНУЮ</a>
        </p>

        <div style="max-width: 420px; margin: 40px auto 0;">
            <p>Или найдите нужную экспедицию:</p>
            <?php get_search_form(); ?>
        </div>

    </section>

</div>

<?php
get_footer();
