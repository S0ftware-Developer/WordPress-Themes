/**
 * DuckTalesTheme - интерактивность
 * Сбор монет, появление экспедиций, звуки
 */
(function() {
    'use strict';

    document.body.classList.remove('no-js');

    // Появление экспедиций при скролле
    function initReveal() {
        var cards = document.querySelectorAll('.treasure-card');
        
        if (!('IntersectionObserver' in window)) {
            cards.forEach(function(card) { card.style.opacity = '1'; });
            return;
        }

        var observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry, i) {
                if (!entry.isIntersecting) return;
                
                setTimeout(function() {
                    entry.target.style.animation = 'treasure-appear 0.6s cubic-bezier(0.34, 1.56, 0.64, 1) forwards';
                }, i * 100);
                
                observer.unobserve(entry.target);
            });
        }, { threshold: 0.15 });

        cards.forEach(function(card) { observer.observe(card); });
    }

    // Сбор монет при клике
    function initCoinCollection() {
        document.querySelectorAll('.treasure-card').forEach(function(card) {
            card.addEventListener('click', function() {
                var coin = document.createElement('div');
                coin.className = 'coin-collect';
                coin.innerHTML = '💰';
                coin.style.position = 'absolute';
                coin.style.left = event.pageX + 'px';
                coin.style.top = event.pageY + 'px';
                coin.style.fontSize = '32px';
                coin.style.pointerEvents = 'none';
                coin.style.zIndex = '1000';
                
                document.body.appendChild(coin);
                
                setTimeout(function() { coin.remove(); }, 800);
            });
        });
    }

    initReveal();
    initCoinCollection();
})();
