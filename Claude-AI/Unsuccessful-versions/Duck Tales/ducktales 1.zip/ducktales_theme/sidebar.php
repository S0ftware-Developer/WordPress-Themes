<?php
/**
 * Сайдбар - денежное хранилище
 *
 * @package DuckTalesTheme
 */
?>

<aside class="sidebar" role="complementary">

    <?php if ( is_active_sidebar( 'sidebar-main' ) ) : ?>

        <?php dynamic_sidebar( 'sidebar-main' ); ?>

    <?php else : ?>

        <!-- Поиск экспедиции -->
        <section class="widget">
            <h3 class="widget-title">💰 ПОИСК СОКРОВИЩ</h3>
            <?php get_search_form(); ?>
        </section>

        <!-- Свежие экспедиции -->
        <section class="widget">
            <h3 class="widget-title">🗺️ СВЕЖИЕ ЭКСПЕДИЦИИ</h3>
            <ul>
                <?php
                $fresh_expeditions = new WP_Query( array(
                    'posts_per_page'      => 5,
                    'ignore_sticky_posts' => true,
                ) );

                while ( $fresh_expeditions->have_posts() ) :
                    $fresh_expeditions->the_post();
                    ?>
                    <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                <?php
                endwhile;

                wp_reset_postdata();
                ?>
            </ul>
        </section>

        <!-- Локации (категории) -->
        <section class="widget">
            <h3 class="widget-title">🌍 ЛОКАЦИИ</h3>
            <ul>
                <?php wp_list_categories( array( 'title_li' => '' ) ); ?>
            </ul>
        </section>

    <?php endif; ?>

</aside>
