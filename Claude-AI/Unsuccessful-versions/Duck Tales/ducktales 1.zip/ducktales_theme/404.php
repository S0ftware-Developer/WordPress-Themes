<?php
/**
 * Страница 404 - потеряны в пути
 *
 * @package DuckTalesTheme
 */

get_header();
?>

<div class="site-wrap" id="content">

    <section class="game-over">

        <p class="game-over__code">404</p>

        <h1 class="game-over__title">ЭКСПЕДИЦИЯ НЕ НАЙДЕНА!</h1>

        <p>🗺️ Похоже, эта карта сокровищ потеряна...</p>
        <p>Скруджа Макдака не может найти нужный путь. Вернитесь на главную!</p>

        <p>
            <a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">ВЕРНУТЬСЯ НА ГЛАВНУЮ</a>
        </p>

        <div style="max-width: 420px; margin: 40px auto 0;">
            <p>Или найдите нужную экспедицию:</p>
            <?php get_search_form(); ?>
        </div>

    </section>

</div>

<?php
get_footer();
