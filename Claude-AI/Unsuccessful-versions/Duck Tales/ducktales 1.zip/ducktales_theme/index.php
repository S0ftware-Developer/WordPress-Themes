<?php
/**
 * Главная: экспедиции за сокровищами
 *
 * @package DuckTalesTheme
 */

get_header();
?>

<div class="site-wrap" id="content">
    <div class="site-main-area">

        <main class="site-main">

            <?php if ( is_home() && ! is_front_page() ) : ?>
                <h1 class="page-title"><?php single_post_title(); ?></h1>
            <?php elseif ( is_archive() ) : ?>
                <h1 class="page-title"><?php the_archive_title(); ?></h1>
            <?php elseif ( is_search() ) : ?>
                <h1 class="page-title">ПОИСК: <?php echo esc_html( get_search_query() ); ?></h1>
            <?php endif; ?>

            <?php if ( have_posts() ) : ?>

                <div class="treasures-grid">

                    <?php
                    $expedition_counter = 0;

                    while ( have_posts() ) :
                        the_post();
                        $character = ducktales_get_character();
                        ?>

                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'treasure-card' ); ?>>

                            <!-- Номер экспедиции -->
                            <span class="treasure-num">
                                ЭКСПЕДИЦИЯ <?php echo esc_html( ducktales_expedition_number( $expedition_counter ) ); ?>
                            </span>

                            <!-- Персонаж-герой -->
                            <span class="character-badge <?php echo esc_attr( $character['class'] ); ?>">
                                <?php echo esc_html( $character['emoji'] . ' ' . $character['name'] ); ?>
                            </span>

                            <!-- Обложка уровня -->
                            <?php if ( has_post_thumbnail() ) : ?>
                                <a class="treasure-card__thumb" href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail( 'treasure-thumb', array( 'loading' => 'lazy' ) ); ?>
                                </a>
                            <?php endif; ?>

                            <!-- Название экспедиции -->
                            <h2 class="treasure-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>

                            <!-- Мета: персонаж и дата -->
                            <?php ducktales_expedition_meta(); ?>

                            <!-- Выдержка из описания экспедиции -->
                            <div class="treasure-excerpt">
                                <?php the_excerpt(); ?>
                            </div>

                            <!-- Кнопка входа в экспедицию -->
                            <p>
                                <a class="btn" href="<?php the_permalink(); ?>">НАЧАТЬ ЭКСПЕДИЦИЮ</a>
                            </p>

                        </article>

                        <?php $expedition_counter++; ?>

                    <?php endwhile; ?>

                </div><!-- .treasures-grid -->

                <!-- Пагинация -->
                <nav class="pagination" aria-label="Навигация по экспедициям">
                    <?php
                    echo paginate_links( array(
                        'prev_text' => '← НАЗАД',
                        'next_text' => 'ДАЛЕЕ →',
                    ) );
                    ?>
                </nav>

            <?php else : ?>

                <div class="entry">
                    <h2>НЕТ ЭКСПЕДИЦИЙ</h2>
                    <p>Пока что нет опубликованных экспедиций. Проверьте позже!</p>
                    <?php get_search_form(); ?>
                </div>

            <?php endif; ?>

        </main>

        <?php get_sidebar(); ?>

    </div>
</div>

<?php
get_footer();
