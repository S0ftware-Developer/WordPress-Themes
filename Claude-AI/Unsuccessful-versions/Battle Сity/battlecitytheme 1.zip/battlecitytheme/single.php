<?php
/**
 * Шаблон отдельного уровня (запись)
 *
 * @package BattleCityTheme
 */

get_header();
?>

<div class="site-wrap" id="content">
    <div class="site-main-area">

        <main class="site-main">

            <?php
            while ( have_posts() ) :
                the_post();
                ?>

                <article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>

                    <p class="enemy-count">
                        <?php echo esc_html( battlecitytheme_enemy_count() ); ?> ВРАГОВ
                    </p>

                    <h1 class="entry-title"><?php the_title(); ?></h1>

                    <?php battlecitytheme_entry_meta(); ?>

                    <?php if ( has_post_thumbnail() ) : ?>
                        <div class="tank-level__thumb">
                            <?php the_post_thumbnail( 'large' ); ?>
                        </div>
                    <?php endif; ?>

                    <div class="entry-content">
                        <?php
                        the_content();

                        wp_link_pages( array(
                            'before' => '<nav class="pagination">ВОЛНЫ: ',
                            'after'  => '</nav>',
                        ) );
                        ?>
                    </div>

                    <?php
                    $battle_cats = get_the_category_list( ', ' );
                    if ( $battle_cats ) {
                        echo '<p class="tank-level__meta">МИССИИ: ' . wp_kses_post( $battle_cats ) . '</p>';
                    }
                    the_tags( '<p class="tank-level__meta">ТЕГИ: ', ', ', '</p>' );
                    ?>

                </article>

                <!-- Переход к соседним уровням -->
                <nav class="post-nav" aria-label="Соседние записи">
                    <?php previous_post_link( '%link', '← %title' ); ?>
                    <?php next_post_link( '%link', '%title →' ); ?>
                </nav>

                <?php
                if ( comments_open() || get_comments_number() ) {
                    comments_template();
                }

            endwhile;
            ?>

        </main>

        <?php get_sidebar(); ?>

    </div>
</div>

<?php
get_footer();
