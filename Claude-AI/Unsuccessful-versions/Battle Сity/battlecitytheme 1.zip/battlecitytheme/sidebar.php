<?php
/**
 * Сайдбар: радар боя и статистика
 *
 * @package BattleCityTheme
 */
?>

<aside class="sidebar" role="complementary">

    <!-- Радар боя: сетка 8x8 с врагами и танком -->
    <section class="widget">
        <h3 class="widget-title">РАДАР</h3>
        <div class="radar" aria-label="Боевой радар">
            <span class="player" title="Ваш танк"></span>
            <span></span>
            <span class="enemy" title="Враг"></span>
            <span></span>
            <span class="enemy" title="Враг"></span>
            <span></span>
            <span></span>
            <span></span>

            <span></span>
            <span></span>
            <span></span>
            <span class="enemy" title="Враг"></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>

            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>

            <span></span>
            <span class="enemy" title="Враг"></span>
            <span></span>
            <span></span>
            <span></span>
            <span class="enemy" title="Враг"></span>
            <span></span>
            <span></span>

            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>

            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span class="enemy" title="Враг"></span>
            <span></span>
            <span></span>
            <span></span>

            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>

            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
    </section>

    <?php if ( is_active_sidebar( 'sidebar-main' ) ) : ?>

        <?php dynamic_sidebar( 'sidebar-main' ); ?>

    <?php else : ?>

        <!-- Запасное наполнение, если виджеты ещё не добавлены -->
        <section class="widget">
            <h3 class="widget-title">ПОИСК</h3>
            <?php get_search_form(); ?>
        </section>

        <section class="widget">
            <h3 class="widget-title">УРОВНИ</h3>
            <ul>
                <?php
                $battle_recent = new WP_Query( array(
                    'posts_per_page'      => 5,
                    'ignore_sticky_posts' => true,
                ) );

                while ( $battle_recent->have_posts() ) :
                    $battle_recent->the_post();
                    ?>
                    <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                <?php
                endwhile;

                wp_reset_postdata();
                ?>
            </ul>
        </section>

        <section class="widget">
            <h3 class="widget-title">МИССИИ</h3>
            <ul>
                <?php wp_list_categories( array( 'title_li' => '' ) ); ?>
            </ul>
        </section>

    <?php endif; ?>

</aside>
