<?php
/**
 * BattleCityTheme — функции и настройки темы
 *
 * @package BattleCityTheme
 */

// Прямой вызов файла запрещён
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Базовая поддержка возможностей WordPress
 */
function battlecitytheme_setup() {

    // Тег <title> генерирует WordPress
    add_theme_support( 'title-tag' );

    // Миниатюры записей (обложки уровней)
    add_theme_support( 'post-thumbnails' );

    // Корректная HTML5-разметка для встроенных элементов
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ) );

    // Кастомный логотип (заменит танк, если загружен)
    add_theme_support( 'custom-logo', array(
        'height'      => 48,
        'width'       => 48,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'responsive-embeds' );

    // Размер обложки для карточки-уровня
    add_image_size( 'battle-level', 600, 340, true );

    // Регистрируем два меню
    register_nav_menus( array(
        'primary' => 'Главное меню (шапка)',
        'footer'  => 'Меню в футере',
    ) );

    // Файлы перевода
    load_theme_textdomain( 'battlecitytheme', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'battlecitytheme_setup' );

/**
 * Подключение стилей и скриптов
 */
function battlecitytheme_assets() {

    $theme_version = wp_get_theme()->get( 'Version' );

    // Пиксельные шрифты с Google Fonts
    wp_enqueue_style(
        'battlecitytheme-fonts',
        'https://fonts.googleapis.com/css2?family=Press+Start+2P&family=VT323&display=swap',
        array(),
        null
    );

    // Главный файл темы (обязательный style.css)
    wp_enqueue_style(
        'battlecitytheme-style',
        get_stylesheet_uri(),
        array( 'battlecitytheme-fonts' ),
        $theme_version
    );

    // Дополнительные анимации: выстрелы, взрывы, радар
    wp_enqueue_style(
        'battlecitytheme-battle',
        get_template_directory_uri() . '/assets/css/battle.css',
        array( 'battlecitytheme-style' ),
        $theme_version
    );

    // Скрипт интерактива
    wp_enqueue_script(
        'battlecitytheme-script',
        get_template_directory_uri() . '/assets/js/battle.js',
        array(),
        $theme_version,
        true // подключаем в футере
    );

    // Скрипт ответов на комментарии
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'battlecitytheme_assets' );

/**
 * Регистрация областей виджетов
 */
function battlecitytheme_widgets_init() {

    register_sidebar( array(
        'name'          => 'Сайдбар',
        'id'            => 'sidebar-main',
        'description'   => 'Радар боя и статистика.',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => 'Футер',
        'id'            => 'footer-widgets',
        'description'   => 'Виджеты в нижней части сайта.',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'battlecitytheme_widgets_init' );

/**
 * Длина анонса — 20 слов, чтобы карточки-уровни были одного размера
 */
function battlecitytheme_excerpt_length( $length ) {
    return 20;
}
add_filter( 'excerpt_length', 'battlecitytheme_excerpt_length' );

/**
 * Многоточие в анонсе
 */
function battlecitytheme_excerpt_more( $more ) {
    return ' ...';
}
add_filter( 'excerpt_more', 'battlecitytheme_excerpt_more' );

/**
 * Номер уровня в зависимости от порядка записи (1, 2, 3...)
 *
 * @param int $position Позиция в цикле.
 * @return int
 */
function battlecitytheme_level_number( $position ) {
    return $position + 1;
}

/**
 * Счётчик врагов вместо просмотров
 *
 * @return int
 */
function battlecitytheme_enemy_count() {
    $comments = absint( get_comments_number() );
    return max( 1, $comments );
}

/**
 * Добавляем класс no-js в <body>.
 * JavaScript снимет его при загрузке.
 */
function battlecitytheme_body_classes( $classes ) {
    $classes[] = 'no-js';
    return $classes;
}
add_filter( 'body_class', 'battlecitytheme_body_classes' );

/**
 * Мета-строка записи: дата, автор
 */
function battlecitytheme_entry_meta() {
    printf(
        '<p class="tank-level__meta">%1$s &middot; %2$s</p>',
        esc_html( get_the_date( 'd.m.Y' ) ),
        esc_html( get_the_author() )
    );
}
