<?php
/**
 * Страница 404 — здание уничтожено
 *
 * @package BattleCityTheme
 */

get_header();
?>

<div class="site-wrap" id="content">

    <section class="game-over">

        <p class="game-over__code">404</p>

        <h1 class="game-over__title">ЗДАНИЕ УНИЧТОЖЕНО</h1>

        <div class="destroyed">
            <p>⬚ ⬚ ⬚<br>
               ⬜ ☒ ⬜<br>
               ⬚ ⬚ ⬚</p>
        </div>

        <p style="margin-top: 20px; color: #ff4400;">
            Такая позиция отсутствует на этом поле боя.<br>
            Ссылка повреждена или адрес указан неправильно.
        </p>

        <p>
            <a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">ВЕРНУТЬСЯ В БОЙ</a>
        </p>

        <div style="max-width: 420px; margin: 40px auto 0;">
            <p>Найдите нужный уровень:</p>
            <?php get_search_form(); ?>
        </div>

    </section>

</div>

<?php
get_footer();
