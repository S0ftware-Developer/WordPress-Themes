/**
 * BattleCityTheme — интерактивные эффекты: появление уровней, выстрелы, радар
 *
 * Файл не зависит от jQuery.
 */
( function () {
    'use strict';

    // Снимаем класс no-js: JavaScript работает
    document.body.classList.remove( 'no-js' );

    var reducedMotion = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

    /**
     * Уровни «материализуются» при прокрутке до них
     */
    function initReveal() {
        var levels = document.querySelectorAll( '.tank-level' );

        if ( ! levels.length ) {
            return;
        }

        if ( ! ( 'IntersectionObserver' in window ) || reducedMotion ) {
            levels.forEach( function ( level ) {
                level.classList.add( 'is-revealed' );
            } );
            return;
        }

        var observer = new IntersectionObserver( function ( entries ) {
            entries.forEach( function ( entry, i ) {
                if ( ! entry.isIntersecting ) {
                    return;
                }

                // Уровни появляются с небольшой задержкой друг за другом
                setTimeout( function () {
                    entry.target.classList.add( 'is-revealed' );
                }, i * 100 );

                observer.unobserve( entry.target );
            } );
        }, { threshold: 0.15 } );

        levels.forEach( function ( level ) {
            observer.observe( level );
        } );
    }

    /**
     * Мобильное меню: кнопка START раскрывает список
     */
    function initNav() {
        var toggle = document.getElementById( 'nav-toggle' );
        var nav = document.getElementById( 'primary-menu' );

        if ( ! toggle || ! nav ) {
            return;
        }

        toggle.addEventListener( 'click', function () {
            var isOpen = nav.classList.toggle( 'is-open' );
            toggle.setAttribute( 'aria-expanded', isOpen ? 'true' : 'false' );
        } );
    }

    /**
     * Клик по кнопке НАЧАТЬ БОЙ — танк выстреливает перед переходом
     */
    function initButtonShot() {
        if ( reducedMotion ) {
            return;
        }

        document.querySelectorAll( 'a.btn' ).forEach( function ( btn ) {
            btn.addEventListener( 'click', function ( event ) {
                if ( btn.dataset.shot ) {
                    return;
                }

                event.preventDefault();
                btn.dataset.shot = 'true';
                btn.style.animation = 'tank-recoil 0.2s steps(2, end)';

                setTimeout( function () {
                    window.location.href = btn.href;
                }, 200 );
            } );
        } );
    }

    /**
     * Динамическое обновление радара — враги мигают
     * (эта функция уже задана в CSS анимациями, но можно расширить)
     */
    function initRadar() {
        var radar = document.querySelector( '.radar' );
        if ( ! radar ) {
            return;
        }

        // Радар работает через CSS анимацию .radar-pulse
        // Здесь можно добавить интерактивность, если нужно
    }

    initReveal();
    initNav();
    initButtonShot();
    initRadar();

}() );
