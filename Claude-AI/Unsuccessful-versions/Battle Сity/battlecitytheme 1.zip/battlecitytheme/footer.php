<?php
/**
 * Футер сайта с паттерном кирпичных стен
 *
 * @package BattleCityTheme
 */
?>

<footer class="site-footer">

    <!-- Паттерн кирпичных стен вдоль верхней кромки -->
    <div class="footer-walls" aria-hidden="true"></div>

    <?php if ( is_active_sidebar( 'footer-widgets' ) ) : ?>
        <div class="footer-widgets site-wrap">
            <?php dynamic_sidebar( 'footer-widgets' ); ?>
        </div>
    <?php endif; ?>

    <div class="footer-inner">

        <p>
            &copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?>
            <?php bloginfo( 'name' ); ?>. The website was made by Andrei Orlov: orlovandrei.space
        </p>

        <?php if ( has_nav_menu( 'footer' ) ) : ?>
            <nav aria-label="Меню в футере">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'footer',
                    'container'      => false,
                    'depth'          => 1,
                ) );
                ?>
            </nav>
        <?php endif; ?>

        <p><a href="#top">↑ BACK</a></p>

    </div>

</footer>

<?php wp_footer(); ?>
</body>
</html>
