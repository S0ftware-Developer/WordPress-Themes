<?php
/**
 * Главный шаблон: лента уровней боя
 *
 * @package BattleCityTheme
 */

get_header();
?>

<div class="site-wrap" id="content">
    <div class="site-main-area">

        <main class="site-main">

            <?php if ( is_home() && ! is_front_page() ) : ?>
                <h1 class="page-title"><?php single_post_title(); ?></h1>
            <?php elseif ( is_archive() ) : ?>
                <h1 class="page-title"><?php the_archive_title(); ?></h1>
            <?php elseif ( is_search() ) : ?>
                <h1 class="page-title">ПОИСК: <?php echo esc_html( get_search_query() ); ?></h1>
            <?php endif; ?>

            <?php if ( have_posts() ) : ?>

                <div class="battle-levels">

                    <?php
                    $battle_position = 0;

                    while ( have_posts() ) :
                        the_post();
                        ?>

                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'tank-level' ); ?>>

                            <!-- Номер уровня -->
                            <span class="level-num">
                                УРОВЕНЬ <?php echo esc_html( battlecitytheme_level_number( $battle_position ) ); ?>
                            </span>

                            <?php if ( has_post_thumbnail() ) : ?>
                                <a class="tank-level__thumb" href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail( 'battle-level', array( 'loading' => 'lazy' ) ); ?>
                                </a>
                            <?php endif; ?>

                            <h2 class="tank-level__title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>

                            <?php battlecitytheme_entry_meta(); ?>

                            <div class="tank-level__excerpt">
                                <?php the_excerpt(); ?>
                            </div>

                            <!-- Счётчик врагов -->
                            <p class="enemy-count">
                                <?php echo esc_html( battlecitytheme_enemy_count() ); ?> ВРАГОВ
                            </p>

                            <p>
                                <a class="btn" href="<?php the_permalink(); ?>">НАЧАТЬ БОЙ</a>
                            </p>

                        </article>

                        <?php $battle_position++; ?>

                    <?php endwhile; ?>

                </div><!-- .battle-levels -->

                <!-- Постраничная навигация -->
                <nav class="pagination" aria-label="Навигация по страницам">
                    <?php
                    echo paginate_links( array(
                        'prev_text' => '← PREV WAVE',
                        'next_text' => 'NEXT WAVE →',
                    ) );
                    ?>
                </nav>

            <?php else : ?>

                <div class="entry">
                    <h2>УРОВНИ ОТСУТСТВУЮТ</h2>
                    <p>Опубликуйте первый уровень в админке и вернитесь в боевое поле.</p>
                    <?php get_search_form(); ?>
                </div>

            <?php endif; ?>

        </main>

        <?php get_sidebar(); ?>

    </div>
</div>

<?php
get_footer();
