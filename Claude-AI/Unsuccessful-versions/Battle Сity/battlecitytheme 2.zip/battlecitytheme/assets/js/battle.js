/**
 * BattleCityTheme — интерактивные эффекты
 */
( function () {
    'use strict';

    document.body.classList.remove( 'no-js' );

    var reducedMotion = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

    /**
     * Уровни появляются при скролле
     */
    function initReveal() {
        var levels = document.querySelectorAll( '.tank-level' );

        if ( ! levels.length || ! ( 'IntersectionObserver' in window ) || reducedMotion ) {
            levels.forEach( function ( level ) {
                level.classList.add( 'is-revealed' );
            } );
            return;
        }

        var observer = new IntersectionObserver( function ( entries ) {
            entries.forEach( function ( entry, i ) {
                if ( ! entry.isIntersecting ) return;

                setTimeout( function () {
                    entry.target.classList.add( 'is-revealed' );
                }, i * 100 );

                observer.unobserve( entry.target );
            } );
        }, { threshold: 0.15 } );

        levels.forEach( function ( level ) {
            observer.observe( level );
        } );
    }

    /**
     * Мобильное меню
     */
    function initNav() {
        var toggle = document.getElementById( 'nav-toggle' );
        var nav = document.getElementById( 'primary-menu' );

        if ( ! toggle || ! nav ) return;

        toggle.addEventListener( 'click', function () {
            var isOpen = nav.classList.toggle( 'is-open' );
            toggle.setAttribute( 'aria-expanded', isOpen ? 'true' : 'false' );
        } );
    }

    initReveal();
    initNav();

}() );
