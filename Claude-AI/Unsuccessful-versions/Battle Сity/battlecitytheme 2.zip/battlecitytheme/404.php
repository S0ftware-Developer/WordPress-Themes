<?php
/**
 * Ошибка 404 - Game Over
 *
 * @package BattleCityTheme
 */
get_header();
?>

<div class="site-wrap" id="content">

    <section class="game-over">

        <p class="game-over__code">404</p>

        <h1 class="game-over__title">GAME OVER</h1>

        <div class="destroyed">
            <p style="font-size: 18px; margin: 0;">⬜ ⬜ ⬜<br>
               ⬜ ☒ ⬜<br>
               ⬜ ⬜ ⬜</p>
        </div>

        <p style="margin-top: 20px; color: #ff3333; font-size: 14px;">
            Эта позиция не найдена на поле боя.<br>
            Ссылка повреждена или адрес неверный.
        </p>

        <p>
            <a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">BACK TO GAME</a>
        </p>

        <div style="max-width: 420px; margin: 40px auto 0;">
            <p>Или найдите нужный уровень:</p>
            <?php get_search_form(); ?>
        </div>

    </section>

</div>

<?php get_footer();
