<?php
/**
 * BattleCityTheme v2.0 — функции и настройки темы
 * Правильная палитра, кирпичи, танки, как на NES/Денди
 *
 * @package BattleCityTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Поддержка возможностей WordPress
 */
function battlecitytheme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array(
        'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script',
    ) );
    add_theme_support( 'custom-logo', array(
        'height' => 48, 'width' => 48, 'flex-height' => true, 'flex-width' => true,
    ) );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'responsive-embeds' );

    add_image_size( 'battle-level', 600, 340, true );

    register_nav_menus( array(
        'primary' => 'Главное меню',
        'footer'  => 'Меню в футере',
    ) );

    load_theme_textdomain( 'battlecitytheme', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'battlecitytheme_setup' );

/**
 * Подключение стилей и скриптов
 */
function battlecitytheme_assets() {
    $theme_version = wp_get_theme()->get( 'Version' );

    wp_enqueue_style(
        'battlecitytheme-fonts',
        'https://fonts.googleapis.com/css2?family=Press+Start+2P&family=VT323&display=swap',
        array(), null
    );

    wp_enqueue_style(
        'battlecitytheme-style',
        get_stylesheet_uri(),
        array( 'battlecitytheme-fonts' ),
        $theme_version
    );

    wp_enqueue_style(
        'battlecitytheme-battle',
        get_template_directory_uri() . '/assets/css/battle.css',
        array( 'battlecitytheme-style' ),
        $theme_version
    );

    wp_enqueue_script(
        'battlecitytheme-script',
        get_template_directory_uri() . '/assets/js/battle.js',
        array(), $theme_version, true
    );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'battlecitytheme_assets' );

/**
 * Регистрация виджетов
 */
function battlecitytheme_widgets_init() {
    register_sidebar( array(
        'name'          => 'Сайдбар',
        'id'            => 'sidebar-main',
        'description'   => 'Боковая панель.',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => 'Футер',
        'id'            => 'footer-widgets',
        'description'   => 'Виджеты в футере.',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'battlecitytheme_widgets_init' );

/**
 * Длина анонса
 */
function battlecitytheme_excerpt_length( $length ) {
    return 20;
}
add_filter( 'excerpt_length', 'battlecitytheme_excerpt_length' );

function battlecitytheme_excerpt_more( $more ) {
    return ' ...';
}
add_filter( 'excerpt_more', 'battlecitytheme_excerpt_more' );

/**
 * Номер уровня
 */
function battlecitytheme_level_number( $position ) {
    return $position + 1;
}

/**
 * Счётчик врагов
 */
function battlecitytheme_enemy_count() {
    return max( 1, absint( get_comments_number() ) );
}

/**
 * Класс no-js для деградации
 */
function battlecitytheme_body_classes( $classes ) {
    $classes[] = 'no-js';
    return $classes;
}
add_filter( 'body_class', 'battlecitytheme_body_classes' );

/**
 * Мета-строка поста
 */
function battlecitytheme_entry_meta() {
    printf(
        '<p class="tank-level__meta">STAGE %1$s • %2$s</p>',
        esc_html( get_the_date( 'd.m.Y' ) ),
        esc_html( get_the_author() )
    );
}

/**
 * SVG танк для логотипа
 */
function battlecitytheme_tank_svg() {
    return '<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
        <!-- Корпус танка -->
        <rect x="8" y="16" width="16" height="12" fill="#ffff00" stroke="#000" stroke-width="1"/>
        <!-- Башня -->
        <circle cx="16" cy="12" r="6" fill="#ffff00" stroke="#000" stroke-width="1"/>
        <!-- Пушка -->
        <rect x="15" y="4" width="2" height="8" fill="#ffff00" stroke="#000" stroke-width="1"/>
        <!-- Гусеницы -->
        <rect x="6" y="16" width="4" height="12" fill="#000" opacity="0.3"/>
        <rect x="22" y="16" width="4" height="12" fill="#000" opacity="0.3"/>
    </svg>';
}
