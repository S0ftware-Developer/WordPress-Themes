<?php
/**
 * Сайдбар - информация о игроке
 *
 * @package BattleCityTheme
 */
?>

<aside class="sidebar" role="complementary">

    <!-- Информация о игроке в стиле игры -->
    <div class="widget game-info" aria-label="Информация о игре">
        <p>PLAYER 1</p>
        <strong><?php bloginfo( 'name' ); ?></strong>
        <p style="margin-top: 8px; font-size: 8px; color: #ffff00;">
            POSTS: <?php echo esc_html( wp_count_posts()->publish ); ?><br>
            LIVES: ×3
        </p>
    </div>

    <?php if ( is_active_sidebar( 'sidebar-main' ) ) : ?>

        <?php dynamic_sidebar( 'sidebar-main' ); ?>

    <?php else : ?>

        <section class="widget">
            <h3 class="widget-title">SEARCH</h3>
            <?php get_search_form(); ?>
        </section>

        <section class="widget">
            <h3 class="widget-title">STAGES</h3>
            <ul>
                <?php
                $battle_recent = new WP_Query( array(
                    'posts_per_page'      => 5,
                    'ignore_sticky_posts' => true,
                ) );

                while ( $battle_recent->have_posts() ) :
                    $battle_recent->the_post();
                    ?>
                    <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                <?php
                endwhile;

                wp_reset_postdata();
                ?>
            </ul>
        </section>

        <section class="widget">
            <h3 class="widget-title">CAMPAIGNS</h3>
            <ul>
                <?php wp_list_categories( array( 'title_li' => '' ) ); ?>
            </ul>
        </section>

    <?php endif; ?>

</aside>
