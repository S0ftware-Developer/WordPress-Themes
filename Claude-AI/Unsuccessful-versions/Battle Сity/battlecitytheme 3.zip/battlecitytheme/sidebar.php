<?php if ( ! is_active_sidebar( 'sidebar-main' ) ) : ?>
    <aside class="sidebar" role="complementary">
        <section class="widget">
            <h3 class="widget-title">STAGES</h3>
            <ul>
                <?php
                $posts = new WP_Query( array( 'posts_per_page' => 5 ) );
                while ( $posts->have_posts() ) : $posts->the_post();
                    echo '<li><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></li>';
                endwhile;
                wp_reset_postdata();
                ?>
            </ul>
        </section>
    </aside>
<?php else : ?>
    <aside class="sidebar" role="complementary">
        <?php dynamic_sidebar( 'sidebar-main' ); ?>
    </aside>
<?php endif;
