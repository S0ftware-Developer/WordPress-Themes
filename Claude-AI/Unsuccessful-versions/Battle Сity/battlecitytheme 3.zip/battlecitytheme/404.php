<?php get_header(); ?>

<div class="site-wrap" id="content">
    <section class="game-over">
        <p class="game-over__code">404</p>
        <h1 class="game-over__title">GAME OVER</h1>
        <p>Ваша база уничтожена. Эта страница не найдена.</p>
        <p><a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">BACK TO GAME</a></p>
    </section>
</div>

<?php get_footer();
