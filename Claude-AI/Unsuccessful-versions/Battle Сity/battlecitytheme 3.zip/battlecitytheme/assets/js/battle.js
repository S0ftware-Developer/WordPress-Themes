(function() {
    'use strict';
    document.body.classList.remove('no-js');

    function initReveal() {
        var entries = document.querySelectorAll('.entry');
        if (!('IntersectionObserver' in window)) {
            entries.forEach(e => e.style.opacity = '1');
            return;
        }

        new IntersectionObserver(function(entries) {
            entries.forEach((entry, i) => {
                if (entry.isIntersecting) {
                    setTimeout(() => {
                        entry.target.style.opacity = '1';
                    }, i * 100);
                }
            });
        }, { threshold: 0.15 }).observe(entries[0] || {});
    }

    initReveal();
})();
