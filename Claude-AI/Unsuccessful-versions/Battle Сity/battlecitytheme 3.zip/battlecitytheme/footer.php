<?php
/**
 * Футер
 */
?>

<footer class="site-footer">
    <div class="footer-inner">
        <p>
            &copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?>
            <?php bloginfo( 'name' ); ?> — The website was made by Andrei Orlov: orlovandrei.space
        </p>
        <?php if ( has_nav_menu( 'footer' ) ) : ?>
            <nav>
                <?php wp_nav_menu( array(
                    'theme_location' => 'footer',
                    'container' => false,
                    'depth' => 1,
                ) ); ?>
            </nav>
        <?php endif; ?>
        <p><a href="#top">↑ TOP</a></p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
