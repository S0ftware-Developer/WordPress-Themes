<?php get_header(); ?>

<div class="site-wrap" id="content">
    <div class="site-main-area">
        <main class="site-main">

            <?php if ( is_home() && ! is_front_page() ) : ?>
                <h1><?php single_post_title(); ?></h1>
            <?php elseif ( is_archive() ) : ?>
                <h1><?php the_archive_title(); ?></h1>
            <?php elseif ( is_search() ) : ?>
                <h1>SEARCH: <?php echo esc_html( get_search_query() ); ?></h1>
            <?php endif; ?>

            <?php if ( have_posts() ) : ?>
                <?php while ( have_posts() ) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
                        <h2 class="entry-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>
                        <p class="entry-meta">
                            <?php echo esc_html( get_the_date() ); ?> • <?php echo esc_html( get_the_author() ); ?>
                        </p>
                        <?php if ( has_post_thumbnail() ) : ?>
                            <a href="<?php the_permalink(); ?>">
                                <?php the_post_thumbnail( 'battle-thumb' ); ?>
                            </a>
                        <?php endif; ?>
                        <div class="entry-content"><?php the_excerpt(); ?></div>
                        <p><a class="btn" href="<?php the_permalink(); ?>">READ</a></p>
                    </article>
                <?php endwhile; ?>

                <nav class="pagination">
                    <?php echo paginate_links( array( 'prev_text' => '← PREV', 'next_text' => 'NEXT →' ) ); ?>
                </nav>
            <?php else : ?>
                <div class="entry">
                    <h2>NO POSTS</h2>
                    <?php get_search_form(); ?>
                </div>
            <?php endif; ?>

        </main>
        <?php get_sidebar(); ?>
    </div>
</div>

<?php get_footer();
