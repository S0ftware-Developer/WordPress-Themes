<?php
/**
 * Шапка с танком и меню
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- БОЕВОЕ ПОЛЕ 13x13 КАК НА NES -->
<div class="battle-field" aria-hidden="true">
    <div class="battle-grid">
        <!-- Паттерн уровня (кирпичи и стены) генерируется PHP -->
        <?php
        // Паттерн классического уровня Battle City
        $level_pattern = array(
            'BBBBBSBBBBBBB',
            'BBBBBBBBBBBBB',
            'BBSBBBBBBSBBB',
            'BBBBBBBBBBBBB',
            'BBBSBBBBBBBBB',
            'BBBBBBBBBBBBB',
            'BBBBBSBBSBBB',
            'BBBBBBBBBBBBB',
            'BBBBSBBSBBBB',
            'BBBBBBBBBBBBB',
            'BBSBBBBBBSBBB',
            'BBBBBBBBBBBBB',
            'BBBBBSBBBBBBB',
        );

        $idx = 0;
        foreach ( $level_pattern as $row => $cols ) {
            for ( $col = 0; $col < 13; $col++ ) {
                $cell = $cols[ $col ];
                if ( $cell === 'B' ) {
                    echo '<div class="brick grid-row-' . $row . ' grid-col-' . $col . '"></div>';
                } elseif ( $cell === 'S' ) {
                    echo '<div class="steel grid-row-' . $row . ' grid-col-' . $col . '"></div>';
                } else {
                    echo '<div class="empty grid-row-' . $row . ' grid-col-' . $col . '"></div>';
                }
            }
        }
        ?>
    </div>

    <!-- БАЗА (здание) в центре -->
    <div class="base">A</div>
</div>

<a class="screen-reader-text" href="#content">Перейти к содержимому</a>

<header class="site-header" id="top">
    <div class="header-inner">
        <div class="brand">
            <div class="logo-tank" aria-hidden="true"></div>
            <div>
                <?php if ( is_front_page() ) : ?>
                    <h1 class="site-title">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
                    </h1>
                <?php else : ?>
                    <p class="site-title">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
                    </p>
                <?php endif; ?>
            </div>
        </div>

        <nav class="main-nav" id="primary-menu" aria-label="Главное меню">
            <?php
            if ( has_nav_menu( 'primary' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'container' => false,
                    'depth' => 1,
                ) );
            }
            ?>
        </nav>
    </div>
</header>
