<?php get_header(); ?>

<div class="site-wrap" id="content">
    <div class="site-main-area">
        <main class="site-main">
            <?php while ( have_posts() ) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
                    <h1><?php the_title(); ?></h1>
                    <?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'large' ); endif; ?>
                    <div class="entry-content"><?php the_content(); ?></div>
                </article>
                <?php if ( comments_open() ) : comments_template(); endif; ?>
            <?php endwhile; ?>
        </main>
        <?php get_sidebar(); ?>
    </div>
</div>

<?php get_footer();
