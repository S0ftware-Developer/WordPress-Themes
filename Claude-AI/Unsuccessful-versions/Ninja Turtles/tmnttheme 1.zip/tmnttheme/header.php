<?php
/**
 * Шапка сайта: логотип TMNT и меню-трубы
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#content">Перейти к содержимому</a>

<header class="site-header">

	<!-- Верхняя часть: ночное небо, небоскрёбы, логотип -->
	<div class="header-top">
		<div class="skyline" aria-hidden="true"></div>

		<div class="header-inner">
			<a class="tmnt-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
				<span class="logo-line">Teenage Mutant</span>
				<span class="logo-main">Ninja Turtles</span>
				<span class="logo-sub"><?php bloginfo( 'name' ); ?></span>
			</a>
		</div>

		<!-- Летящая ниндзя-звезда (анимация в animations.css) -->
		<span class="shuriken-fly" aria-hidden="true"></span>
	</div>

	<!-- Главное меню в виде канализационных труб -->
	<nav class="sewer-nav" aria-label="Главное меню">
		<?php
		wp_nav_menu( array(
			'theme_location' => 'primary',
			'container'      => false,
			'menu_class'     => 'sewer-menu',
			'depth'          => 1,
			'fallback_cb'    => 'tmnt_menu_fallback',
		) );
		?>
	</nav>

</header>

<main id="content" class="site-main">
