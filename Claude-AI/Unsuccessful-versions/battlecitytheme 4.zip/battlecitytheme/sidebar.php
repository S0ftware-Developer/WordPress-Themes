<?php if ( is_active_sidebar( 'sidebar-main' ) ) : ?>
    <aside class="sidebar"><?php dynamic_sidebar( 'sidebar-main' ); ?></aside>
<?php else : ?>
    <aside class="sidebar">
        <section class="widget">
            <h3 class="widget-title">POSTS</h3>
            <ul>
                <?php $posts = new WP_Query( array( 'posts_per_page' => 5 ) );
                while ( $posts->have_posts() ) : $posts->the_post(); ?>
                    <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                <?php endwhile; wp_reset_postdata(); ?>
            </ul>
        </section>
    </aside>
<?php endif;
