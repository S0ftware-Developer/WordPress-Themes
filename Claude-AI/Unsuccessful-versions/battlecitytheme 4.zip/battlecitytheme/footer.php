<?php ?>

<footer class="site-footer">
    <div class="footer-inner">
        <p>&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?> — The website was made by Andrei Orlov: orlovandrei.space</p>
        <?php has_nav_menu( 'footer' ) ? wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'depth' => 1 ) ) : ''; ?>
        <p><a href="#top">↑</a></p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
