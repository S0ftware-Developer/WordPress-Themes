<?php get_header(); ?>
<div class="site-wrap" id="content">
    <div class="site-main-area">
        <main class="site-main">
            <?php while ( have_posts() ) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
                    <h1 class="entry-title"><?php the_title(); ?></h1>
                    <p class="entry-meta"><?php echo esc_html( get_the_date() ); ?> • <?php echo esc_html( get_the_author() ); ?></p>
                    <?php if ( has_post_thumbnail() ) : ?><?php the_post_thumbnail( 'large' ); ?><?php endif; ?>
                    <div class="entry-content"><?php the_content(); ?></div>
                </article>
                <nav class="post-nav"><?php previous_post_link( '%link', '← %title' ); ?><?php next_post_link( '%link', '%title →' ); ?></nav>
                <?php if ( comments_open() ) : comments_template(); endif; ?>
            <?php endwhile; ?>
        </main>
        <?php get_sidebar(); ?>
    </div>
</div>
<?php get_footer();
