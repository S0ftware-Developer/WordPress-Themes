<?php ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="screen-reader-text" href="#content">К содержимому</a>

<header class="site-header" id="top">
    <div class="header-inner">
        <div class="brand">
            <div class="logo-tank"></div>
            <div>
                <?php if ( is_front_page() ) : ?>
                    <h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
                <?php else : ?>
                    <p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a></p>
                <?php endif; ?>
            </div>
        </div>
        <nav class="main-nav" id="primary-menu">
            <?php has_nav_menu( 'primary' ) ? wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'depth' => 1 ) ) : ''; ?>
        </nav>
    </div>
</header>
