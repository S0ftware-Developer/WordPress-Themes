<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function battlecitytheme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
    add_image_size( 'battle-thumb', 300, 200, true );
    register_nav_menus( array( 'primary' => 'Главное меню', 'footer' => 'Меню в футере' ) );
    load_theme_textdomain( 'battlecitytheme', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'battlecitytheme_setup' );

function battlecitytheme_assets() {
    $v = wp_get_theme()->get( 'Version' );
    wp_enqueue_style( 'battlecitytheme-fonts', 'https://fonts.googleapis.com/css2?family=Press+Start+2P&family=VT323&display=swap', array(), null );
    wp_enqueue_style( 'battlecitytheme-style', get_stylesheet_uri(), array(), $v );
    wp_enqueue_script( 'battlecitytheme-script', get_template_directory_uri() . '/assets/js/battle.js', array(), $v, true );
}
add_action( 'wp_enqueue_scripts', 'battlecitytheme_assets' );

function battlecitytheme_widgets_init() {
    register_sidebar( array(
        'name' => 'Сайдбар',
        'id' => 'sidebar-main',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
}
add_action( 'widgets_init', 'battlecitytheme_widgets_init' );

function battlecitytheme_body_classes( $classes ) { $classes[] = 'no-js'; return $classes; }
add_filter( 'body_class', 'battlecitytheme_body_classes' );
