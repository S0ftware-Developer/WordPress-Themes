<?php
/**
 * Главный шаблон: лента постов в виде карточек-черепашек
 */
get_header();
?>

<?php if ( is_home() && ! is_paged() ) : ?>
	<!-- Приветствие показываем только на первой странице главной -->
	<section class="hero">
		<h1 class="hero-title">Добро пожаловать в логово!</h1>
		<p>Игры, ретро, проекты и немного пиццы. Выбирай черепашку и читай.</p>
	</section>
<?php endif; ?>

<?php if ( have_posts() ) : ?>

	<div class="turtle-grid">
		<?php
		while ( have_posts() ) :
			the_post();
			// Каждая карточка подключается из отдельного шаблона
			get_template_part( 'template-parts/card', 'turtle' );
		endwhile;
		?>
	</div>

	<?php
	// Постраничная навигация
	the_posts_pagination( array(
		'prev_text' => '&laquo; Назад',
		'next_text' => 'Вперёд &raquo;',
	) );
	?>

<?php else : ?>

	<section class="pixel-box">
		<h1 class="page-title">Тут пусто!</h1>
		<p>Черепашки съели всю пиццу, а записей пока нет.</p>
		<?php get_search_form(); ?>
	</section>

<?php endif; ?>

<?php get_footer(); ?>
