<?php
/**
 * Страница 404
 */
get_header(); ?>

<section class="pixel-box error-404">
	<img class="manhole"
	     src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/manhole.svg' ); ?>"
	     alt="" width="120" height="120">
	<h1 class="page-title">404 — Кровля обвалилась!</h1>
	<p>Ты провалился в канализацию, а этой страницы тут нет. Сплинтер советует вернуться в логово.</p>
	<a class="btn-pizza" href="<?php echo esc_url( home_url( '/' ) ); ?>">
		В логово <span class="btn-star" aria-hidden="true"></span>
	</a>
	<?php get_search_form(); ?>
</section>

<?php get_footer(); ?>
