/* Скрипты темы TMNTTheme.
   Здесь появятся звуки и мини-игра с пиццей (см. Шаг 5). */
document.addEventListener('DOMContentLoaded', function () {
  // Пока пусто
});
