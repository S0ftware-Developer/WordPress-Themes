<?php
/**
 * Футер с паттерном из пиццы
 */
?>
</main><!-- /.site-main -->

<footer class="site-footer">
	<div class="footer-inner">

		<p class="footer-slogan">Кавабанга! Пицца — это жизнь!</p>

		<div class="pizza-row" aria-hidden="true">🍕🍕🍕🍕🍕</div>

		<?php
		// Меню футера выводится только если оно назначено в админке
		wp_nav_menu( array(
			'theme_location' => 'footer',
			'container'      => false,
			'menu_class'     => 'footer-menu',
			'depth'          => 1,
			'fallback_cb'    => false,
		) );
		?>

		<p class="footer-copy">
			&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?>
			<?php bloginfo( 'name' ); ?> · Сделано с любовью к ретро-играм и пицце
		</p>

		<!-- Обязательное указание автора сайта -->
		<p class="footer-credit">
			The website was made by Andrei Orlov:
			<a href="https://orlovandrei.space" target="_blank" rel="noopener">orlovandrei.space</a>
		</p>

		<p class="footer-copy">Неофициальный фан-сайт. Teenage Mutant Ninja Turtles — торговая марка их владельцев.</p>

	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
