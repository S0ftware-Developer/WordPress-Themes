<?php
/**
 * Обычная страница (например, «Обо мне» или «Портфолио»)
 */
get_header();

while ( have_posts() ) :
	the_post(); ?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'pixel-box' ); ?>>
		<h1 class="page-title"><?php the_title(); ?></h1>
		<div class="entry-content"><?php the_content(); ?></div>
	</article>
<?php endwhile;

get_footer();
