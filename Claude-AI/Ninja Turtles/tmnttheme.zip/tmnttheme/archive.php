<?php
/**
 * Архивы: рубрики, теги, авторы, даты
 */
get_header(); ?>

<header class="pixel-box">
	<?php
	the_archive_title( '<h1 class="page-title">', '</h1>' );
	the_archive_description( '<div class="entry-content">', '</div>' );
	?>
</header>

<?php if ( have_posts() ) : ?>
	<div class="turtle-grid">
		<?php
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/card', 'turtle' );
		endwhile;
		?>
	</div>
	<?php the_posts_pagination( array( 'prev_text' => '&laquo; Назад', 'next_text' => 'Вперёд &raquo;' ) ); ?>
<?php else : ?>
	<p>В этой части канализации пока ничего нет.</p>
<?php endif; ?>

<?php get_footer(); ?>
