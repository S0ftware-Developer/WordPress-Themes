<?php
/**
 * Функции темы TMNTTheme
 */

// Защита от прямого обращения к файлу
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Базовая настройка темы: поддержка функций WordPress и регистрация меню.
 */
function tmnt_setup() {
	// Заголовок страницы формирует сам WordPress
	add_theme_support( 'title-tag' );

	// Миниатюры записей и свой размер для карточек
	add_theme_support( 'post-thumbnails' );
	add_image_size( 'tmnt-card', 600, 400, true );

	// Ссылки на RSS-ленты в <head>
	add_theme_support( 'automatic-feed-links' );

	// Семантическая HTML5-разметка для стандартных блоков
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script',
	) );

	// Два места для меню: главное (трубы) и в футере
	register_nav_menus( array(
		'primary' => 'Главное меню (канализационные трубы)',
		'footer'  => 'Меню в футере',
	) );
}
add_action( 'after_setup_theme', 'tmnt_setup' );

/**
 * Подключение стилей, шрифта и скриптов.
 */
function tmnt_enqueue_assets() {
	$version = wp_get_theme()->get( 'Version' );

	// Пиксельный шрифт Press Start 2P (поддерживает кириллицу)
	wp_enqueue_style(
		'tmnt-fonts',
		'https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap',
		array(),
		null
	);

	// Основной стиль темы (style.css)
	wp_enqueue_style( 'tmnt-style', get_stylesheet_uri(), array( 'tmnt-fonts' ), $version );

	// Анимации (бросок звезды и др.)
	wp_enqueue_style(
		'tmnt-animations',
		get_template_directory_uri() . '/assets/css/animations.css',
		array( 'tmnt-style' ),
		$version
	);

	// Скрипт темы (пока пустой; сюда придут звуки и мини-игра), грузим в футере
	wp_enqueue_script(
		'tmnt-main',
		get_template_directory_uri() . '/assets/js/main.js',
		array(),
		$version,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'tmnt_enqueue_assets' );

/**
 * Данные о черепашках. Цвет банданы задаётся в CSS через класс.
 * Порядок карточек: Леонардо, Рафаэль, Донателло, Микеланджело.
 *
 * @param int $index Порядковый номер поста в цикле.
 * @return array
 */
function tmnt_get_turtle( $index ) {
	$turtles = array(
		array( 'class' => 'leo',    'name' => 'Леонардо',     'weapon' => 'Оружие: катаны' ),
		array( 'class' => 'raph',   'name' => 'Рафаэль',      'weapon' => 'Оружие: сай' ),
		array( 'class' => 'donnie', 'name' => 'Донателло',    'weapon' => 'Оружие: посох бо' ),
		array( 'class' => 'mike',   'name' => 'Микеланджело', 'weapon' => 'Оружие: нунчаки' ),
	);
	return $turtles[ absint( $index ) % 4 ];
}

/**
 * Запасное меню, если в админке ещё не создано ни одного меню.
 */
function tmnt_menu_fallback() {
	echo '<ul class="sewer-menu">';
	echo '<li class="current-menu-item"><a href="' . esc_url( home_url( '/' ) ) . '">Логово</a></li>';
	wp_list_pages( array( 'title_li' => '', 'depth' => 1 ) );
	echo '</ul>';
}

/**
 * Короткие анонсы: 25 слов и многоточие.
 */
add_filter( 'excerpt_length', function () {
	return 25;
}, 999 );

add_filter( 'excerpt_more', function () {
	return '…';
} );
