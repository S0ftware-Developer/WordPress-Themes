<?php
/**
 * Карточка поста в виде черепашки.
 * Цвет банданы зависит от порядкового номера поста в цикле.
 */
global $wp_query;
$turtle = tmnt_get_turtle( $wp_query->current_post );
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'turtle-card turtle-' . $turtle['class'] ); ?>>

	<!-- «Голова» с банданой и глазами -->
	<header class="turtle-head">
		<span class="turtle-name"><?php echo esc_html( $turtle['name'] ); ?></span>
		<div class="bandana" aria-hidden="true">
			<span class="eye"></span>
			<span class="eye"></span>
			<span class="bandana-tail tail-a"></span>
			<span class="bandana-tail tail-b"></span>
		</div>
	</header>

	<div class="turtle-body">

		<?php if ( has_post_thumbnail() ) : ?>
			<a class="turtle-thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
				<?php the_post_thumbnail( 'tmnt-card' ); ?>
			</a>
		<?php endif; ?>

		<h2 class="turtle-title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h2>

		<p class="turtle-meta">
			<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
				<?php echo esc_html( get_the_date() ); ?>
			</time>
			· <?php the_category( ', ' ); ?>
		</p>

		<div class="turtle-excerpt"><?php the_excerpt(); ?></div>

		<a class="btn-pizza" href="<?php the_permalink(); ?>">
			Читать <span class="btn-star" aria-hidden="true"></span>
		</a>

	</div>

	<!-- Нижняя полоска цвета банданы -->
	<footer class="turtle-weapon"><?php echo esc_html( $turtle['weapon'] ); ?></footer>

</article>
