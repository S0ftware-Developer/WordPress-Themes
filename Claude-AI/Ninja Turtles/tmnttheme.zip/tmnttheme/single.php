<?php
/**
 * Страница отдельной записи
 */
get_header();

while ( have_posts() ) :
	the_post(); ?>

	<article id="post-<?php the_ID(); ?>" <?php post_class( 'pixel-box' ); ?>>
		<h1 class="page-title"><?php the_title(); ?></h1>
		<p class="turtle-meta">
			<?php echo esc_html( get_the_date() ); ?> · <?php the_category( ', ' ); ?>
		</p>

		<?php if ( has_post_thumbnail() ) {
			the_post_thumbnail( 'large' );
		} ?>

		<div class="entry-content">
			<?php
			the_content();
			wp_link_pages();
			?>
		</div>

		<?php the_tags( '<p class="turtle-meta">Теги: ', ', ', '</p>' ); ?>
	</article>

	<?php
	// Ссылки на предыдущую и следующую записи
	the_post_navigation( array(
		'prev_text' => '&laquo; %title',
		'next_text' => '%title &raquo;',
	) );

	// Комментарии, если они включены
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}
endwhile;

get_footer();
