<?php
/**
 * Подвал сайта: лента с восточным узором, лампа, меню и копирайт.
 *
 * @package AladdinTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</main><!-- #content -->

<footer class="site-footer">

	<?php // Лента с узором (тот же pattern.svg, что и в шапке) ?>
	<div class="ornament-band ornament-band--footer" aria-hidden="true"></div>

	<div class="site-footer__inner">

		<?php echo aladdin_sprite( 'lamp', 72, 'site-footer__lamp' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

		<?php // Меню подвала: показываем, только если оно назначено в «Внешний вид → Меню» ?>
		<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<nav class="footer-nav" aria-label="<?php esc_attr_e( 'Меню в подвале', 'aladdin-theme' ); ?>">
				<?php
				wp_nav_menu( array(
					'theme_location' => 'footer',
					'container'      => false,
					'depth'          => 1,
				) );
				?>
			</nav>
		<?php endif; ?>

		<p class="site-footer__copy">
			<?php
			printf(
				/* translators: 1: год, 2: название сайта */
				esc_html__( '© %1$s %2$s. Пусть ваш ковёр летит высоко.', 'aladdin-theme' ),
				esc_html( wp_date( 'Y' ) ),
				esc_html( get_bloginfo( 'name' ) )
			);
			?>
		</p>

		<?php // Подпись автора темы (обязательная) ?>
		<p class="site-footer__copy site-footer__credit">The website was made by Andrei Orlov: <a href="https://orlovandrei.space" target="_blank" rel="noopener">orlovandrei.space</a></p>

		<a class="button" href="#top"><?php esc_html_e( 'Взлететь наверх', 'aladdin-theme' ); ?></a>
	</div>

	<?php // Нижняя лента узора — «край ковра» ?>
	<div class="ornament-band ornament-band--footer" aria-hidden="true"></div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
