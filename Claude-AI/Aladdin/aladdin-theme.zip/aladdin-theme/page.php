<?php
/**
 * Шаблон статичных страниц («Обо мне», «Портфолио» и т. п.).
 *
 * @package AladdinTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="container">
	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>

			<header class="entry__header">
				<h1 class="entry__title"><?php the_title(); ?></h1>
			</header>

			<?php if ( has_post_thumbnail() ) : ?>
				<div class="entry__thumb"><?php the_post_thumbnail( 'large' ); ?></div>
			<?php endif; ?>

			<div class="entry__content">
				<?php
				the_content();

				wp_link_pages( array(
					'before' => '<p class="page-links">' . esc_html__( 'Страницы:', 'aladdin-theme' ),
					'after'  => '</p>',
				) );
				?>
			</div>
		</article>

		<?php
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
		?>

	<?php endwhile; ?>
</div>

<?php
get_footer();
