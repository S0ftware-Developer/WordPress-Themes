<?php
/**
 * Функции и настройки темы AladdinTheme.
 *
 * @package AladdinTheme
 */

// Защита: файл нельзя открыть напрямую по адресу в браузере
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Версия темы берём из style.css — она же используется для сброса кэша стилей
define( 'ALADDIN_VERSION', wp_get_theme()->get( 'Version' ) );


/* ==========================================================================
   1. НАСТРОЙКА ТЕМЫ: поддержка функций WordPress и регистрация меню
   ========================================================================== */
function aladdin_setup() {

	// Файлы переводов лежат в папке languages
	load_theme_textdomain( 'aladdin-theme', get_template_directory() . '/languages' );

	// WordPress сам формирует тег <title>
	add_theme_support( 'title-tag' );

	// Миниатюры записей и адаптивные встраиваемые видео
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );

	// RSS-ссылки в <head>
	add_theme_support( 'automatic-feed-links' );

	// Современная HTML5-разметка форм, комментариев и галерей
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script',
	) );

	// Свой логотип из «Внешний вид → Настроить». Если не загружен — покажем лампу.
	add_theme_support( 'custom-logo', array(
		'height'      => 64,
		'width'       => 96,
		'flex-height' => true,
		'flex-width'  => true,
	) );

	// Размер картинки для карточек-приключений (16:9)
	add_image_size( 'aladdin-card', 640, 360, true );

	// Два места для меню: в шапке и в подвале
	register_nav_menus( array(
		'primary' => __( 'Главное меню (шапка)', 'aladdin-theme' ),
		'footer'  => __( 'Меню в подвале', 'aladdin-theme' ),
	) );
}
add_action( 'after_setup_theme', 'aladdin_setup' );

// Максимальная ширина контента (нужна для встраиваемых объектов)
function aladdin_content_width() {
	$GLOBALS['content_width'] = 720;
}
add_action( 'after_setup_theme', 'aladdin_content_width', 0 );


/* ==========================================================================
   2. ПОДКЛЮЧЕНИЕ СТИЛЕЙ, ШРИФТОВ И СКРИПТОВ
   ========================================================================== */
function aladdin_scripts() {

	// Шрифты Google: «Press Start 2P» (заголовки, с кириллицей) и «PT Sans» (основной текст)
	wp_enqueue_style(
		'aladdin-fonts',
		'https://fonts.googleapis.com/css2?family=Press+Start+2P&family=PT+Sans:ital,wght@0,400;0,700;1,400&display=swap',
		array(),
		null
	);

	// Главный файл стилей темы (style.css в корне)
	wp_enqueue_style( 'aladdin-style', get_stylesheet_uri(), array( 'aladdin-fonts' ), ALADDIN_VERSION );

	// Анимации: ковёр-самолёт, джинн, лампа
	wp_enqueue_style(
		'aladdin-animations',
		get_template_directory_uri() . '/assets/css/animations.css',
		array( 'aladdin-style' ),
		ALADDIN_VERSION
	);

	// Скрипт темы (мобильное меню; задел под звуки и мини-игру). Грузится в подвале, с defer.
	wp_enqueue_script(
		'aladdin-main',
		get_template_directory_uri() . '/assets/js/main.js',
		array(),
		ALADDIN_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	// Скрипт ответов на комментарии (только там, где он нужен)
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'aladdin_scripts' );

// Ускоряем загрузку шрифтов: заранее открываем соединение с серверами Google
function aladdin_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		$urls[] = 'https://fonts.googleapis.com';
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'anonymous',
		);
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'aladdin_resource_hints', 10, 2 );


/* ==========================================================================
   3. МЕНЮ: запасной вариант, если меню ещё не создано в админке
   ========================================================================== */
function aladdin_fallback_menu() {
	echo '<ul id="primary-menu" class="menu">';
	echo '<li class="menu-item"><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Главная', 'aladdin-theme' ) . '</a></li>';
	wp_list_pages( array(
		'title_li' => '',
		'depth'    => 1,
	) );
	echo '</ul>';
}


/* ==========================================================================
   4. ПИКСЕЛЬНЫЕ СПРАЙТЫ (лампа, ковёр, джинн, луна)
   ========================================================================== */

/**
 * Возвращает <img> с пиксельным спрайтом из assets/images.
 * Пропорции спрайтов заданы здесь, чтобы страница не «прыгала» при загрузке.
 *
 * @param string $name  Имя файла без .svg: lamp, carpet, genie, moon.
 * @param int    $width Ширина на странице в пикселях.
 * @param string $class Дополнительные CSS-классы.
 */
function aladdin_sprite( $name, $width, $class = '' ) {
	$ratios = array(
		'lamp'   => array( 34, 22 ),
		'carpet' => array( 50, 20 ),
		'genie'  => array( 34, 50 ),
		'moon'   => array( 16, 16 ),
	);

	if ( ! isset( $ratios[ $name ] ) ) {
		return '';
	}

	$height = round( $width * $ratios[ $name ][1] / $ratios[ $name ][0] );
	$url    = get_template_directory_uri() . '/assets/images/' . $name . '.svg';

	return sprintf(
		'<img class="pixel-img %1$s" src="%2$s" width="%3$d" height="%4$d" alt="" aria-hidden="true">',
		esc_attr( $class ),
		esc_url( $url ),
		(int) $width,
		(int) $height
	);
}

/**
 * Иконка приключения по номеру карточки: лампа → ковёр → джинн → лампа…
 */
function aladdin_adventure_icon( $index ) {
	$icons = array( 'lamp', 'carpet', 'genie' );
	$name  = $icons[ (int) $index % count( $icons ) ];

	// Джинн выше остальных, поэтому даём ему меньшую ширину, чтобы влезть в ленту
	$width = ( 'genie' === $name ) ? 34 : 56;

	return aladdin_sprite( $name, $width, 'adventure__icon' );
}


/* ==========================================================================
   5. ПОМОЩНИКИ ДЛЯ ШАБЛОНОВ
   ========================================================================== */

// «Локация» приключения — это первая рубрика записи
function aladdin_location_name() {
	$categories = get_the_category();

	if ( ! empty( $categories ) && 'uncategorized' !== $categories[0]->slug ) {
		return $categories[0]->name;
	}

	return __( 'Неведомые земли', 'aladdin-theme' );
}

// Время чтения: считаем слова (в том числе кириллические) при скорости 180 слов в минуту
function aladdin_reading_time() {
	$text  = wp_strip_all_tags( get_the_content() );
	$words = preg_match_all( '/\p{L}+/u', $text );

	return max( 1, (int) ceil( $words / 180 ) );
}

// Мета-строка под заголовком: дата и «время в пути»
function aladdin_entry_meta() {
	printf(
		'<p class="entry-meta"><span class="entry-meta__item"><span class="screen-reader-text">%1$s </span><time datetime="%2$s">%3$s</time></span><span class="entry-meta__item">%4$s</span></p>',
		esc_html__( 'Дата:', 'aladdin-theme' ),
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		/* translators: %d — минуты чтения */
		esc_html( sprintf( __( 'Время в пути: %d мин', 'aladdin-theme' ), aladdin_reading_time() ) )
	);
}

// Короткий анонс для карточек: 28 слов и многоточие
function aladdin_excerpt_length() {
	return 28;
}
add_filter( 'excerpt_length', 'aladdin_excerpt_length' );

function aladdin_excerpt_more() {
	return '…';
}
add_filter( 'excerpt_more', 'aladdin_excerpt_more' );
