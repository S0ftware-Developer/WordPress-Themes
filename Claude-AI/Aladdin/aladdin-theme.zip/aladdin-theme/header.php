<?php
/**
 * Шапка сайта: небо с ковром-самолётом, логотип-лампа и меню в виде орнамента.
 *
 * @package AladdinTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php // Помечаем страницу классом «js», чтобы кнопка мобильного меню работала только при включённом JavaScript ?>
	<script>document.documentElement.className += ' js';</script>
	<?php wp_head(); ?>
</head>

<body id="top" <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Перейти к содержимому', 'aladdin-theme' ); ?></a>

<?php // Ночное небо Аграбы: звёзды, луна и летящий ковёр (чисто декоративный слой) ?>
<div class="sky" aria-hidden="true">
	<?php echo aladdin_sprite( 'moon', 72, 'sky__moon' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	<div class="sky__carpet"><?php echo aladdin_sprite( 'carpet', 160 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
</div>

<header class="site-header">
	<div class="site-header__inner">

		<?php // Логотип: свой из настроек или лампа по умолчанию ?>
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php
			if ( has_custom_logo() ) {
				echo wp_kses_post( get_custom_logo() );
			} else {
				echo aladdin_sprite( 'lamp', 96, 'brand__logo' ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			?>
			<div class="brand__text">
				<?php // На главной название сайта — заголовок первого уровня, на остальных страницах — обычный абзац ?>
				<?php if ( is_front_page() && is_home() ) : ?>
					<h1 class="brand__title"><?php bloginfo( 'name' ); ?></h1>
				<?php else : ?>
					<p class="brand__title"><?php bloginfo( 'name' ); ?></p>
				<?php endif; ?>

				<?php $description = get_bloginfo( 'description', 'display' ); ?>
				<?php if ( $description ) : ?>
					<p class="brand__tagline"><?php echo esc_html( $description ); ?></p>
				<?php endif; ?>
			</div>
		</a>

		<?php // Кнопка меню для телефонов; логика — в assets/js/main.js ?>
		<button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-navigation">
			<?php esc_html_e( 'Меню', 'aladdin-theme' ); ?>
		</button>
	</div>

	<?php // Меню: пункты оформлены как пиксельные арки с ромбом-орнаментом (см. style.css, раздел 5) ?>
	<nav id="site-navigation" class="main-nav" aria-label="<?php esc_attr_e( 'Главное меню', 'aladdin-theme' ); ?>">
		<?php
		wp_nav_menu( array(
			'theme_location' => 'primary',
			'menu_id'        => 'primary-menu',
			'container'      => false,
			'depth'          => 1,
			'fallback_cb'    => 'aladdin_fallback_menu',
		) );
		?>
	</nav>

	<?php // Лента с восточным узором под меню ?>
	<div class="ornament-band" aria-hidden="true"></div>
</header>

<main id="content" class="site-main">
