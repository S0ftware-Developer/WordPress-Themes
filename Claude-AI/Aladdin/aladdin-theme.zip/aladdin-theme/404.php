<?php
/**
 * Страница ошибки 404: «Джинн не нашёл эту пещеру».
 *
 * @package AladdinTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="container">
	<section class="lost">

		<?php echo aladdin_sprite( 'genie', 120, 'lost__genie' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

		<div class="dialogue">
			<h1 class="dialogue__title"><?php esc_html_e( 'Джинн не нашёл эту пещеру', 'aladdin-theme' ); ?></h1>
			<p><?php esc_html_e( 'Страницы по этому адресу нет: возможно, её унесло песчаной бурей или адрес набран с ошибкой. Поищи нужное приключение или вернись на главную.', 'aladdin-theme' ); ?></p>
		</div>

		<?php get_search_form(); ?>

		<a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'На главную', 'aladdin-theme' ); ?></a>
	</section>
</div>

<?php
get_footer();
