<?php
/**
 * Главный шаблон: список постов в виде карточек-«приключений».
 * Он же обслуживает архивы (рубрики, метки, даты) и результаты поиска.
 *
 * @package AladdinTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="container">

	<?php if ( is_home() && ! is_paged() ) : ?>

		<?php // Приветствие джинна — только на первой странице главной ?>
		<section class="hero" aria-labelledby="hero-title">
			<?php echo aladdin_sprite( 'genie', 104, 'hero__genie' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<div class="dialogue">
				<h2 id="hero-title" class="dialogue__title"><?php esc_html_e( 'Выбери своё приключение!', 'aladdin-theme' ); ?></h2>
				<p><?php esc_html_e( 'Эй, странник! У меня для тебя три желания… то есть целая пещера свежих историй. Выбирай любую и садись на ковёр.', 'aladdin-theme' ); ?></p>
			</div>
		</section>

	<?php elseif ( is_archive() ) : ?>

		<?php // Заголовок архива: рубрика («локация»), метка, автор или дата ?>
		<header class="page-header">
			<?php the_archive_title( '<h1 class="page-header__title">', '</h1>' ); ?>
			<?php the_archive_description( '<p class="page-header__text">', '</p>' ); ?>
		</header>

	<?php elseif ( is_search() ) : ?>

		<header class="page-header">
			<h1 class="page-header__title">
				<?php
				/* translators: %s — поисковый запрос */
				printf( esc_html__( 'Поиск по пещере: %s', 'aladdin-theme' ), '<span>' . esc_html( get_search_query() ) . '</span>' );
				?>
			</h1>
		</header>

	<?php endif; ?>

	<?php if ( have_posts() ) : ?>

		<div class="adventures">
			<?php
			// Номер карточки нужен, чтобы чередовать иконки: лампа → ковёр → джинн
			$card_index = 0;

			while ( have_posts() ) :
				the_post();
				?>

				<article id="post-<?php the_ID(); ?>" <?php post_class( 'adventure' ); ?>>

					<?php // Лента карточки: иконка приключения и «локация» (рубрика) ?>
					<div class="adventure__banner">
						<?php echo aladdin_adventure_icon( $card_index ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<p class="adventure__location"><?php echo esc_html( aladdin_location_name() ); ?></p>
					</div>

					<?php // Миниатюра — только если она задана у записи ?>
					<?php if ( has_post_thumbnail() ) : ?>
						<a class="adventure__thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
							<?php the_post_thumbnail( 'aladdin-card' ); ?>
						</a>
					<?php endif; ?>

					<div class="adventure__body">
						<h2 class="adventure__title">
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</h2>

						<?php aladdin_entry_meta(); ?>

						<div class="adventure__excerpt"><?php the_excerpt(); ?></div>

						<a class="button" href="<?php the_permalink(); ?>">
							<?php esc_html_e( 'В путь!', 'aladdin-theme' ); ?>
							<span class="screen-reader-text"><?php the_title(); ?></span>
						</a>
					</div>
				</article>

				<?php $card_index++; ?>
			<?php endwhile; ?>
		</div>

		<?php // Пагинация: «Назад в путь» / «Дальше» ?>
		<?php
		the_posts_pagination( array(
			'mid_size'           => 1,
			'prev_text'          => esc_html__( 'Назад', 'aladdin-theme' ),
			'next_text'          => esc_html__( 'Дальше', 'aladdin-theme' ),
			'screen_reader_text' => esc_html__( 'Страницы приключений', 'aladdin-theme' ),
		) );
		?>

	<?php else : ?>

		<?php // Ничего не найдено ?>
		<div class="lost">
			<div class="dialogue">
				<h2 class="dialogue__title"><?php esc_html_e( 'Здесь пока пусто', 'aladdin-theme' ); ?></h2>
				<p><?php esc_html_e( 'Джинн обыскал всю пещеру и не нашёл ни одного приключения. Попробуй другой запрос или загляни на главную.', 'aladdin-theme' ); ?></p>
			</div>
			<?php get_search_form(); ?>
		</div>

	<?php endif; ?>

</div>

<?php
get_footer();
