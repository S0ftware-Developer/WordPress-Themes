<?php
/**
 * Шаблон одиночной записи — страница одного «приключения».
 *
 * @package AladdinTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="container">
	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>

			<header class="entry__header">
				<h1 class="entry__title"><?php the_title(); ?></h1>

				<?php // Дата и время чтения ?>
				<?php aladdin_entry_meta(); ?>
			</header>

			<?php // Большая картинка приключения (если есть) ?>
			<?php if ( has_post_thumbnail() ) : ?>
				<div class="entry__thumb"><?php the_post_thumbnail( 'large' ); ?></div>
			<?php endif; ?>

			<div class="entry__content">
				<?php
				the_content();

				// Постраничные записи (<!--nextpage-->)
				wp_link_pages( array(
					'before' => '<p class="page-links">' . esc_html__( 'Страницы:', 'aladdin-theme' ),
					'after'  => '</p>',
				) );
				?>
			</div>

			<footer class="entry__footer">
				<?php // Рубрика — «локация», метки — «спутники» ?>
				<p class="entry__tags">
					<?php
					/* translators: %s — название рубрики */
					printf( esc_html__( 'Локация: %s', 'aladdin-theme' ), esc_html( aladdin_location_name() ) );
					?>
				</p>
				<?php the_tags( '<p class="entry__tags">' . esc_html__( 'Спутники в пути: ', 'aladdin-theme' ), ', ', '</p>' ); ?>
			</footer>
		</article>

		<?php // Переход между приключениями ?>
		<?php
		the_post_navigation( array(
			'prev_text'          => esc_html__( 'Предыдущее приключение: %title', 'aladdin-theme' ),
			'next_text'          => esc_html__( 'Следующее приключение: %title', 'aladdin-theme' ),
			'screen_reader_text' => esc_html__( 'Навигация по приключениям', 'aladdin-theme' ),
		) );
		?>

		<?php // Комментарии (если открыты или уже есть) ?>
		<?php
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
		?>

	<?php endwhile; ?>
</div>

<?php
get_footer();
