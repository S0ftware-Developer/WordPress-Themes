<?php
/**
 * Главный шаблон: список постов в виде карточек-«расследований».
 * Он же обслуживает архивы (рубрики, метки, даты) и результаты поиска.
 *
 * @package ChipNDaleTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="container">

	<?php if ( is_home() && ! is_paged() ) : ?>

		<?php // Сообщение из штаба — только на первой странице главной ?>
		<section class="hero" aria-labelledby="hero-title">
			<?php echo chipndale_sprite( 'magnifier', 120, 'hero__icon' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<div class="radio">
				<h2 id="hero-title" class="radio__title"><?php esc_html_e( 'Сообщение из штаба', 'chipndale-theme' ); ?></h2>
				<p class="radio__text"><?php esc_html_e( 'Внимание, спасатели! Поступили новые дела: тайны, находки и игры. Берите лупу и открывайте любое.', 'chipndale-theme' ); ?></p>
			</div>
		</section>

	<?php elseif ( is_archive() ) : ?>

		<?php // Заголовок архива: рубрика («отдел»), метка, автор или дата ?>
		<header class="page-header">
			<?php the_archive_title( '<h1 class="page-header__title">', '</h1>' ); ?>
			<?php the_archive_description( '<p class="page-header__text">', '</p>' ); ?>
		</header>

	<?php elseif ( is_search() ) : ?>

		<header class="page-header">
			<h1 class="page-header__title">
				<?php
				/* translators: %s — поисковый запрос */
				printf( esc_html__( 'Поиск улик: %s', 'chipndale-theme' ), '<span>' . esc_html( get_search_query() ) . '</span>' );
				?>
			</h1>
		</header>

	<?php endif; ?>

	<?php if ( have_posts() ) : ?>

		<div class="cases">
			<?php
			// Номер карточки нужен, чтобы чередовать иконки: лупа → шестерёнка → жёлудь → самолёт
			$card_index = 0;

			while ( have_posts() ) :
				the_post();
				$status = chipndale_case_status();
				?>

				<article id="post-<?php the_ID(); ?>" <?php post_class( 'case' ); ?>>

					<?php // Вкладка папки: номер дела (это ID записи) ?>
					<p class="case__tab">
						<?php
						/* translators: %s — номер дела */
						printf( esc_html__( 'Дело № %s', 'chipndale-theme' ), esc_html( chipndale_case_number() ) );
						?>
					</p>

					<?php // Шапка карточки: отдел (рубрика), иконка и печать со статусом ?>
					<div class="case__head">
						<p class="case__department"><?php echo esc_html( chipndale_department_name() ); ?></p>
						<?php echo chipndale_case_icon( $card_index ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<?php if ( $status ) : ?>
							<p class="stamp"><?php echo esc_html( $status ); ?></p>
						<?php endif; ?>
					</div>

					<?php // Миниатюра — только если она задана у записи ?>
					<?php if ( has_post_thumbnail() ) : ?>
						<a class="case__thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
							<?php the_post_thumbnail( 'chipndale-card' ); ?>
						</a>
					<?php endif; ?>

					<div class="case__body">
						<h2 class="case__title">
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</h2>

						<?php chipndale_entry_meta(); ?>

						<div class="case__excerpt"><?php the_excerpt(); ?></div>

						<a class="button" href="<?php the_permalink(); ?>">
							<?php esc_html_e( 'Открыть дело', 'chipndale-theme' ); ?>
							<span class="screen-reader-text"><?php the_title(); ?></span>
						</a>
					</div>
				</article>

				<?php $card_index++; ?>
			<?php endwhile; ?>
		</div>

		<?php // Пагинация ?>
		<?php
		the_posts_pagination( array(
			'mid_size'           => 1,
			'prev_text'          => esc_html__( 'Назад', 'chipndale-theme' ),
			'next_text'          => esc_html__( 'Дальше', 'chipndale-theme' ),
			'screen_reader_text' => esc_html__( 'Страницы расследований', 'chipndale-theme' ),
		) );
		?>

	<?php else : ?>

		<?php // Ничего не найдено ?>
		<div class="lost">
			<?php echo chipndale_sprite( 'magnifier', 88, 'lost__icon' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<div class="radio">
				<h2 class="radio__title"><?php esc_html_e( 'Улик не найдено', 'chipndale-theme' ); ?></h2>
				<p class="radio__text"><?php esc_html_e( 'По этому запросу дел нет. Попробуй другие слова или вернись на главную.', 'chipndale-theme' ); ?></p>
			</div>
			<?php get_search_form(); ?>
		</div>

	<?php endif; ?>

</div>

<?php
get_footer();
