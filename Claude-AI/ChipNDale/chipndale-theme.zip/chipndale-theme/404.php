<?php
/**
 * Страница ошибки 404: «След потерян».
 *
 * @package ChipNDaleTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="container">
	<section class="lost">

		<?php echo chipndale_sprite( 'magnifier', 110, 'lost__icon' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

		<div class="radio">
			<h1 class="radio__title"><?php esc_html_e( 'След потерян', 'chipndale-theme' ); ?></h1>
			<p class="radio__text"><?php esc_html_e( 'Страницы по этому адресу нет: возможно, дело перенесли в архив или адрес набран с ошибкой. Поищи нужное расследование или вернись на базу.', 'chipndale-theme' ); ?></p>
		</div>

		<?php get_search_form(); ?>

		<a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'На базу', 'chipndale-theme' ); ?></a>
	</section>
</div>

<?php
get_footer();
