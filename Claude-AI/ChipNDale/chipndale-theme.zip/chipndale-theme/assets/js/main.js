/**
 * ChipNDaleTheme — скрипт темы.
 * Сейчас: переключатель меню-самолёта на телефонах.
 * Дальше: сюда добавим звуки и мини-игру (см. Шаг 5).
 */
(function () {
	'use strict';

	// --- Мобильное меню --------------------------------------------------
	var toggle = document.querySelector('.nav-toggle');
	var nav = document.getElementById('site-navigation');

	if (toggle && nav) {
		// Открыть/закрыть меню по клику и обновить aria-expanded для скринридеров
		toggle.addEventListener('click', function () {
			var isOpen = nav.classList.toggle('is-open');
			toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
		});

		// Закрыть меню клавишей Esc и вернуть фокус на кнопку
		document.addEventListener('keydown', function (event) {
			if (event.key === 'Escape' && nav.classList.contains('is-open')) {
				nav.classList.remove('is-open');
				toggle.setAttribute('aria-expanded', 'false');
				toggle.focus();
			}
		});
	}

	// --- Задел под будущие улучшения ---------------------------------------
	// TODO: звуковые эффекты (клик по «окнам» меню, гул мотора)
	// TODO: мини-игра «Собери шестерёнки»
})();
