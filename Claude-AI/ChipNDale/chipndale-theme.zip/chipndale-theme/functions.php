<?php
/**
 * Функции и настройки темы ChipNDaleTheme.
 *
 * @package ChipNDaleTheme
 */

// Защита: файл нельзя открыть напрямую по адресу в браузере
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Версия темы берём из style.css — она же используется для сброса кэша стилей
define( 'CHIPNDALE_VERSION', wp_get_theme()->get( 'Version' ) );


/* ==========================================================================
   1. НАСТРОЙКА ТЕМЫ: поддержка функций WordPress и регистрация меню
   ========================================================================== */
function chipndale_setup() {

	// Файлы переводов лежат в папке languages
	load_theme_textdomain( 'chipndale-theme', get_template_directory() . '/languages' );

	// WordPress сам формирует тег <title>
	add_theme_support( 'title-tag' );

	// Миниатюры записей и адаптивные встраиваемые видео
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );

	// RSS-ссылки в <head>
	add_theme_support( 'automatic-feed-links' );

	// Современная HTML5-разметка форм, комментариев и галерей
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script',
	) );

	// Свой логотип из «Внешний вид → Настроить». Если не загружен — покажем шляпу сыщика.
	add_theme_support( 'custom-logo', array(
		'height'      => 64,
		'width'       => 96,
		'flex-height' => true,
		'flex-width'  => true,
	) );

	// Размер картинки для карточек-расследований (16:9)
	add_image_size( 'chipndale-card', 640, 360, true );

	// Два места для меню: в шапке (самолёт) и в подвале
	register_nav_menus( array(
		'primary' => __( 'Главное меню (самолёт в шапке)', 'chipndale-theme' ),
		'footer'  => __( 'Меню в подвале', 'chipndale-theme' ),
	) );
}
add_action( 'after_setup_theme', 'chipndale_setup' );

// Максимальная ширина контента (нужна для встраиваемых объектов)
function chipndale_content_width() {
	$GLOBALS['content_width'] = 720;
}
add_action( 'after_setup_theme', 'chipndale_content_width', 0 );


/* ==========================================================================
   2. ПОДКЛЮЧЕНИЕ СТИЛЕЙ, ШРИФТОВ И СКРИПТОВ
   ========================================================================== */
function chipndale_scripts() {

	// Шрифты Google: «Press Start 2P» (заголовки, с кириллицей) и «Nunito» (основной текст)
	wp_enqueue_style(
		'chipndale-fonts',
		'https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,400;0,700;1,400&family=Press+Start+2P&display=swap',
		array(),
		null
	);

	// Главный файл стилей темы (style.css в корне)
	wp_enqueue_style( 'chipndale-style', get_stylesheet_uri(), array( 'chipndale-fonts' ), CHIPNDALE_VERSION );

	// Анимации: самолёт, винт, шестерёнки, облака
	wp_enqueue_style(
		'chipndale-animations',
		get_template_directory_uri() . '/assets/css/animations.css',
		array( 'chipndale-style' ),
		CHIPNDALE_VERSION
	);

	// Скрипт темы (мобильное меню; задел под звуки и мини-игру). Грузится в подвале.
	wp_enqueue_script(
		'chipndale-main',
		get_template_directory_uri() . '/assets/js/main.js',
		array(),
		CHIPNDALE_VERSION,
		true
	);

	// Скрипт ответов на комментарии (только там, где он нужен)
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'chipndale_scripts' );

// Ускоряем загрузку шрифтов: заранее открываем соединение с серверами Google
function chipndale_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		$urls[] = 'https://fonts.googleapis.com';
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'anonymous',
		);
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'chipndale_resource_hints', 10, 2 );


/* ==========================================================================
   3. МЕНЮ: запасной вариант, если меню ещё не создано в админке
   ========================================================================== */
function chipndale_fallback_menu() {
	echo '<ul id="primary-menu" class="menu">';
	echo '<li class="menu-item"><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Главная', 'chipndale-theme' ) . '</a></li>';
	wp_list_pages( array(
		'title_li' => '',
		'depth'    => 1,
	) );
	echo '</ul>';
}


/* ==========================================================================
   4. ПИКСЕЛЬНЫЕ СПРАЙТЫ (самолёт, шестерёнка, лупа, жёлудь, шляпа, облако)
   ========================================================================== */

/**
 * Возвращает <img> с пиксельным спрайтом из assets/images.
 * Пропорции спрайтов заданы здесь, чтобы страница не «прыгала» при загрузке.
 *
 * @param string $name  Имя файла без .svg: plane, gear, magnifier, acorn, hat, cloud.
 * @param int    $width Ширина на странице в пикселях.
 * @param string $class Дополнительные CSS-классы.
 */
function chipndale_sprite( $name, $width, $class = '' ) {
	$ratios = array(
		'plane'     => array( 50, 26 ),
		'gear'      => array( 26, 26 ),
		'magnifier' => array( 22, 22 ),
		'acorn'     => array( 18, 21 ),
		'hat'       => array( 34, 21 ),
		'cloud'     => array( 36, 14 ),
	);

	if ( ! isset( $ratios[ $name ] ) ) {
		return '';
	}

	$height = round( $width * $ratios[ $name ][1] / $ratios[ $name ][0] );
	$url    = get_template_directory_uri() . '/assets/images/' . $name . '.svg';

	return sprintf(
		'<img class="pixel-img %1$s" src="%2$s" width="%3$d" height="%4$d" alt="" aria-hidden="true">',
		esc_attr( $class ),
		esc_url( $url ),
		(int) $width,
		(int) $height
	);
}

/**
 * Иконка расследования по номеру карточки: лупа → шестерёнка → жёлудь → самолёт → …
 */
function chipndale_case_icon( $index ) {
	$icons = array(
		'magnifier' => 44,
		'gear'      => 44,
		'acorn'     => 38,
		'plane'     => 64,
	);

	$names = array_keys( $icons );
	$name  = $names[ (int) $index % count( $names ) ];

	return chipndale_sprite( $name, $icons[ $name ], 'case__icon' );
}


/* ==========================================================================
   5. ПОМОЩНИКИ ДЛЯ ШАБЛОНОВ
   ========================================================================== */

// Номер дела — это настоящий ID записи, дополненный нулями: «0042»
function chipndale_case_number() {
	return sprintf( '%04d', get_the_ID() );
}

// «Отдел» расследования — это первая рубрика записи
function chipndale_department_name() {
	$categories = get_the_category();

	if ( ! empty( $categories ) && 'uncategorized' !== $categories[0]->slug ) {
		return $categories[0]->name;
	}

	return __( 'Общий отдел', 'chipndale-theme' );
}

/**
 * Статус дела для красной печати. Печать показываем только тогда, когда она что-то сообщает:
 * «Срочно» — закреплённая запись, «Свежее дело» — младше 7 дней, «В архиве» — старше года.
 * Для остальных записей возвращаем пустую строку, и печати нет.
 */
function chipndale_case_status() {
	if ( is_sticky() ) {
		return __( 'Срочно', 'chipndale-theme' );
	}

	$age = time() - (int) get_post_time( 'U', true );

	if ( $age < 7 * DAY_IN_SECONDS ) {
		return __( 'Свежее дело', 'chipndale-theme' );
	}

	if ( $age > 365 * DAY_IN_SECONDS ) {
		return __( 'В архиве', 'chipndale-theme' );
	}

	return '';
}

// Время чтения: считаем слова (в том числе кириллические) при скорости 180 слов в минуту
function chipndale_reading_time() {
	$text  = wp_strip_all_tags( get_the_content() );
	$words = preg_match_all( '/\p{L}+/u', $text );

	return max( 1, (int) ceil( $words / 180 ) );
}

// Мета-строка под заголовком: дата открытия дела и время чтения
function chipndale_entry_meta() {
	printf(
		'<p class="entry-meta"><span class="entry-meta__item">%1$s <time datetime="%2$s">%3$s</time></span><span class="entry-meta__item">%4$s</span></p>',
		esc_html__( 'Открыто:', 'chipndale-theme' ),
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		/* translators: %d — минуты чтения */
		esc_html( sprintf( __( 'Чтение: %d мин', 'chipndale-theme' ), chipndale_reading_time() ) )
	);
}

// Короткий анонс для карточек: 28 слов и многоточие
function chipndale_excerpt_length() {
	return 28;
}
add_filter( 'excerpt_length', 'chipndale_excerpt_length' );

function chipndale_excerpt_more() {
	return '…';
}
add_filter( 'excerpt_more', 'chipndale_excerpt_more' );
