<?php
/**
 * Подвал сайта: паттерн из шестерёнок, панель с меню, копирайтом и подписью автора.
 *
 * @package ChipNDaleTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</main><!-- #content -->

<?php // Фон подвала — бесшовный паттерн из шестерёнок (pattern-gears.svg задан в style.css) ?>
<footer class="site-footer">
	<div class="site-footer__panel">

		<?php // Две вращающиеся шестерёнки в углах панели (движение — в animations.css) ?>
		<?php echo chipndale_sprite( 'gear', 56, 'site-footer__gear site-footer__gear--a' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<?php echo chipndale_sprite( 'gear', 56, 'site-footer__gear site-footer__gear--b' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

		<?php echo chipndale_sprite( 'hat', 72, 'site-footer__logo' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

		<?php // Меню подвала: показываем, только если оно назначено в «Внешний вид → Меню» ?>
		<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<nav class="footer-nav" aria-label="<?php esc_attr_e( 'Меню в подвале', 'chipndale-theme' ); ?>">
				<?php
				wp_nav_menu( array(
					'theme_location' => 'footer',
					'container'      => false,
					'depth'          => 1,
				) );
				?>
			</nav>
		<?php endif; ?>

		<p class="site-footer__copy">
			<?php
			printf(
				/* translators: 1: год, 2: название сайта */
				esc_html__( '© %1$s %2$s. Расследуем, чиним и летаем.', 'chipndale-theme' ),
				esc_html( wp_date( 'Y' ) ),
				esc_html( get_bloginfo( 'name' ) )
			);
			?>
		</p>

		<?php // Подпись автора темы (обязательная) ?>
		<p class="site-footer__copy site-footer__credit">The website was made by Andrei Orlov: <a href="https://orlovandrei.space" target="_blank" rel="noopener">orlovandrei.space</a></p>

		<a class="button" href="#top"><?php esc_html_e( 'Взлететь наверх', 'chipndale-theme' ); ?></a>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
