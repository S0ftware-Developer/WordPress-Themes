<?php
/**
 * Шаблон одиночной записи — страница одного «дела».
 *
 * @package ChipNDaleTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="container">
	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>

			<?php // Вкладка папки с номером дела ?>
			<p class="case__tab">
				<?php
				/* translators: %s — номер дела */
				printf( esc_html__( 'Дело № %s', 'chipndale-theme' ), esc_html( chipndale_case_number() ) );
				?>
			</p>

			<header class="entry__header">
				<h1 class="entry__title"><?php the_title(); ?></h1>

				<?php // Дата открытия и время чтения ?>
				<?php chipndale_entry_meta(); ?>
			</header>

			<?php // Большая картинка дела (если есть) ?>
			<?php if ( has_post_thumbnail() ) : ?>
				<div class="entry__thumb"><?php the_post_thumbnail( 'large' ); ?></div>
			<?php endif; ?>

			<div class="entry__content">
				<?php
				the_content();

				// Постраничные записи (<!--nextpage-->)
				wp_link_pages( array(
					'before' => '<p class="page-links">' . esc_html__( 'Страницы:', 'chipndale-theme' ),
					'after'  => '</p>',
				) );
				?>
			</div>

			<footer class="entry__footer">
				<?php // Рубрика — «отдел», метки — «улики» ?>
				<p class="entry__tags">
					<?php
					/* translators: %s — название рубрики */
					printf( esc_html__( 'Отдел: %s', 'chipndale-theme' ), esc_html( chipndale_department_name() ) );
					?>
				</p>
				<?php the_tags( '<p class="entry__tags">' . esc_html__( 'Улики: ', 'chipndale-theme' ), ', ', '</p>' ); ?>
			</footer>
		</article>

		<?php // Переход между делами ?>
		<?php
		the_post_navigation( array(
			'prev_text'          => esc_html__( 'Предыдущее дело: %title', 'chipndale-theme' ),
			'next_text'          => esc_html__( 'Следующее дело: %title', 'chipndale-theme' ),
			'screen_reader_text' => esc_html__( 'Навигация по делам', 'chipndale-theme' ),
		) );
		?>

		<?php // Комментарии (если открыты или уже есть) ?>
		<?php
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
		?>

	<?php endwhile; ?>
</div>

<?php
get_footer();
