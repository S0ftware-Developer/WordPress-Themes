<?php
/**
 * Шапка сайта: небо с самолётом, логотип со шляпой сыщика и меню в виде самолёта.
 *
 * @package ChipNDaleTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php // Помечаем страницу классом «js», чтобы кнопка мобильного меню работала только при включённом JavaScript ?>
	<script>document.documentElement.className += ' js';</script>
	<?php wp_head(); ?>
</head>

<body id="top" <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Перейти к содержимому', 'chipndale-theme' ); ?></a>

<?php // Небо: облака и пролетающий самолёт (чисто декоративный слой) ?>
<div class="sky" aria-hidden="true">
	<?php echo chipndale_sprite( 'cloud', 144, 'sky__cloud sky__cloud--1' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	<?php echo chipndale_sprite( 'cloud', 208, 'sky__cloud sky__cloud--2' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	<?php echo chipndale_sprite( 'cloud', 120, 'sky__cloud sky__cloud--3' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	<div class="sky__plane"><?php echo chipndale_sprite( 'plane', 120 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
</div>

<header class="site-header">
	<div class="site-header__inner">

		<?php // Логотип: свой из настроек или шляпа сыщика по умолчанию ?>
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php
			if ( has_custom_logo() ) {
				echo wp_kses_post( get_custom_logo() );
			} else {
				echo chipndale_sprite( 'hat', 88, 'brand__logo' ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			?>
			<div class="brand__text">
				<?php // На главной название сайта — заголовок первого уровня, на остальных страницах — обычный абзац ?>
				<?php if ( is_front_page() && is_home() ) : ?>
					<h1 class="brand__title"><?php bloginfo( 'name' ); ?></h1>
				<?php else : ?>
					<p class="brand__title"><?php bloginfo( 'name' ); ?></p>
				<?php endif; ?>

				<?php $description = get_bloginfo( 'description', 'display' ); ?>
				<?php if ( $description ) : ?>
					<p class="brand__tagline"><?php echo esc_html( $description ); ?></p>
				<?php endif; ?>
			</div>
		</a>

		<?php // Кнопка меню для телефонов; логика — в assets/js/main.js ?>
		<button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-navigation">
			<?php esc_html_e( 'Меню', 'chipndale-theme' ); ?>
		</button>
	</div>
</header>

<?php // Меню-самолёт: хвост, фюзеляж с «окнами»-пунктами, нос с винтом и крыло (см. style.css, раздел 5) ?>
<nav id="site-navigation" class="plane-nav" aria-label="<?php esc_attr_e( 'Главное меню', 'chipndale-theme' ); ?>">
	<div class="plane">
		<div class="plane__body">
			<span class="plane__wing" aria-hidden="true"></span>
			<span class="plane__tail" aria-hidden="true"></span>
			<div class="plane__fuselage">
				<?php
				wp_nav_menu( array(
					'theme_location' => 'primary',
					'menu_id'        => 'primary-menu',
					'container'      => false,
					'depth'          => 1,
					'fallback_cb'    => 'chipndale_fallback_menu',
				) );
				?>
			</div>
			<span class="plane__nose" aria-hidden="true"></span>
			<span class="plane__prop" aria-hidden="true"></span>
		</div>
	</div>
</nav>

<main id="content" class="site-main">
