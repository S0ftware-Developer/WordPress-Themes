<?php
/**
 * Culinary Grid — theme setup
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'CG_VERSION', '1.0.0' );

/* ---------------------------------------------------------
 * 1. Theme support & setup
 * --------------------------------------------------------- */
function cg_setup() {
	load_theme_textdomain( 'culinary-grid', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array(
		'height'      => 120,
		'width'       => 120,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'responsive-embeds' );

	// Image size used for the 5-column recipe grid (square crop looks best in a grid).
	add_image_size( 'cg-recipe-card', 400, 400, true );
	add_image_size( 'cg-recipe-featured', 900, 600, true );

	// Cuisine-and-cooking focused navigation menu.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu (Cuisines & Cooking)', 'culinary-grid' ),
		'footer'  => __( 'Footer Menu', 'culinary-grid' ),
	) );

	// Excerpts default to the recipe-post format.
	add_post_type_support( 'post', 'excerpt' );
}
add_action( 'after_setup_theme', 'cg_setup' );

/* ---------------------------------------------------------
 * 2. Enqueue styles & scripts
 * --------------------------------------------------------- */
function cg_scripts() {
	wp_enqueue_style(
		'cg-google-fonts',
		'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Jost:wght@400;500;600&family=Caveat:wght@600&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'culinary-grid-style', get_stylesheet_uri(), array(), CG_VERSION );
	wp_enqueue_script( 'culinary-grid-nav', get_template_directory_uri() . '/js/navigation.js', array(), CG_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'cg_scripts' );

/* ---------------------------------------------------------
 * 3. Sidebar: right-hand column for banners + HTML widgets
 * --------------------------------------------------------- */
function cg_widgets_init() {

	register_sidebar( array(
		'name'          => __( 'Right Sidebar', 'culinary-grid' ),
		'id'            => 'sidebar-right',
		'description'   => __( 'Shown on the right of the recipe grid, single posts and pages. Drop in Image widgets for banners and Custom HTML widgets for ad code / affiliate blocks.', 'culinary-grid' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Sidebar — Banner Slot (top)', 'culinary-grid' ),
		'id'            => 'sidebar-banner-top',
		'description'   => __( 'Optional dedicated slot above the right sidebar widgets — ideal for a single banner ad or Custom HTML block, displayed without a title or card chrome.', 'culinary-grid' ),
		'before_widget' => '<div id="%1$s" class="widget cg-banner-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	for ( $i = 1; $i <= 3; $i++ ) {
		register_sidebar( array(
			'name'          => sprintf( __( 'Footer Column %d', 'culinary-grid' ), $i ),
			'id'            => 'footer-' . $i,
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );
	}
}
add_action( 'widgets_init', 'cg_widgets_init' );

/* ---------------------------------------------------------
 * 4. Fallback menu (so the header looks right before the
 *    user configures Appearance > Menus)
 * --------------------------------------------------------- */
function cg_fallback_menu() {
	echo '<ul id="primary-menu" class="primary-menu">';
	$items = array(
		'Home'         => home_url( '/' ),
		'All Recipes'  => home_url( '/?post_type=post' ),
		'Italian'      => home_url( '/?s=italian' ),
		'Asian'        => home_url( '/?s=asian' ),
		'Mexican'      => home_url( '/?s=mexican' ),
		'Mediterranean'=> home_url( '/?s=mediterranean' ),
		'Baking'       => home_url( '/?s=baking' ),
		'Cooking Tips' => home_url( '/?s=tips' ),
		'About'        => home_url( '/about' ),
	);
	foreach ( $items as $label => $url ) {
		printf( '<li><a href="%s">%s</a></li>', esc_url( $url ), esc_html( $label ) );
	}
	echo '</ul>';
}

/* ---------------------------------------------------------
 * 5. Excerpt tuning for mini recipe cards
 * --------------------------------------------------------- */
function cg_excerpt_length( $length ) {
	return 12;
}
add_filter( 'excerpt_length', 'cg_excerpt_length' );

function cg_excerpt_more( $more ) {
	return '…';
}
add_filter( 'excerpt_more', 'cg_excerpt_more' );

/* ---------------------------------------------------------
 * 6. Reading time helper (nice touch for recipe meta)
 * --------------------------------------------------------- */
function cg_reading_time() {
	$content = get_post_field( 'post_content', get_the_ID() );
	$word_count = str_word_count( wp_strip_all_tags( $content ) );
	$minutes = max( 1, ceil( $word_count / 200 ) );
	return $minutes;
}

/* ---------------------------------------------------------
 * 7. Body classes
 * --------------------------------------------------------- */
function cg_body_classes( $classes ) {
	if ( ! is_active_sidebar( 'sidebar-right' ) && ! is_active_sidebar( 'sidebar-banner-top' ) ) {
		$classes[] = 'no-sidebar';
	}
	return $classes;
}
add_filter( 'body_class', 'cg_body_classes' );

/* ---------------------------------------------------------
 * 8. Widgets: allow raw HTML/script in Custom HTML & Text
 *    widgets for banner/ad code (default WP behaviour, kept
 *    explicit here for clarity to theme users).
 * --------------------------------------------------------- */
add_filter( 'widget_text', 'do_shortcode' );

/* ---------------------------------------------------------
 * 9. Register a default set of cuisine categories on theme
 *    activation so the menu / grid has something to show.
 * --------------------------------------------------------- */
function cg_after_switch_theme() {
	$cuisines = array( 'Italian', 'Mexican', 'Asian', 'Mediterranean', 'Baking & Desserts', 'Cooking Tips' );
	foreach ( $cuisines as $cuisine ) {
		if ( ! term_exists( $cuisine, 'category' ) ) {
			wp_insert_term( $cuisine, 'category' );
		}
	}
}
add_action( 'after_switch_theme', 'cg_after_switch_theme' );

/* ---------------------------------------------------------
 * 10. Force 50 posts per page (5 columns x 10 rows) on the
 *     main grid views: home, blog index, category/tag
 *     archives and search results.
 * --------------------------------------------------------- */
function cg_grid_posts_per_page( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( $query->is_home() || $query->is_archive() || $query->is_search() ) {
		$query->set( 'posts_per_page', 50 );
	}
}
add_action( 'pre_get_posts', 'cg_grid_posts_per_page' );

/* ---------------------------------------------------------
 * 11. Include template helper files
 * --------------------------------------------------------- */
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/customizer.php';
