/**
 * Mobile menu toggle for the primary (cuisine) navigation.
 */
( function () {
	document.addEventListener( 'DOMContentLoaded', function () {
		var toggle = document.querySelector( '.menu-toggle' );
		var menu = document.getElementById( 'primary-menu' );

		if ( ! toggle || ! menu ) return;

		toggle.addEventListener( 'click', function () {
			var isOpen = menu.classList.toggle( 'is-open' );
			toggle.setAttribute( 'aria-expanded', isOpen ? 'true' : 'false' );
		} );
	} );
} )();
