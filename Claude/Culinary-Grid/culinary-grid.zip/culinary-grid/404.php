<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
?>
<div class="cg-layout">
	<main id="main" class="cg-main" style="text-align:center;padding:60px 0;">
		<h1 style="font-size:80px;margin-bottom:0;">🥘</h1>
		<h2><?php esc_html_e( 'This dish isn\'t on the menu.', 'culinary-grid' ); ?></h2>
		<p><?php esc_html_e( 'The page you were looking for has gone cold. Try a search instead.', 'culinary-grid' ); ?></p>
		<form role="search" method="get" class="header-search-form" style="max-width:340px;margin:20px auto;" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<input type="search" name="s" placeholder="<?php esc_attr_e( 'Search recipes…', 'culinary-grid' ); ?>">
			<button type="submit">🔍</button>
		</form>
	</main>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
