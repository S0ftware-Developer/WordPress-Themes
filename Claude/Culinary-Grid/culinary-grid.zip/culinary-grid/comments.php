<?php
if ( ! defined( 'ABSPATH' ) ) exit;

if ( post_password_required() ) {
	return;
}
?>
<div id="comments" class="comments-area" style="margin-top:40px;">
	<?php if ( have_comments() ) : ?>
		<h2 class="comments-title">
			<?php
			printf(
				esc_html( _n( '%1$s comment on %2$s', '%1$s comments on %2$s', get_comments_number(), 'culinary-grid' ) ),
				number_format_i18n( get_comments_number() ),
				'<span>' . esc_html( get_the_title() ) . '</span>'
			);
			?>
		</h2>
		<ul class="comment-list">
			<?php wp_list_comments( array( 'style' => 'ul', 'short_ping' => true ) ); ?>
		</ul>
		<?php the_comments_pagination(); ?>
	<?php endif; ?>

	<?php comment_form(); ?>
</div>
