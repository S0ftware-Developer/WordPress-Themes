<?php
/**
 * Static page template
 */
if ( ! defined( 'ABSPATH' ) ) exit;

get_header();
?>
<div class="cg-layout">
	<main id="main" class="cg-main">
		<?php while ( have_posts() ) : the_post(); ?>
			<article <?php post_class(); ?>>
				<header class="recipe-single-header" style="text-align:left;padding-left:0;">
					<h1><?php the_title(); ?></h1>
				</header>
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="recipe-featured-img"><?php the_post_thumbnail( 'cg-recipe-featured' ); ?></div>
				<?php endif; ?>
				<div class="entry-content">
					<?php the_content(); ?>
				</div>
			</article>
			<?php if ( comments_open() || get_comments_number() ) comments_template(); ?>
		<?php endwhile; ?>
	</main>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
