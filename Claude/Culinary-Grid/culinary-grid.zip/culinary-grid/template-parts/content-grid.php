<?php
/**
 * The 5-column recipe grid, paired with the right sidebar.
 * posts_per_page is forced to 50 (5 cols x 10 rows) via
 * pre_get_posts in inc/template-tags.php-style hook below,
 * so this template stays simple and reusable.
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="cg-page-hero">
	<h1>
		<?php
		if ( is_home() || is_front_page() ) {
			echo esc_html( get_theme_mod( 'cg_hero_heading', __( 'Recipes Worth Repeating', 'culinary-grid' ) ) );
		} elseif ( is_search() ) {
			printf( esc_html__( 'Search results for: %s', 'culinary-grid' ), '<em>' . esc_html( get_search_query() ) . '</em>' );
		} elseif ( is_category() || is_tag() ) {
			single_term_title();
		} else {
			esc_html_e( 'The Recipe Box', 'culinary-grid' );
		}
		?>
	</h1>
	<?php if ( is_home() || is_front_page() ) : ?>
		<p><?php echo esc_html( get_theme_mod( 'cg_hero_subtext', __( 'Fifty ways to fall for dinner — new dishes added weekly.', 'culinary-grid' ) ) ); ?></p>
	<?php endif; ?>
	<div class="cg-divider">🍅 · 🧄 · 🌿</div>
</div>

<div class="cg-layout">
	<main id="main-grid" class="cg-main">

		<?php if ( have_posts() ) : ?>
			<div class="recipe-grid">
				<?php while ( have_posts() ) : the_post();
					cg_recipe_card();
				endwhile; ?>
			</div>

			<?php cg_pagination(); ?>

		<?php else : ?>
			<p><?php esc_html_e( 'No recipes found. Try a different search or check back soon!', 'culinary-grid' ); ?></p>
		<?php endif; ?>

	</main>

	<?php get_sidebar(); ?>
</div>
