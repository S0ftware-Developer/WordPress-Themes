<?php
/**
 * Single recipe post template
 */
if ( ! defined( 'ABSPATH' ) ) exit;

get_header();
?>

<div class="cg-layout">
	<main id="main" class="cg-main">
		<?php while ( have_posts() ) : the_post(); ?>

			<article <?php post_class(); ?>>

				<header class="recipe-single-header">
					<?php
					$cats = get_the_category();
					if ( ! empty( $cats ) ) {
						echo '<p><a class="entry-tags" href="' . esc_url( get_category_link( $cats[0]->term_id ) ) . '">' . esc_html( $cats[0]->name ) . '</a></p>';
					}
					?>
					<h1><?php the_title(); ?></h1>
					<div class="recipe-single-meta">
						<span>👩‍🍳 <?php the_author(); ?></span>
						<span>📅 <?php echo esc_html( get_the_date() ); ?></span>
						<span>⏱️ <?php echo esc_html( cg_reading_time() ); ?> <?php esc_html_e( 'min read', 'culinary-grid' ); ?></span>
					</div>
				</header>

				<?php if ( has_post_thumbnail() ) : ?>
					<div class="recipe-featured-img">
						<?php the_post_thumbnail( 'cg-recipe-featured' ); ?>
					</div>
				<?php endif; ?>

				<div class="recipe-facts">
					<div><span>4</span><small><?php esc_html_e( 'Servings', 'culinary-grid' ); ?></small></div>
					<div><span>20m</span><small><?php esc_html_e( 'Prep', 'culinary-grid' ); ?></small></div>
					<div><span>35m</span><small><?php esc_html_e( 'Cook', 'culinary-grid' ); ?></small></div>
					<div><span><?php echo esc_html( cg_reading_time() ); ?>m</span><small><?php esc_html_e( 'Read', 'culinary-grid' ); ?></small></div>
				</div>

				<div class="entry-content">
					<?php
					the_content();
					wp_link_pages( array(
						'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'culinary-grid' ),
						'after'  => '</div>',
					) );
					?>
				</div>

				<?php
				$tags = get_the_tag_list( '', ' ' );
				if ( $tags ) : ?>
					<div class="entry-tags"><?php echo wp_kses_post( $tags ); ?></div>
				<?php endif; ?>

			</article>

			<?php
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
			?>

		<?php endwhile; ?>
	</main>

	<?php get_sidebar(); ?>
</div>

<?php get_footer(); ?>
