<?php
/**
 * Right-hand sidebar — banners + custom HTML widgets
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! is_active_sidebar( 'sidebar-right' ) && ! is_active_sidebar( 'sidebar-banner-top' ) ) {
	return;
}
?>
<aside id="secondary" class="cg-sidebar" role="complementary">

	<?php if ( is_active_sidebar( 'sidebar-banner-top' ) ) : ?>
		<?php dynamic_sidebar( 'sidebar-banner-top' ); ?>
	<?php else : ?>
		<div class="cg-sidebar-cta">
			<h3><?php esc_html_e( 'Your Banner Here', 'culinary-grid' ); ?></h3>
			<p><?php esc_html_e( 'Add an Image or Custom HTML widget to "Sidebar — Banner Slot (top)" in Appearance → Widgets.', 'culinary-grid' ); ?></p>
		</div>
	<?php endif; ?>

	<?php if ( is_active_sidebar( 'sidebar-right' ) ) : ?>
		<?php dynamic_sidebar( 'sidebar-right' ); ?>
	<?php else : ?>
		<div class="widget">
			<h3 class="widget-title"><?php esc_html_e( 'Kitchen Notes', 'culinary-grid' ); ?></h3>
			<p><?php esc_html_e( 'Add widgets to "Right Sidebar" in Appearance → Widgets — Custom HTML works great here for ad codes or embeds.', 'culinary-grid' ); ?></p>
		</div>
	<?php endif; ?>

</aside>
