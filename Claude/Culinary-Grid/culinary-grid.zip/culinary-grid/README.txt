=== Culinary Grid ===
A custom WordPress theme for recipe blogs.

INSTALL
1. Zip the "culinary-grid" folder (already done for you as culinary-grid.zip)
   if you edit any files, or upload it as-is.
2. In wp-admin go to Appearance > Themes > Add New > Upload Theme.
3. Upload culinary-grid.zip, then Activate.

SET UP THE HOMEPAGE GRID
- The theme already shows your 50 most recent posts (5 columns x 10 rows,
  newer posts fill row 1 first) on the homepage, blog index, category/tag
  archives and search results. Nothing to configure — just publish posts.
- Each post needs a Featured Image for the grid photo. Recommended image
  size: at least 400x400px (square crops automatically).
- Pagination appears automatically once you have more than 50 posts.

MENU (Appearance > Menus)
- Create a menu, add your cuisine/category links (Italian, Asian, Baking,
  Cooking Tips, About, etc.), and assign it to "Primary Menu (Cuisines &
  Cooking)". Supports drop-down sub-menus automatically.
- A sample cuisine menu shows automatically until you create one.

RIGHT SIDEBAR (Appearance > Widgets)
- "Sidebar — Banner Slot (top)": add one Image widget or Custom HTML
  widget here for a top banner ad — it renders edge-to-edge with no
  title or card border, ideal for ad creative.
- "Right Sidebar": add as many widgets as you like below the banner —
  Custom HTML is great for ad network codes, affiliate blocks, or
  embeds; Text, Recent Posts, Categories, and Search widgets are also
  styled to match.
- Both sidebars show on the grid pages and on single recipe posts.

LOGO & SITE IDENTITY (Appearance > Customize > Site Identity)
- Upload a logo (displays as a circular mark next to your site title)
  and set your tagline (shown in a script font under the title).

GRID INTRO TEXT (Appearance > Customize > Grid Page Intro)
- Edit the heading/subheading shown above the recipe grid on the
  homepage.

CATEGORIES
- On activation the theme creates starter categories: Italian, Mexican,
  Asian, Mediterranean, Baking & Desserts, Cooking Tips. Rename, delete,
  or add more under Posts > Categories, then link to them from your
  primary menu.

NOTES
- Built with plain PHP + CSS, no build step or dependencies — safe to
  hand-edit style.css or the template files directly.
- Fonts (Playfair Display / Jost / Caveat) load from Google Fonts.
