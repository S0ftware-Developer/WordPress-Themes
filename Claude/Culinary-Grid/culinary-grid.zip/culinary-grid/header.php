<?php
/**
 * The header — topbar, logo/site title, search, cuisine navigation
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">

<div class="cg-topbar">
	<div class="container">
		<span>🍽️ <?php bloginfo( 'name' ); ?> — <?php esc_html_e( 'Fresh recipes every week', 'culinary-grid' ); ?></span>
		<span class="cg-social">
			<?php
			$socials = array(
				'instagram' => 'Instagram',
				'pinterest' => 'Pinterest',
				'facebook'  => 'Facebook',
				'youtube'   => 'YouTube',
			);
			foreach ( $socials as $key => $label ) {
				$url = get_theme_mod( 'cg_social_' . $key );
				if ( $url ) {
					printf( '<a href="%s" target="_blank" rel="noopener">%s</a>', esc_url( $url ), esc_html( $label ) );
				}
			}
			?>
		</span>
	</div>
</div>

<header id="masthead" class="site-header">
	<div class="site-branding-row">
		<div class="site-branding">
			<?php
			if ( has_custom_logo() ) {
				the_custom_logo();
			}
			?>
			<div>
				<p class="site-title">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
				</p>
				<?php $desc = get_bloginfo( 'description' ); if ( $desc ) : ?>
					<p class="site-description"><?php echo esc_html( $desc ); ?></p>
				<?php endif; ?>
			</div>
		</div>

		<form role="search" method="get" class="header-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<input type="search" name="s" placeholder="<?php esc_attr_e( 'Search recipes…', 'culinary-grid' ); ?>" value="<?php echo get_search_query(); ?>">
			<button type="submit" aria-label="<?php esc_attr_e( 'Search', 'culinary-grid' ); ?>">🔍</button>
		</form>
	</div>

	<nav id="site-navigation" class="site-nav">
		<div class="container">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'menu_id'        => 'primary-menu',
				'container'      => false,
				'menu_class'     => 'primary-menu',
				'fallback_cb'    => 'cg_fallback_menu',
			) );
			?>
			<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">&#9776;</button>
		</div>
	</nav>
</header>
