<?php
/**
 * The footer
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
	<footer id="colophon" class="site-footer">
		<?php if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) ) : ?>
			<div class="footer-widgets">
				<?php for ( $i = 1; $i <= 3; $i++ ) : if ( is_active_sidebar( 'footer-' . $i ) ) : ?>
					<div class="footer-col">
						<?php dynamic_sidebar( 'footer-' . $i ); ?>
					</div>
				<?php endif; endfor; ?>
			</div>
		<?php endif; ?>

		<div class="site-info container">
			<p>
				&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
				— <?php esc_html_e( 'Made with butter, garlic, and Culinary Grid.', 'culinary-grid' ); ?>
			</p>
		</div>
	</footer>
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
