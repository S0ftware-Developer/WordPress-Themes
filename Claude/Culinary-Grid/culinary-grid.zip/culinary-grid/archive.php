<?php
/**
 * Main template file — falls back to the recipe grid for any
 * request not caught by a more specific template.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

get_header();
get_template_part( 'template-parts/content', 'grid' );
get_footer();
