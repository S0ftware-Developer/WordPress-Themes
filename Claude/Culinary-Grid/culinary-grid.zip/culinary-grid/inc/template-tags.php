<?php
/**
 * Reusable template helpers
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Custom pagination markup styled to match the theme.
 */
function cg_pagination() {
	global $wp_query;

	$big = 999999999;
	$links = paginate_links( array(
		'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
		'format'    => '?paged=%#%',
		'current'   => max( 1, get_query_var( 'paged' ) ),
		'total'     => $wp_query->max_num_pages,
		'mid_size'  => 2,
		'prev_text' => '&larr;',
		'next_text' => '&rarr;',
		'type'      => 'array',
	) );

	if ( empty( $links ) ) return;

	echo '<nav class="cg-pagination" aria-label="' . esc_attr__( 'Recipe pagination', 'culinary-grid' ) . '">';
	foreach ( $links as $link ) {
		echo wp_kses_post( $link );
	}
	echo '</nav>';
}

/**
 * Output one mini recipe card. Used by the 5x10 grid on
 * index.php / home.php / archive.php / search.php.
 */
function cg_recipe_card() {
	?>
	<article <?php post_class( 'recipe-card' ); ?>>
		<a class="recipe-card__thumb" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
			<?php
			$cats = get_the_category();
			if ( ! empty( $cats ) ) {
				echo '<span class="recipe-card__cat">' . esc_html( $cats[0]->name ) . '</span>';
			}
			if ( has_post_thumbnail() ) {
				the_post_thumbnail( 'cg-recipe-card' );
			} else {
				echo '<img src="' . esc_url( get_template_directory_uri() . '/images/placeholder.svg' ) . '" alt="' . esc_attr( get_the_title() ) . '">';
			}
			?>
		</a>
		<div class="recipe-card__body">
			<h2 class="recipe-card__title">
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</h2>
			<div class="recipe-card__meta">
				<span><?php echo esc_html( cg_reading_time() ); ?> min</span>
				<span class="dot">&bull;</span>
				<span><?php echo esc_html( get_the_date() ); ?></span>
			</div>
		</div>
	</article>
	<?php
}
