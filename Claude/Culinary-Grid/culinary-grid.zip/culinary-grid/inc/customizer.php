<?php
/**
 * Theme Customizer settings
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function cg_customize_register( $wp_customize ) {

	$wp_customize->add_section( 'cg_hero_section', array(
		'title'    => __( 'Grid Page Intro', 'culinary-grid' ),
		'priority' => 25,
	) );

	$wp_customize->add_setting( 'cg_hero_heading', array(
		'default'           => __( 'Recipes Worth Repeating', 'culinary-grid' ),
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'cg_hero_heading', array(
		'label'   => __( 'Heading above the recipe grid', 'culinary-grid' ),
		'section' => 'cg_hero_section',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'cg_hero_subtext', array(
		'default'           => __( 'Fifty ways to fall for dinner — new dishes added weekly.', 'culinary-grid' ),
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'cg_hero_subtext', array(
		'label'   => __( 'Subheading text', 'culinary-grid' ),
		'section' => 'cg_hero_section',
		'type'    => 'text',
	) );

	$wp_customize->add_section( 'cg_topbar_section', array(
		'title'    => __( 'Top Bar Social Links', 'culinary-grid' ),
		'priority' => 30,
	) );

	$socials = array( 'instagram', 'pinterest', 'facebook', 'youtube' );
	foreach ( $socials as $social ) {
		$wp_customize->add_setting( 'cg_social_' . $social, array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		) );
		$wp_customize->add_control( 'cg_social_' . $social, array(
			'label'   => ucfirst( $social ) . ' ' . __( 'URL', 'culinary-grid' ),
			'section' => 'cg_topbar_section',
			'type'    => 'url',
		) );
	}
}
add_action( 'customize_register', 'cg_customize_register' );
