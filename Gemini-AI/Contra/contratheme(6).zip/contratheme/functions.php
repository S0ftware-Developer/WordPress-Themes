<?php
/**
 * Функции и настройки темы ContraTheme v2.0
 */

if ( ! function_exists( 'contratheme_setup' ) ) :
    function contratheme_setup() {
        add_theme_support( 'title-tag' );
        add_theme_support( 'post-thumbnails' );

        add_theme_support( 'custom-background', array(
            'default-color'      => '070a06',
            'default-image'      => get_template_directory_uri() . '/screenshot.png',
            'default-repeat'     => 'no-repeat',
            'default-position-x' => 'center',
            'default-position-y' => 'top',
            'default-size'       => 'cover',
            'default-attachment' => 'fixed',
        ) );

        register_nav_menus( array(
            'primary' => __( 'HUD Главное Меню', 'contratheme' ),
        ) );
    }
endif;
add_action( 'after_setup_theme', 'contratheme_setup' );

function contratheme_scripts() {
    wp_enqueue_style( 'contratheme-style', get_stylesheet_uri(), array(), '2.0' );

    $bg_url = get_template_directory_uri() . '/screenshot.png';
    $custom_css = "
        body {
            background-image: linear-gradient(to bottom, rgba(0, 0, 0, 0.3) 0%, rgba(0, 0, 0, 0.6) 100%), url('{$bg_url}') !important;
            background-repeat: no-repeat !important;
            background-position: center top !important;
            background-attachment: fixed !important;
            background-size: cover !important;
        }
    ";
    wp_add_inline_style( 'contratheme-style', $custom_css );
}
add_action( 'wp_enqueue_scripts', 'contratheme_scripts' );
