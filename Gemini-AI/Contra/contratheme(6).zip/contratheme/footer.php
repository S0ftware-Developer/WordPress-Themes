<?php
/**
 * Подвал темы ContraTheme
 */
?>
</main> <!-- Конец container -->

<footer style="background-color: rgba(0,0,0,0.92); border-top: 4px solid var(--border-pixel); margin-top: 50px; padding: 30px 0; text-align: center;">
    <div class="container">
        <div style="color: var(--border-pixel); font-size: 10px; margin-bottom: 15px;">
            ▲▲▲ JUNGLE BASE ZONE ▲▲▲
        </div>
        
        <p style="font-size: 10px; color: #aaa; margin: 0; line-height: 2;">
            &copy; <?php echo date('Y'); ?> CONTRA THEME. ALL RIGHTS RESERVED.
            <br>
            The website was made by Andrei Orlov: <a href="https://orlovandrei.space" target="_blank" rel="noopener noreferrer" style="color: var(--hud-yellow);">orlovandrei.space</a>
            <br>PRESS START TO PLAY.
        </p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
