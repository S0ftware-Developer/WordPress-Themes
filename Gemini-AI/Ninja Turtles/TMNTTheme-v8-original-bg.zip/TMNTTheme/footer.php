<footer class="tmnt-footer">
    <div class="tmnt-container">
        <p style="font-size: 10px; color: var(--tmnt-yellow-pizza);">COWABUNGA! &copy; <?php echo date('Y'); ?></p>
        <p class="footer-credits" style="font-size: 10px;"><a href="https://orlovandrei.space" target="_blank">orlovandrei.space</a></p>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
