<?php
/**
 * Шапка темы ContraTheme (HUD-интерфейс)
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<header style="background: rgba(0, 0, 0, 0.88); border-bottom: 4px solid var(--hud-red); padding: 15px 0;">
    <div class="container" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
        
        <!-- Игровой HUD: Игрок 1 и Счет -->
        <div class="hud-stats" style="color: var(--hud-red);">
            1P <span style="color: #fff;">REST 3</span> <span style="color: var(--hud-yellow);">HI 0030000</span>
        </div>

        <!-- Логотип Contra -->
        <div class="logo">
            <h1 style="margin: 0; font-size: 24px;">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color: var(--hud-red); text-shadow: 3px 3px var(--hud-yellow);">
                    CONTRA
                </a>
            </h1>
        </div>

        <!-- Меню навигации -->
        <nav class="hud-menu">
            <?php
            wp_nav_menu( array(
                'theme_location' => 'primary',
                'menu_class'     => 'hud-menu-list',
                'container'      => false,
                'fallback_cb'    => false,
            ) );
            ?>
        </nav>

    </div>
</header>

<main class="container">
