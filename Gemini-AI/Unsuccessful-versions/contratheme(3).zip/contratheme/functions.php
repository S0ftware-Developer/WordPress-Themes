<?php
/**
 * Функции и настройки темы ContraTheme
 */

if ( ! function_exists( 'contratheme_setup' ) ) :
    function contratheme_setup() {
        // Добавляем поддержку тега <title>
        add_theme_support( 'title-tag' );

        // Поддержка миниатюр (изображений) постов
        add_theme_support( 'post-thumbnails' );

        // Регистрация меню навигации в стиле HUD
        register_nav_menus( array(
            'primary' => __( 'HUD Главное Меню', 'contratheme' ),
        ) );
    }
endif;
add_action( 'after_setup_theme', 'contratheme_setup' );

/**
 * Подключение стилей и внедрение фона через inline CSS (гарантированное отображение)
 */
function contratheme_scripts() {
    // Подключаем главный style.css
    wp_enqueue_style( 'contratheme-style', get_stylesheet_uri(), array(), '1.2' );

    // Динамически получаем полный URL к картинке screenshot.png из папки темы
    $bg_image_url = get_template_directory_uri() . '/screenshot.png';

    // Внедряем правильный CSS с явным URL файла
    $custom_css = "
        body {
            background-color: #0d130c !important;
            background-image: linear-gradient(rgba(13, 19, 12, 0.35), rgba(13, 19, 12, 0.55)), url('{$bg_image_url}') !important;
            background-repeat: no-repeat !important;
            background-position: center top !important;
            background-attachment: fixed !important;
            background-size: cover !important;
        }
    ";
    wp_add_inline_style( 'contratheme-style', $custom_css );
}
add_action( 'wp_enqueue_scripts', 'contratheme_scripts' );
