<?php
/**
 * Подвал темы ContraTheme
 */
?>
</main> <!-- Конец container -->

<footer style="background-color: rgba(0,0,0,0.95); border-top: 4px solid var(--border-pixel); margin-top: 50px; padding: 30px 0; text-align: center;">
    <div class="container">
        <!-- Текстура джунглей/декорация -->
        <div style="color: var(--border-pixel); font-size: 10px; margin-bottom: 15px;">
            ▲▲▲ JUNGLE BASE ZONE ▲▲▲
        </div>
        
        <p style="font-size: 10px; color: #888; margin: 0;">
            &copy; <?php echo date('Y'); ?> CONTRA THEME. ALL RIGHTS RESERVED.
            <br><br>
            The website was made by Andrei Orlov: <a href="https://orlovandrei.space" target="_blank" rel="noopener noreferrer" style="color: var(--hud-yellow);">orlovandrei.space</a>
            <br><br>PRESS START TO PLAY.
        </p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
