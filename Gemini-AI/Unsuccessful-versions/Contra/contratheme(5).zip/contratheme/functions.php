<?php
/**
 * Функции и настройки темы ContraTheme v1.3
 */

if ( ! function_exists( 'contratheme_setup' ) ) :
    function contratheme_setup() {
        add_theme_support( 'title-tag' );
        add_theme_support( 'post-thumbnails' );
        register_nav_menus( array(
            'primary' => __( 'HUD Главное Меню', 'contratheme' ),
        ) );
    }
endif;
add_action( 'after_setup_theme', 'contratheme_setup' );

/**
 * Подключение стилей и прописывание фона сайта
 */
function contratheme_scripts() {
    wp_enqueue_style( 'contratheme-style', get_stylesheet_uri(), array(), '1.3' );

    // Берем screenshot.jpg из директории темы
    $bg_image_url = get_template_directory_uri() . '/screenshot.jpg';

    // Внедряем динамический фоновый арт с легким темным полупрозрачным слоем для читаемости
    $custom_css = "
        body {
            background-color: #070a06 !important;
            background-image: linear-gradient(to bottom, rgba(0,0,0,0.45) 0%, rgba(0,0,0,0.65) 100%), url('{$bg_image_url}') !important;
            background-repeat: no-repeat !important;
            background-position: center top !important;
            background-attachment: fixed !important;
            background-size: cover !important;
        }
    ";
    wp_add_inline_style( 'contratheme-style', $custom_css );
}
add_action( 'wp_enqueue_scripts', 'contratheme_scripts' );
