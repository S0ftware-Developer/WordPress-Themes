<?php
/**
 * Главный шаблон вывода постов (Список Миссий)
 */
get_header(); 
?>

<div style="text-align: center; margin-bottom: 30px; background: rgba(0,0,0,0.7); padding: 12px; border: 3px solid var(--hud-yellow);">
    <h2 style="color: var(--hud-yellow); font-size: 16px; margin: 0;">SELECT MISSION</h2>
</div>

<div class="missions-grid">
    <?php 
    $mission_number = 1;
    if ( have_posts() ) : 
        while ( have_posts() ) : the_post(); ?>
            
            <article id="post-<?php the_ID(); ?>" <?php post_class('mission-card'); ?>>
                <span class="weapon-icon">GUN: [M]</span>
                
                <div style="font-size: 10px; color: #aaa; margin-bottom: 8px;">
                    STAGE 0<?php echo $mission_number++; ?>
                </div>

                <h3 class="mission-title">
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </h3>

                <div class="mission-excerpt" style="font-size: 10px; margin-bottom: 15px; color: #ddd;">
                    <?php the_excerpt(); ?>
                </div>

                <a href="<?php the_permalink(); ?>" class="btn-contra">
                    START MISSION
                </a>
            </article>

        <?php endwhile;
    else : ?>
        <div style="background: rgba(0,0,0,0.8); padding: 25px; border: 3px solid var(--hud-red); grid-column: 1 / -1; text-align: center;">
            <p style="margin: 0; color: var(--hud-yellow);">МИССИИ НЕ НАЙДЕНЫ. ВРАГ ОТСТУПИЛ.</p>
        </div>
    <?php endif; ?>
</div>

<?php 
get_footer();
