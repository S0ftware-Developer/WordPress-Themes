<?php
/**
 * Функции и настройки темы ContraTheme
 */

if ( ! function_exists( 'contratheme_setup' ) ) :
    function contratheme_setup() {
        // Добавляем поддержку тега <title>
        add_theme_support( 'title-tag' );

        // Поддержка миниатюр (изображений) постов
        add_theme_support( 'post-thumbnails' );

        // Регистрация меню навигации в стиле HUD
        register_nav_menus( array(
            'primary' => __( 'HUD Главное Меню', 'contratheme' ),
        ) );
    }
endif;
add_action( 'after_setup_theme', 'contratheme_setup' );

/**
 * Подключение стилей и скриптов
 */
function contratheme_scripts() {
    // Подключаем главный style.css
    wp_enqueue_style( 'contratheme-style', get_stylesheet_uri(), array(), '1.0' );
}
add_action( 'wp_enqueue_scripts', 'contratheme_scripts' );
