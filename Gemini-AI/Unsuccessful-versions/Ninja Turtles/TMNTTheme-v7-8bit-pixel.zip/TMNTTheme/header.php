<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="tmnt-header">
    <div class="tmnt-container">
        <div class="tmnt-logo">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
        </div>
        <nav class="sewer-nav">
            <ul>
                <li><a href="#">Главная</a></li>
                <li><a href="#">Уровни</a></li>
                <li><a href="#">Пицца</a></li>
            </ul>
        </nav>
    </div>
</header>
