<?php get_header(); ?>
<main class="tmnt-container">
    <div class="posts-grid">
        <?php if ( have_posts() ) : ?>
            <?php while ( have_posts() ) : the_post(); ?>
                <article <?php post_class( 'turtle-card' ); ?>>
                    <h2 class="turtle-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <div class="turtle-excerpt"><?php the_excerpt(); ?></div>
                </article>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>
