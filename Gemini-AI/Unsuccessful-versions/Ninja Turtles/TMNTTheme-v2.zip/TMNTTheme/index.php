<?php
/**
 * Главный файл шаблона вывода постов
 * 
 * @package TMNTTheme
 */

get_header(); ?>

<main class="tmnt-container">
    <h1 style="text-align: center; color: var(--tmnt-yellow-pizza); font-size: 20px; margin-top: 30px;">
        Свежие Логова и Новости <span class="shuriken"></span>
    </h1>

    <div class="posts-grid">
        <?php if ( have_posts() ) : ?>
            <?php while ( have_posts() ) : the_post(); ?>
                
                <!-- Карточка-черепашка -->
                <article id="post-<?php the_ID(); ?>" <?php post_class( 'turtle-card' ); ?>>
                    <div class="turtle-card-content">
                        <h2 class="turtle-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>
                        <div class="turtle-excerpt">
                            <?php the_excerpt(); ?>
                        </div>
                    </div>
                </article>

            <?php endwhile; ?>
        <?php else : ?>
            <p style="text-align: center;">Шредер украл все посты! Пока ничего нет.</p>
        <?php endif; ?>
    </div>
</main>

<?php get_footer(); ?>
