<?php
/**
 * Футер темы TMNTTheme
 * 
 * @package TMNTTheme
 */
?>

<footer class="tmnt-footer">
    <div class="footer-box">
        <p style="margin: 0; font-size: 12px; color: var(--tmnt-yellow-pizza);">
            PIZZA TIME! &copy; <?php echo date( 'Y' ); ?> <?php bloginfo( 'name' ); ?>.
        </p>
        <p class="footer-credits" style="margin-top: 10px; font-size: 10px; color: #fff;">
            The website was made by Andrei Orlov: <a href="https://orlovandrei.space" target="_blank" rel="noopener">orlovandrei.space</a>
        </p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
