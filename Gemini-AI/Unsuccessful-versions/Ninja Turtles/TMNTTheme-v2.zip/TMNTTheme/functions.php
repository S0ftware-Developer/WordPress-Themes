<?php
/**
 * Функции и настройки темы TMNTTheme
 * 
 * @package TMNTTheme
 */

if ( ! function_exists( 'tmnttheme_setup' ) ) :
    /**
     * Основная настройка темы
     */
    function tmnttheme_setup() {
        // Поддержка тега <title>
        add_theme_support( 'title-tag' );

        // Поддержка миниатюр постов
        add_theme_support( 'post-thumbnails' );

        // Регистрация навигационного меню в виде канализационных труб
        register_nav_menus( array(
            'primary-menu' => __( 'Канализационное Меню', 'tmnttheme' ),
        ) );
    }
endif;
add_action( 'after_setup_theme', 'tmnttheme_setup' );

/**
 * Подключение стилей и скриптов
 */
function tmnttheme_scripts() {
    // Подключение пиксельного шрифта Press Start 2P из Google Fonts
    wp_enqueue_style( 'tmnt-pixel-font', 'https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap', array(), null );

    // Подключение главного файла стилей
    wp_enqueue_style( 'tmnt-main-style', get_stylesheet_uri(), array( 'tmnt-pixel-font' ), '1.0' );
}
add_action( 'wp_enqueue_scripts', 'tmnttheme_scripts' );
