<?php
/**
 * Функции темы TMNTTheme v2.0
 */
if ( ! function_exists( 'tmnttheme_setup' ) ) :
    function tmnttheme_setup() {
        add_theme_support( 'title-tag' );
        add_theme_support( 'post-thumbnails' );
        add_theme_support( 'custom-background' );

        register_nav_menus( array(
            'primary-menu' => __( 'Канализационное Меню', 'tmnttheme' ),
        ) );
    }
endif;
add_action( 'after_setup_theme', 'tmnttheme_setup' );

function tmnttheme_scripts() {
    wp_enqueue_style( 'tmnt-pixel-font', 'https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap', array(), null );
    wp_enqueue_style( 'tmnt-main-style', get_stylesheet_uri(), array( 'tmnt-pixel-font' ), '2.0' );
}
add_action( 'wp_enqueue_scripts', 'tmnttheme_scripts' );
