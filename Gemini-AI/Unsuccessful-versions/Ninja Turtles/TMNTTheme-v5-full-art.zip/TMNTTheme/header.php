<?php
/**
 * Шапка темы TMNTTheme
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="tmnt-header">
    <div class="tmnt-container">
        <div class="tmnt-logo">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                <?php bloginfo( 'name' ); ?>
            </a>
            <span class="shuriken"></span>
        </div>

        <nav class="sewer-nav">
            <?php
            if ( has_nav_menu( 'primary-menu' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'primary-menu',
                    'container'      => false,
                    'fallback_cb'    => false,
                ) );
            } else {
                echo '<ul><li><a href="#">Главная</a></li><li><a href="#">Блог</a></li><li><a href="#">Пицца-Бар</a></li></ul>';
            }
            ?>
        </nav>
    </div>
</header>
